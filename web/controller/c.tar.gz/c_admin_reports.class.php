<?php
if(!defined('CAN_RUN')) {
	exit('Access Denied');
}


class c_admin_reports extends c_base {
	var $templates=array(
						array('name'=>'', 'title'=>''),
						array('name'=>'commandreport', 'title'=>'命令报表'),
						array('name'=>'appreport', 'title'=>'应用报表'),
						array('name'=>'sftpreport', 'title'=>'SFTP命令报表'),
						array('name'=>'ftpreport', 'title'=>'FTP命令报表'),
						array('name'=>'dangercmdreport', 'title'=>'违规报表'),
						array('name'=>'reportgraph', 'title'=>'图形输出'),
						array('name'=>'logintims', 'title'=>'登录统计'),
						array('name'=>'loginacct', 'title'=>'登录明细'),
						array('name'=>'loginfailed', 'title'=>'登录尝试')
					);
	function index($where = NULL) {
		$back = get_request('back');
		if($back){
			if(is_array($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'])){
				$_GET = array_merge($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'], $_GET);
				$_SERVER['QUERY_STRING'] = http_build_query($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
			}
		}else{
			$_SESSION[$_GET['controller'].'_'.$_GET['action'].'_'.'QUERY_STRING'] = null;
		}
		$page_num = get_request('page');
		$derive = get_request('derive');
		$delete = get_request('delete');
		$where = " WHERE 1=1 ";

		$timetype = get_request('timetype', 0, 1);		
		$types = get_request('types', 0, 1);
		

		switch($timetype){
			case "month":
				$selecttime = " DATE_FORMAT(`start`,\"%Y-%m\") AS startym ";
				$month = get_request('month',0,1);
				$where .= " AND DATE_FORMAT( `start`, \"%Y-%m\")='$month'";
				break;
			case "week":
				
				$week = get_request('week');
				if($week==1) {
					$selecttime = " '上一周'  AS startym ";
					$datestart = mktime(0,0,0,date('m'),date('d')-date('w')-7,date('Y'));
					$dateend = mktime(0,0,0,date('m'),date('d')-date('w'),date('Y'));
				}
				else if($week==2) {
					$selecttime = " '上二周'  AS startym ";
					$datestart = mktime(0,0,0,date('m'),date('d')-date('w')-14,date('Y'));
					$dateend = mktime(0,0,0,date('m'),date('d')-date('w'),date('Y'));
				}
				else if($week==3) {
					$selecttime = " '上三周'  AS startym ";
					$datestart = mktime(0,0,0,date('m'),date('d')-date('w')-21,date('Y'));
					$dateend = mktime(0,0,0,date('m'),date('d')-date('w'),date('Y'));
				}
				else if($week==4) {
					$selecttime = " '上四周'  AS startym ";
					$datestart = mktime(0,0,0,date('m'),date('d')-date('w')-28,date('Y'));
					$dateend = mktime(0,0,0,date('m'),date('d')-date('w'),date('Y'));
				}
				$where .= " AND UNIX_TIMESTAMP(`start`)>$datestart AND  UNIX_TIMESTAMP(`start`)<$dateend ";				
				break;
			case "day":
				$selecttime = " DATE_FORMAT(`start`,\"%Y-%m-%d\") AS startym ";
				$f_rangeStart = get_request('f_rangeStart', 0, 1);
				$where .= " AND DATE_FORMAT(`start`,\"%Y-%m-%d\")='$f_rangeStart' ";
				break;
			default:
				$selecttime = " DATE_FORMAT(`start`,\"%Y-%m-%d\") AS startym ";
				$where .= " AND DATE_FORMAT(`start`,\"%Y-%m-%d\")='".date('Y-m-d')."' ";
		}
		switch($types){
			case "logintype":
				$groupby = " GROUP BY type ";
				$groupbykey = 'type';
				break;
			default:
				$groupby = " GROUP BY user";
				$groupbykey = 'user';
		}
		$having = " HAVING loginnum > 0 ";
		
		$sql = "SELECT * FROM ("
."SELECT IFNULL(s.type,'unknown') type,s.user,s.luser,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM sessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM commands c GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "
." UNION SELECT 'sftp' type,s.sftp_user user,NULL,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM  sftpsessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM sftpcomm c  GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "
." UNION SELECT 'oracle' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM  oracle_sessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM oracle_commands c  GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "
." UNION SELECT 'db2' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM  oracle_sessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM oracle_commands c  GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "
." UNION SELECT 'sybase' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM  sybase_sessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM sybase_commands c  GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "
." UNION SELECT 'mysql' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM  mysql_sessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM mysql_commands c  GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "
." UNION SELECT 'AS400' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM  AS400_sessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM AS400_commands c  GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "

." UNION SELECT 'ftp' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,IFNULL(t.cmdnum,0) cmdnum FROM  ftp_sessions s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM ftp_command c WHERE c.session_desc='cmd' GROUP BY sid) t ON s.sid=t.csid ".$where." GROUP BY $groupbykey "
." UNION SELECT 'rdp' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,0 FROM  rdpsessions s ".$where." GROUP BY $groupbykey "
." UNION SELECT 'vnc' type,s.user,NULL,COUNT(sid) AS loginnum,$selecttime,0 FROM  vncsessions s ".$where." GROUP BY $groupbykey "
.") t $groupby $having ";
	

		if($delete) {
			
		}
		else if($derive) {		
			if($derive==1){	
				$this->derive($sql);
				exit;
			}else if($derive==2){
				$this->derivetoHTML($sql);
				return;
			}
		}
		else {		
			//$table_list = $this->get_table_list();

			$curr_url = $_SERVER['PHP_SELF'] . "?";
			if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
				$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
			}
			else {
				$curr_url .= $_SERVER['QUERY_STRING'];
			}
			//echo $curr_url;
			
			$row_num = $this->sessions_set->base_select("SELECT count(*) ct FROM ($sql) t");
			$row_num = $row_num[0]['ct'];
			$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
			$this->assign('page_list', $newpager->showSerialList());
			$this->assign('session_num', $row_num);
			$this->assign('curr_page', $newpager->intCurrentPageNumber);
			$this->assign('total_page', $newpager->intTotalPageCount);
			$this->assign('items_per_page', $newpager->intItemsPerPage);
			$this->assign('curr_url', $curr_url);
			//$sql = "SELECT COUNT(sid) AS loginnum,DATE_FORMAT(`start`,\"%Y�?m�?d日\") AS startym,s.*,IFNULL(t.cmdnum,0) cmdnum FROM ".$this->sessions_set->get_table_name()." s LEFT JOIN (SELECT COUNT(cid) AS cmdnum,sid csid FROM commands c GROUP BY sid) t ON s.sid=t.csid ".$where.$groupby." LIMIT ".$newpager->intStartPosition.", ".$newpager->intItemsPerPage;
		    $sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
			$allsession = $this->sessions_set->base_select($sql);
			
			
			$this->assign('allsession', $allsession);
			if(!empty($allsession)){
			
				for($ii=0; $ii<count($allsession); $ii++){
					$datastr .= 'data[]='.$allsession[$ii]['loginnum'].'&';
					$infostr .= 'info[]='.($types=='logintype' ? $allsession[$ii]['type'] : $allsession[$ii]['user']).'&';
				}
				$infostr=str_replace('?',"__wenhao__",$infostr);
				$infostr=str_replace('#',"__jinhao__",$infostr);
				$this->assign('data', $datastr);
				$this->assign('info', $infostr);
			}
			//$this->assign('now_table_name', $table_name);
			//$this->assign('table_list', $table_list);
			$curr_url = $_SERVER['PHP_SELF'] . "?";
			if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
				$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
			}
			else {
				$curr_url .= $_SERVER['QUERY_STRING'];
			
			}
			parse_str($_SERVER['QUERY_STRING'], $_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
			$this->display("reports_list.tpl");
		}
	}

	function deriveExcel($sql){//未完成
		$timetype = get_request('timetype', 0, 1);		
		$types = get_request('types', 0, 1);
		error_reporting(E_ALL);
		require_once ROOT.'/include/phpExcel/PHPExcel.php';
		$columns=array('A','B','C','D','E','F','G','H','I');
		$result = $this->sessions_set->base_select($sql);
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");
		$objPHPExcel->setActiveSheetIndex(0);
		$objPHPExcel->getActiveSheet()->setCellValue('A1', "序号");
		$objPHPExcel->getActiveSheet()->setCellValue('B1', "用户名");
		$objPHPExcel->getActiveSheet()->setCellValue('C1', "telnet/ssh");
		$objPHPExcel->getActiveSheet()->setCellValue('D1', "rdp");
		$objPHPExcel->getActiveSheet()->setCellValue('E1', "ftp");
		$objPHPExcel->getActiveSheet()->setCellValue('F1', "sftp");
		$objPHPExcel->getActiveSheet()->setCellValue('G1', "合计");
		$row=2;
		$datastr="";
		$infostr="";
		foreach($result as $info) {
			$col = 0;				
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col++]."$row", $row-1);
			foreach($info as $t) {
				$objPHPExcel->getActiveSheet()->setCellValue($columns[$col++]."$row", $t);					
			}
			$data[]=$result[$row-1]['loginnum'];
			$info[]=($types=='logintype' ? $result[$row-1]['type'] : $result[$row-1]['user']);
			$row++;
		}
		$infostr=str_replace('?',"__wenhao__",$infostr);
		$infostr=str_replace('#',"__jinhao__",$infostr);
		$_GET['data']=$data;
		$_GET['info']=$info;
		$_GET['filename']=ROOT.'/tmp/a.png';
		include(ROOT."/include/pChart/graphgenerate.php");
		
		
		
		$objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
		$objDrawing->setName('Sample image');
		$objDrawing->setDescription('Sample image');
		$objDrawing->setImageResource(imagecreatefrompng($gdImage));
		$objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_PNG);
		$objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
		$objDrawing->setHeight(36);

		$objPHPExcel->setActiveSheetIndex(0);
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="loginreport.xlsx"');
header('Cache-Control: max-age=0');

$objWriter = PHPExcel_IOFactory:: createWriter($objPHPExcel, 'Excel2007');
$objWriter->save( 'php://output');
	}
	
	function derive($sql){
		$allsession = $this->sessions_set->base_select($sql);
		$str = language("时间")."\t".language("登录次数")."\t".language("命令数量")."\t".language("会话类型")."\t".language("登录用户名")." \t". language("本地用户名")."\t\n";
			$id=1;
			if($allsession)
			foreach ($allsession AS $report){		
				
				$str .= $report['startym']."\t".$report['loginnum']."\t".$report['cmdnum']."\t".$report['type']."\t".$report['user']."\t".$report['luser'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=ReportList.csv"); 
			$str= mb_convert_encoding($str, "GB2312", "UTF-8");
			echo $str;			
			exit;
	}
	function derivetoHTML($sql){
		$allsession = $this->sessions_set->base_select($sql);
		ob_start();
		$this->assign('allsession', $allsession);
		$this->display('reports_list_for_export.tpl');
		$str = ob_get_clean();
		if($_GET['derive_forcron']){
			echo $str;
			return ;
		}
		Header('Cache-Control: private, must-revalidate, max-age=0');
		Header("Content-type: application/octet-stream"); 
		Header("Content-Disposition: attachment; filename=auditreports.html"); 
		echo $str;
		exit();
	}
	

	function logintims(){
		$page_num = get_request('page');
		$derive = get_request('derive');
		$row_num = $this->member_set->select_count();
		$f_rangeEnd = get_request('f_rangeEnd', 1, 1);
		$f_rangeStart = get_request('f_rangeStart', 1, 1);
		if(!$f_rangeStart){
			$f_rangeStart = get_request('f_rangeStart', 0, 1);
		}
		if(!$f_rangeEnd){
			$f_rangeEnd = get_request('f_rangeEnd', 0, 1);
		}
		if(!$f_rangeStart){
			$f_rangeStart = date('Y-m-d',mktime(0,0,0,date('m')-1,date('d'),date('Y')));
		}
		if(!$f_rangeEnd){
			$f_rangeEnd = date('Y-m-d',mktime(23,23,59,date('m'),date('d'),date('Y')));
		}
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		
		$this->assign('f_rangeStart', $f_rangeStart);
		$this->assign('f_rangeEnd', $f_rangeEnd);
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "select m.username,IFNULL(s.sct,0) sct,IFNULL(t.tct,0) tct, IFNULL(r.rct,0) rct,IFNULL(a.act,0) act, IFNULL(f.fct,0) fct, IFNULL(sf.sfct,0) sfct, IFNULL(web.webct,0) webct,IFNULL(v.vct,0) vct,(IFNULL(s.sct,0)+IFNULL(a.act,0)+IFNULL(t.tct,0)+IFNULL(r.rct,0)+IFNULL(f.fct,0)+IFNULL(sf.sfct,0)+IFNULL(web.webct,0)+IFNULL(v.vct,0)) as ct  from member m 
					left join (select count(*) sct,luser from sessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND type='ssh' group by luser) s on m.username=s.luser 
					left join (select count(*) tct,luser from sessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND type='telnet' group by luser) t on m.username=t.luser 
					left join (select count(*) rct,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=8 or LOGIN_TEMPLATE=22) group by luser) r on m.username=r.luser
					left join (select count(*) act,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=26) group by luser) a on m.username=a.luser 
					left join (select count(*) vct,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=21) group by luser) v on m.username=a.luser 
					left join (select count(*) fct,radius_user from ftpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' group by radius_user) f on m.username=f.radius_user
					left join (select count(*) sfct,radius_user from sftpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' group by radius_user) sf on m.username=sf.radius_user 
					left join (select count(*) webct,audituser from loginacct where time >= '$f_rangeStart 00:00:00' AND time <= '$f_rangeEnd 23:59:59' and portocol='web' group by audituser) web on m.username=web.audituser ORDER BY ct DESC";			

		if($derive==1){
			$sql = "select m.username,IFNULL(s.sct,0) sct,IFNULL(t.tct,0) tct, IFNULL(r.rct,0) rct,IFNULL(a.act,0) act, IFNULL(f.fct,0) fct, IFNULL(sf.sfct,0) sfct,IFNULL(web.webct,0) webct,IFNULL(v.vct,0) vct,(IFNULL(s.sct,0)+IFNULL(a.act,0)+IFNULL(t.tct,0)+IFNULL(r.rct,0)+IFNULL(f.fct,0)+IFNULL(sf.sfct,0)+IFNULL(web.webct,0)+IFNULL(v.vct,0)) as ct  from member m 
					left join (select count(*) sct,luser from sessions where start >= '$f_rangeStar 00:00:00t' AND end <= '$f_rangeEnd 23:59:59' AND type='ssh' group by luser) s on m.username=s.luser 
					left join (select count(*) tct,luser from sessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND type='telnet' group by luser) t on m.username=t.luser 
					left join (select count(*) rct,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=8 or LOGIN_TEMPLATE=22) group by luser) r on m.username=r.luser
					left join (select count(*) act,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=26) group by luser) a on m.username=a.luser 
					left join (select count(*) vct,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=21) group by luser) v on m.username=a.luser 
					left join (select count(*) fct,radius_user from ftpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' group by radius_user) f on m.username=f.radius_user
					left join (select count(*) sfct,radius_user from sftpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' group by radius_user) sf on m.username=sf.radius_user 
					left join (select count(*) webct,audituser from loginacct where time >= '$f_rangeStart 00:00:00' AND time <= '$f_rangeEnd 23:59:59' and portocol='web' group by audituser) web on m.username=web.audituser ORDER BY ct DESC";			
			$result = $this->sessions_set->base_select($sql);
			//$handle = fopen(ROOT . 'tmp/loginreport.xls', 'w');

			$str = "日期:\t".$f_rangeStart."\t 到 \t".$f_rangeEnd."\n";
			$str .= language("序号")."\t".language("用户名")."\t"."ssh\t"."telnet\t"."rdp\t"."应用\t"."ftp\t"."sftp\t"."前台\t".language("合计")."\t\n";
			$row = 1;
			foreach($result as $info) {
				$col = 0;
				$str .= "$row\t";
				foreach($info as $t) {
					$str .= "$t\t";
					$col++;
				}
				$str .= "\n";
				$row++;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=loginreport.xls"); 
			$str= mb_convert_encoding($str, "GB2312", "UTF-8");
			echo $str;
			exit();
		}elseif($derive==2){
			ob_start();
			$allsession = $this->sessions_set->base_select($sql);
			$this->assign('allsession', $allsession);
			$this->display("loginreports_list_for_export.tpl");
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=auditreports.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$allsession = $this->sessions_set->base_select($sql);
		$this->assign('allsession', $allsession);
		
		$this->assign('session_num', $row_num);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->display("loginreports_list.tpl");
	}

	function derive_logintimes_tohtml($sql){
		
	}
	
	function derive2($sql){
		
	
	}

	function dangercmdreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND a.start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND a.start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM (SELECT a.*,a.addr device_ip, MIN(start) mstart, MAX(start) mend,SUM(bb.ct) ct,bb.cmd FROM ".$this->sessions_set->get_table_name()." a LEFT JOIN (SELECT COUNT(*) ct,sid,cmd FROM ".$this->commands_set->get_table_name()." WHERE dangerlevel > 0 GROUP BY sid,cmd) bb ON bb.sid=a.sid WHERE type='ssh' AND $where AND ct > 0 GROUP BY addr,user,luser,cmd) t ";		
		$row_num = $this->sessions_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "SELECT a.*,a.addr device_ip, MIN(start) mstart, MAX(start) mend,SUM(bb.ct) ct,bb.cmd FROM ".$this->sessions_set->get_table_name()." a LEFT JOIN (SELECT COUNT(*) ct,sid,cmd FROM ".$this->commands_set->get_table_name()." WHERE dangerlevel > 0 GROUP BY sid,cmd) bb ON bb.sid=a.sid WHERE type='ssh' AND $where AND ct > 0  GROUP BY addr,user,luser,cmd ORDER BY $orderby1 $orderby2 ";	
					
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->sessions_set->base_select($sql);
			$str = "日期:\t".$start."\t 到 \t".$end."\n";
			$str .= language("序号")."\t".language("堡垒机用户")."\t".language("系统用户")."\t".language("设备地址")." \t".language("命令次数")." \t".language("开始日期")." \t".language("结束日期")."\t\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['user']."\t".$report['luser']."\t".$report['device_ip']."\t".$report['cmd']."\t".$report['ct']."\t".$report['mstart']."\t".$report['mend'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AuditReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			ob_start();
			$this->assign('reports', $reports);
			$this->display('dangercmdreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=auditreports.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->sessions_set->base_select($sql);
		
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('session_num', $row_num);
		$this->assign('reports', $reports);
		$this->assign('number', $number);
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		$this->display('dangercmdreport.tpl');
	}	

	function dangercmdlistreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'at';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND at >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND at <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM ".$this->commands_set->get_table_name()." WHERE $where AND dangerlevel > 0 ";		
		$row_num = $this->sessions_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "SELECT a.*,bb.type,bb.luser,bb.user,bb.addr device_ip FROM ".$this->commands_set->get_table_name()." a LEFT JOIN ".$this->sessions_set->get_table_name()." bb  ON bb.sid=a.sid WHERE $where AND dangerlevel > 0 ORDER BY $orderby1 $orderby2 ";	
					
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->sessions_set->base_select($sql);
			$str = "日期:\t".$start."\t 到 \t".$end."\n";
			$str .=  language("序号")."\t".language("运维用户")."\t".language("服务器IP")."\t".language("登录协议")."\t".language("系统用户")." \t".language("违规命令")." \t".language("违规级别")." \t".language("操作时间")."\n";
			$id=1;
			foreach ($reports AS $report){		
				
				$str .= ($id++)."\t".$report['luser']."\t".$report['device_ip']."\t".$report['type']."\t".$report['user']."\t".$report['cmd']."\t".($report['dangerlevel']==1 ? '命令阻断' : ($report['dangerlevel']==2 ? '断开连接' : '命令告警' ))."\t".$report['at'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=DangerCmdListReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			ob_start();
			$this->assign('reports', $reports);
			$this->display('dangercmdlistreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=DangerCmdListReport.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->sessions_set->base_select($sql);
		
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('session_num', $row_num);
		$this->assign('reports', $reports);
		$this->assign('number', $number);
		
		$this->display('dangercmdlistreport.tpl');
	}	
	
	function commandreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM (SELECT * FROM ".$this->sessions_set->get_table_name()." WHERE $where  GROUP BY addr,user,luser) t ";		
		$row_num = $this->sessions_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "SELECT a.*,a.addr device_ip, MIN(start) mstart, MAX(start) mend,SUM(bb.ct) ct FROM ".$this->sessions_set->get_table_name()." a LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->commands_set->get_table_name()." WHERE 1 GROUP BY sid) bb ON bb.sid=a.sid WHERE $where GROUP BY addr,user,luser ORDER BY $orderby1 $orderby2 ";	
		
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->sessions_set->base_select($sql);
			$str = "日期:\t".$start."\t 到 \t".$end."\n";
			$str .= language("序号")."\t".language("堡垒机用户")."\t".language("系统用户")."\t".language("设备地址")." \t".language("登录次数")." \t".language("开始日期")." \t".language("结束日期")."\t\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['user']."\t".$report['luser']."\t".$report['device_ip']."\t".$report['ct']."\t".$report['mstart']."\t".$report['mend'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=CommandReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			ob_start();
			$this->assign('reports', $reports);
			$this->display('commandreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=auditreports.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->sessions_set->base_select($sql);
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('reports', $reports);
		$this->assign('session_num', $row_num);
		$this->assign('number', $number);
		
		$this->display('commandreport.tpl');
	}

	function appreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM (SELECT * FROM ".$this->appcomm_set->get_table_name()." WHERE $where  GROUP BY serverip,appname,memberid) t ";		
		$row_num = $this->appcomm_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, 20, 'page');
		$sql = "SELECT a.*,addr device_ip,count(*) ct, MIN(start) mstart, MAX(start) mend,b.username user FROM ".$this->appcomm_set->get_table_name()." a LEFT JOIN ".$this->member_set->get_table_name()." b ON a.memberid=b.uid WHERE $where GROUP BY serverip,appname,memberid ORDER BY $orderby1 $orderby2 ";	
		$reports = $this->appcomm_set->base_select($sql);			
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->appcomm_set->base_select($sql);			
			$str = "日期:\t".$start."\t 到 \t".$end."\n";
			$str .= language("序号")."\t".language("堡垒机用户")."\t".language("系统用户")."\t".language("应用名称")." \t".language("登录次数")." \t".language("开始日期")." \t".language("结束日期")."\t\n";
			$id=1;
			if($reports)
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['user']."\t".$report['luser']."\t".$report['appname']."\t".$report['ct']."\t".$report['mstart']."\t".$report['mend'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AuditReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->appcomm_set->base_select($sql);			
			ob_start();
			$this->assign('reports', $reports);
			$this->display('appreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=auditreports.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->appcomm_set->base_select($sql);			
		
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('reports', $reports);
		$this->assign('session_num', $row_num);
		$this->assign('number', $number);
		
		$this->display('appreport.tpl');
	}

	function sftpreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM (SELECT * FROM ".$this->sftpsession_set->get_table_name()." WHERE $where  GROUP BY radius_user,sftp_user) t ";		
		$row_num = $this->sftpsession_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "SELECT *,MIN(start) mstart, MAX(start) mend,SUM(putct) putct,SUM(getct) getct,SUM(ct) ct FROM (SELECT a.svraddr device_ip,a.sftp_user,a.radius_user,a.start,a.end, IF(b.ct,b.ct,0) putct,IF(c.ct,c.ct,0) getct,IF(bb.ct,bb.ct,0) ct FROM ".$this->sftpsession_set->get_table_name()." a LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->sftpcmd_set->get_table_name()." WHERE LEFT(comm,3)='put' GROUP BY sid) b ON b.sid=a.sid LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->sftpcmd_set->get_table_name()." WHERE LEFT(comm,3)='get' GROUP BY sid) c ON c.sid=a.sid LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->sftpcmd_set->get_table_name()." WHERE 1 GROUP BY sid) bb ON bb.sid=a.sid GROUP BY a.sid, radius_user,sftp_user) t WHERE $where GROUP BY radius_user,sftp_user ORDER BY $orderby1 $orderby2";	
		$reports = $this->appcomm_set->base_select($sql);			
		
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->appcomm_set->base_select($sql);			
			$str = "日期:\t".$start."\t 到 \t".$end."\n";
			$str .= language("序号")."\t".language("堡垒机用户")."\t".language("上载次数")."\t".language("下载次数")." \t".language("登录次数")." \t".language("开始日期")." \t".language("结束日期")."\t\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['radius_user']."\t".$report['sftp_user']."\t".$report['putct']."\t".$report['getct']."\t".$report['ct']."\t".$report['mstart']."\t".$report['mend'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AuditReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->appcomm_set->base_select($sql);			
			ob_start();
			$this->assign('reports', $reports);
			$this->display('sftpreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=auditreports.html"); 
			echo $str;
			exit();
		}
		$sql .= "  LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->appcomm_set->base_select($sql);			
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('session_num', $row_num);
		$this->assign('reports', $reports);
		$this->assign('number', $number);
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		$this->display('sftpreport.tpl');
	}

	function ftpreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM (SELECT * FROM ".$this->ftpsession_set->get_table_name()." WHERE $where GROUP BY radius_user,ftp_user) t ";		
		$row_num = $this->ftpsession_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "SELECT *,MIN(start) mstart, MAX(start) mend,SUM(putct) putct,SUM(getct) getct,SUM(ct) ct FROM (SELECT a.svraddr device_ip,a.ftp_user,a.radius_user,a.start,a.end, IF(b.ct,b.ct,0) putct,IF(c.ct,c.ct,0) getct,IF(bb.ct,bb.ct,0) ct FROM ".$this->ftpsession_set->get_table_name()." a LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->ftpcmd_set->get_table_name()." WHERE LEFT(comm,3)='put' GROUP BY sid) b ON b.sid=a.sid LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->ftpcmd_set->get_table_name()." WHERE LEFT(comm,3)='get' GROUP BY sid) c ON c.sid=a.sid LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->ftpcmd_set->get_table_name()." WHERE 1 GROUP BY sid) bb ON bb.sid=a.sid GROUP BY a.sid, radius_user,ftp_user) t WHERE $where GROUP BY radius_user,ftp_user ORDER BY $orderby1 $orderby2 ";	
		
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->appcomm_set->base_select($sql);			
			$str = "日期:\t".$start."\t 到 \t".$end."\n";
			$str .= language("序号")."\t".language("堡垒机用户")."\t".language("上载次数")."\t".language("下载次数")." \t".language("登录次数")." \t".language("开始日期")." \t".language("结束日期")."\t\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['radius_user']."\t".$report['ftp_user']."\t".$report['putct']."\t".$report['getct']."\t".$report['ct']."\t".$report['mstart']."\t".$report['mend'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AuditReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->appcomm_set->base_select($sql);			
			ob_start();
			$this->assign('reports', $reports);
			$this->display('ftpreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=auditreports.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->appcomm_set->base_select($sql);			
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('session_num', $row_num);
		$this->assign('reports', $reports);
		$this->assign('number', $number);
		
		$this->display('ftpreport.tpl');
	}
	
	function reportgraph() {
		$f_rangeStart = get_request('f_rangeStart', 0, 1);
		$f_rangeEnd = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive', 0, 1);
		if(empty($f_rangeStart)&&empty($f_rangeEnd)){
			$f_rangeStart = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$f_rangeEnd = date('Y-m-d');
		}
		$f_rangeEnd = empty($f_rangeEnd) ? date('Y-m-d') : $f_rangeEnd;

		$sql = "select m.username,(IFNULL(s.sct,0)+IFNULL(a.act,0)+IFNULL(t.tct,0)+IFNULL(r.rct,0)+IFNULL(f.fct,0)+IFNULL(sf.sfct,0)) as num  from member m 
					left join (select count(*) sct,luser from sessions where start >= '$f_rangeStart 00:00:00' AND start <= '$f_rangeEnd 23:59:59' AND type='ssh' group by luser) s on m.username=s.luser 
					left join (select count(*) tct,luser from sessions where start >= '$f_rangeStart 00:00:00' AND start <= '$f_rangeEnd 23:59:59' AND type='telnet' group by luser) t on m.username=t.luser 
					left join (select count(*) rct,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND start <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=8 or LOGIN_TEMPLATE=22) group by luser) r on m.username=r.luser
					left join (select count(*) act,luser from rdpsessions where start >= '$f_rangeStart 00:00:00' AND start <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=26) group by luser) a on m.username=a.luser 
					left join (select count(*) fct,radius_user from ftpsessions where start >= '$f_rangeStart 00:00:00' AND start <= '$f_rangeEnd 23:59:59' group by radius_user) f on m.username=f.radius_user
					left join (select count(*) sfct,radius_user from sftpsessions where start >= '$f_rangeStart 00:00:00' AND start <= '$f_rangeEnd 23:59:59' group by radius_user) sf on m.username=sf.radius_user ORDER BY num DESC LIMIT 10";
		$top10user = $this->commands_set->base_select($sql);

		$sql = "select count(*) num,'ssh' as protocol from sessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND type='ssh' UNION select count(*) tct,'telnet' from sessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND type='telnet' UNION select count(*) rct,'rdp' from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=8 or LOGIN_TEMPLATE=22) UNION select count(*) act,'app' from rdpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' AND (LOGIN_TEMPLATE=26) UNION select count(*) fct,'ftp' from ftpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59' UNION select count(*) sfct,'sftp' from sftpsessions where start >= '$f_rangeStart 00:00:00' AND end <= '$f_rangeEnd 23:59:59'";
		$top10protocol = $this->commands_set->base_select($sql);

		$top10srcip = $this->loginacct_set->base_select("SELECT count(*) num,sourceip FROM ".$this->loginacct_set->get_table_name()." WHERE time >= '$f_rangeStart 00:00:00' AND time <= '$f_rangeEnd 23:59:59' GROUP BY sourceip ORDER BY num desc LIMIT 10");

		$top10dstip = $this->loginacct_set->base_select("SELECT count(*) num,serverip FROM ".$this->loginacct_set->get_table_name()." WHERE time >= '$f_rangeStart 00:00:00' AND time <= '$f_rangeEnd 23:59:59' GROUP BY serverip ORDER BY num desc LIMIT 10");
		
		
		$datetime = explode(" ", $f_rangeEnd);
		$endymd = explode("-", $datetime[0]);
		
		$f_rangeStart = date('Y-m-d', mktime(0,0,0,$endymd[1],$endymd[2]-10,$endymd[0]));
		$last10user = $this->loginacct_set->base_select("SELECT count(*) num,audituser FROM ".$this->loginacct_set->get_table_name()." WHERE time >= '$f_rangeStart 00:00:00' AND time <= '$f_rangeEnd 23:59:59' GROUP BY audituser ORDER BY num desc LIMIT 10");
		if(is_array($last10user))
		$last10user = array_reverse($last10user);

		$this->assign('top10user', json_encode($top10user));
		$this->assign('top10protocol', json_encode($top10protocol));
		$this->assign('top10srcip', json_encode($top10srcip));
		$this->assign('top10dstip', json_encode($top10dstip));
		$this->assign('last10user', json_encode($last10user));
		$this->assign('f_rangeStart', $f_rangeStart);
		$this->assign('f_rangeEnd', $f_rangeEnd);

		if($derive==2){	
			ob_start();
			$this->display('reportgraph_for_export.tpl');
			$str = ob_get_clean();
			
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=ReportGraph.html"); 
			echo $str;
			exit();
		}

		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->display('reportgraph.tpl');
	}

	function loginacct($where = NULL) {
		$page_num = get_request('page');
		$derive = get_request('derive');
		$delete = get_request('delete');
		$where = "1=1";
		$start = get_request('start');

		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		$id1 = get_request('id1');
		$id2 = get_request('id2');
		$serverip = get_request('serverip', 0, 1);
		$from = get_request('from', 0, 1);
		$systemuser = get_request('systemuser', 0, 1);
		$audituser = get_request('audituser', 0, 1);
		$protocol = get_request('protocol', 0, 1);
		$status = get_request('authenticationstatus', 0, 1);
		$time_start = get_request('f_rangeStart', 0, 1);
		$time_end = get_request('f_rangeEnd', 0, 1);
		if(empty($time_start)&&empty($time_end)){
			$time_start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$time_end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'time';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);

		if($id1){
			$where .= " AND sid>=$id1";
		}
		if($id2){
			$where .= " AND sid<=$id2";
		}
		if($time_start){
			$where .= " AND `time` >='".$time_start." 00:00:00'";
		}
		if($time_end){
			$where .= " AND `time` <='".$time_end." 23:59:59'";
		}
		if($from) {
			if(is_ip($from)) {
				$where .= " AND `sourceip` = '$from'";
			}
			else {
				$where .= " AND `sourceip` LIKE '$from%'";
			}
		}
		if($protocol){
			$where .=" AND `portocol`='$protocol'";
		}

		if($serverip) {
			if(is_ip($serverip)) {
				$where .= " AND serverip = '$serverip'";
			}
			else {
				$where .= " AND serverip LIKE '$serverip%'";
			}
		}
		
		if($systemuser) {
			$where .= " AND (systemuser LIKE '%$systemuser%')";
		}
		
		if($audituser) {
			$where .= " AND (audituser LIKE '%$audituser%')";
		}
		if($status!=""){
			$where .= " AND (authenticationstatus='$status')";
		}
		if($_SESSION['ADMIN_LEVEL']==0){
			$where .= " AND (audituser = '".$_SESSION['ADMIN_USERNAME']."')";
		}
		$get_user_flist = $this->get_user_flist();
		if($_SESSION['ADMIN_LEVEL'] != 1 and !empty($get_user_flist)) {
			$where .= " AND host IN (" . implode(",", $get_user_flist) . ")";
		}

		
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		
		}
		$this->assign('f_rangeStart', $time_start);
		$this->assign('f_rangeEnd', $time_end);
		if($delete) {
			if($_SESSION['ADMIN_LEVEL'] == 1) {
				$this->delete_loginlog($where);
			}
			else {
				die(language('没有权限'));
			}
		}
		
		else if($derive) {
			if($derive==1){
				$result = $this->loginacct_set->select_limit($start, 10000, $where );		
				$str = "日期:\t".$time_start."\t 到 \t".$time_end."\n";
				$str .= language("序号")."SID\t";
				$str .= language("来源地址")."\t";
				$str .= language("审计系统")."\t";
				$str .= language("目标地址")."\t";
				$str .= language("登录协议")."\t";
				$str .= language("时间")."\t";
				$str .= language("运维账号")."\t";
				$str .= language("系统帐号")."\t";
				$str .= language("状态")."\t";
				$str .= language("出错原因")."\t\n";
				$row = 1;
				if(!empty($result))
				foreach($result as $info) {
					$str .= $info['sid']."\t";
					$str .= $info['sourceip']."\t";
					$str .= $info['auditip']."\t";
					$str .= $info['serverip']."\t";
					$str .= $info['portocol']."\t";
					$str .= $info['time']."\t";
					$str .= $info['audituser']."\t";
					$str .= $info['systemuser']."\t";
					$str .= ($info['authenticationstatus'] ? '成功' : '失败')."\t";
					$str .= $info['failreason']."\t";	
					$str .= "\n";		
					
					$row++;
				}
				Header('Cache-Control: private, must-revalidate, max-age=0');
				Header("Content-type: application/octet-stream"); 
				Header("Content-Disposition: attachment; filename=loginacct.xls"); 
				echo iconv("UTF-8", "GB2312", $str);
				exit();		
			}else if($derive==2){
				$alllog=$this->loginacct_set->select_limit($start, 10000, $where );
				ob_start();
				$this->assign('alllog', $alllog);
				$this->assign('title', language('登录日志'));
				$this->display('loginacct_export_tohtml.tpl');
				$str = ob_get_clean();
				if($_GET['derive_forcron']){
					echo $str;
					return ;
				}
				Header('Cache-Control: private, must-revalidate, max-age=0');
				Header("Content-type: application/octet-stream"); 
				Header("Content-Disposition: attachment; filename=auditreports.html"); 
				echo $str;
				exit();
				return;
			}
		}
		else {
			
			$row_num = $this->loginacct_set->select_count($where);
			$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
			$alllog=$this->loginacct_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage, $where, $orderby1, $orderby2 );
			if($row_num>10000){				
				$num = ceil($row_num/10000);
				$str = "";
				$strhtml = "";
				for($i=0; $i<$num; $i++){
					$str .= "<a href='".$curr_url."&derive=1&start=".($i*10000+1)."' target='_blank'>".($i*10000+1)."-".(($i+1)*10000 < $row_num ? ($i+1)*10000 : $row_num)."</a>  ";
					$strhtml .= "<a href='".$curr_url."&derive=2&start=".($i*10000+1)."' target='_blank'>".($i*10000+1)."-".(($i+1)*10000 < $row_num ? ($i+1)*10000 : $row_num)."</a>  ";
				}
			}
			$alltem = $this->tem_set->select_all("device_type=''");
			$this->assign("alltem", $alltem);
			$this->assign("str", $str);
			$this->assign("strhtml", $strhtml);
			$this->assign('page_list', $newpager->showSerialList());
			$this->assign('log_num', $row_num);
			$this->assign('curr_page', $newpager->intCurrentPageNumber);
			$this->assign('total_page', $newpager->intTotalPageCount);
			$this->assign('items_per_page', $newpager->intItemsPerPage);
			$this->assign('curr_url', $curr_url);
			$this->assign('alllog', $alllog);
			
			$this->display("loginacct.tpl");
		}
	}

	
	function loginfailed($where = NULL) {
		$page_num = get_request('page');
		$derive = get_request('derive');
		$delete = get_request('delete');
		$where = "1=1";
		$start = get_request('start');

		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		$serverip = get_request('serverip', 0, 1);
		$from = get_request('from', 0, 1);
		$audituser = get_request('audituser', 0, 1);
		$protocol = get_request('protocol', 0, 1);
		$ct = get_request('ct', 0, 1);
		$time_start = get_request('f_rangeStart', 0, 1);
		$time_end = get_request('f_rangeEnd', 0, 1);
		if(empty($time_start)&&empty($time_end)){
			$time_start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$time_end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);

		if($id1){
			$where .= " AND sid>=$id1";
		}
		if($id2){
			$where .= " AND sid<=$id2";
		}
		if($time_start){
			$where .= " AND `time` >='".$time_start." 00:00:00'";
		}
		if($time_end){
			$where .= " AND `time` <='".$time_end." 23:59:59'";
		}
		if($from) {
			if(is_ip($from)) {
				$where .= " AND `sourceip` = '$from'";
			}
			else {
				$where .= " AND `sourceip` LIKE '$from%'";
			}
		}
		if($protocol){
			$where .=" AND `portocol`='$protocol'";
		}

		if($serverip) {
			if(is_ip($serverip)) {
				$where .= " AND serverip = '$serverip'";
			}
			else {
				$where .= " AND serverip LIKE '$serverip%'";
			}
		}
		
		if($systemuser) {
			$where .= " AND (systemuser LIKE '%$systemuser%')";
		}
		
		if($audituser) {
			$where .= " AND (audituser LIKE '%$audituser%')";
		}
		if($status!=""){
			$where .= " AND (authenticationstatus='$status')";
		}
		if($_SESSION['ADMIN_LEVEL']==0){
			$where .= " AND (audituser = '".$_SESSION['ADMIN_USERNAME']."')";
		}
		$get_user_flist = $this->get_user_flist();
		if($_SESSION['ADMIN_LEVEL'] != 1 and !empty($get_user_flist)) {
			$where .= " AND host IN (" . implode(",", $get_user_flist) . ")";
		}

		
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		
		}
		
		if($delete) {
			if($_SESSION['ADMIN_LEVEL'] == 1) {
				$this->delete_loginlog($where);
			}
			else {
				die(language('没有权限'));
			}
		}
		
		else if($derive) {
			if($derive==1){
				$result=$this->loginacct_set->base_select("SELECT count(*) ct,serverip,sourceip,audituser,portocol FROM ".$this->loginacct_set->get_table_name()." WHERE $where  GROUP BY serverip,sourceip,audituser,portocol ORDER BY serverip asc LIMIT $start, 10000");
				//$handle = @fopen(ROOT . '/tmp/loginacct.xls', 'w');
				
				$str = "日期:\t".$time_start."\t到\t".$time_end."\n";
				$str .= language("序号")."SID\t";
				$str .= language("来源地址")."\t";
				$str .= language("主机地址")."\t";
				$str .= language("登录协议")."\t";
				$str .= language("运维账号")."\t";
				$str .= language("次数")."\t\n";
				$row = 1;
				if(!empty($result))
				foreach($result as $info) {
					$str .= $info['sid']."\t";
					$str .= $info['sourceip']."\t";
					$str .= $info['serverip']."\t";
					$str .= $info['portocol']."\t";
					$str .= $info['audituser']."\t";
					$str .= $info['ct']."\t";	
					$str .= "\n";		
					
					$row++;
				}
				Header('Cache-Control: private, must-revalidate, max-age=0');
				Header("Content-type: application/octet-stream"); 
				Header("Content-Disposition: attachment; filename=loginacct.xls"); 
				$str= mb_convert_encoding($str, "GB2312", "UTF-8");
				echo $str;
				exit();
			}else if($derive==2){
				$alllog=$this->loginacct_set->base_select("SELECT count(*) ct,serverip,sourceip,audituser,portocol FROM ".$this->loginacct_set->get_table_name()." WHERE $where  GROUP BY serverip,sourceip,audituser,portocol ORDER BY serverip asc LIMIT $start, 10000");
				ob_start();
				$this->assign('alllog', $alllog);
				$this->assign('title', language('登录日志'));
				$this->display('loginfailed_export_tohtml.tpl');
				$str = ob_get_clean();
				if($_GET['derive_forcron']){
					echo $str;
					return ;
				}
				Header('Cache-Control: private, must-revalidate, max-age=0');
				Header("Content-type: application/octet-stream"); 
				Header("Content-Disposition: attachment; filename=auditreports.html"); 
				echo $str;
				exit();
				return;
			}
		}
		else {
			
			$row_num = $this->loginacct_set->base_select("SELECT count(*) AS row_num FROM (SELECT count(*) FROM ".$this->loginacct_set->get_table_name()." WHERE $where GROUP BY serverip,sourceip,audituser,portocol) t");
			$row_num = $row_num[0]['row_num'];
			$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
			$alllog=$this->loginacct_set->base_select("SELECT count(*) ct,serverip,sourceip,audituser,portocol FROM ".$this->loginacct_set->get_table_name()." WHERE $where  GROUP BY serverip,sourceip,audituser,portocol ORDER BY $orderby1 $orderby2 LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage");
			if($row_num>10000){				
				$num = ceil($row_num/10000);
				$str = "";
				$strhtml = "";
				for($i=0; $i<$num; $i++){
					$str .= "<a href='".$curr_url."&derive=1&start=".($i*10000+1)."' target='_blank'>".($i*10000+1)."-".(($i+1)*10000 < $row_num ? ($i+1)*10000 : $row_num)."</a>  ";
					$strhtml .= "<a href='".$curr_url."&derive=2&start=".($i*10000+1)."' target='_blank'>".($i*10000+1)."-".(($i+1)*10000 < $row_num ? ($i+1)*10000 : $row_num)."</a>  ";
				}
			}
			$alltem = $this->tem_set->select_all("device_type=''");
			$this->assign("alltem", $alltem);
			$this->assign("str", $str);
			$this->assign("strhtml", $strhtml);
			$this->assign('page_list', $newpager->showSerialList());
			$this->assign('log_num', $row_num);
			$this->assign('curr_page', $newpager->intCurrentPageNumber);
			$this->assign('total_page', $newpager->intTotalPageCount);
			$this->assign('items_per_page', $newpager->intItemsPerPage);
			$this->assign('curr_url', $curr_url);
			$this->assign('alllog', $alllog);
			$this->assign('f_rangeStart', $start);
			$this->assign('f_rangeEnd', $end);
			$this->display("loginfailed.tpl");
		}
	}


	function derive_loginfailed($start, $where) {		
		
	
	}
	
	function derive_loginfailed_tohtml($start, $where){
		
	}
	
	function configreport(){
		$back = get_request('back');
		if($back){
			if(is_array($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'])){
				$_GET = array_merge($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'], $_GET);
				$_SERVER['QUERY_STRING'] = http_build_query($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
			}
		}else{
			$_SESSION[$_GET['controller'].'_'.$_GET['action'].'_'.'QUERY_STRING'] = null;
		}
		$page_num = get_request('page');
		$derive = get_request('derive');
		$view = get_request('view');
		$delete = get_request('delete');
		$where = "1=1";
		$start = get_request('start');
		$subject = get_request('subject', 0, 1);
		$template = get_request('template', 0, 1);
		$f_rangeStart = get_request('f_rangeStart', 0, 1);
		$f_rangeEnd = get_request('f_rangeEnd', 0, 1);

		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		
		if(empty($orderby1)){
			$orderby1 = 'createtime';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);

		if($time_start){
			$where .= " AND `time` >='".$time_start."'";
		}
		if($time_end){
			$where .= " AND `time` <='".$time_end."'";
		}
		if($from) {
			
				$where .= " AND subject LIKE '$from%'";
			
		}
		if($template){
			$where .=" AND template='$template'";
		}

		if($subject){
			$where .=" AND subject like '%$subject%'";
		}
		
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];		
		}
		parse_str($_SERVER['QUERY_STRING'], $_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
		if($derive||$view) {
			$id = get_request('id');
			$report = $this->configreport_set->select_by_id($id);
			switch($report['cycle']){
				case 'thisday':
					$_GET['f_rangeStart'] = date('Y-m-d', mktime(0,0,0,date('m'),date('d'),date('Y')));
					break;
				case 'thisweek':
					$_GET['f_rangeStart'] = date('Y-m-d', mktime(0,0,0,date('m'),date('d')-date('w'),date('Y')));
					break;
				case 'thismonth':
					$_GET['f_rangeStart'] = date('Y-m-d', mktime(0,0,0,date('m'),1,date('Y')));
					break;
			}
			$pos = strpos($report['template'], '_');
			if($pos===false){
				$prev=$report['template'];
			}else{
				$prev = substr($report['template'], 0, $pos);
				if($pos+1<=strlen($report['template']))
					$back = substr($report['template'], $pos+1);
			}
			if($view){
				unset($derive);
			}
			
			switch($prev){
				case 'reportaudit':
					$_GET['number']=$back;
					$this->$prev();
					break;
				default:
					$this->$prev();
					break;
					
			}
			exit;
		} else {
			//echo $where;
			$row_num = $this->configreport_set->select_count($where);
			$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
			$alllog=$this->configreport_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage, $where, $orderby1, $orderby2 );
			for($i=0; $i<count($alllog); $i++){
				for($j=0; $j<count($this->templates); $j++){
					if($alllog[$i]['template']==$this->templates[$j]['name']){
						$alllog[$i]['templatename']=$this->templates[$j]['title'];
					}
				}
				switch($alllog[$i]['cycle']){
					case 'thisday';
						$alllog[$i]['cyclename']='当天';
					break;
					case 'thisweek';
						$alllog[$i]['cyclename']='本周';
					break;
					case 'thismonth';
						$alllog[$i]['cyclename']='当月';
					break;
				}
				
			}
			$this->assign("templates", $this->templates);
			$this->assign('page_list', $newpager->showSerialList());
			$this->assign('log_num', $row_num);
			$this->assign('curr_page', $newpager->intCurrentPageNumber);
			$this->assign('total_page', $newpager->intTotalPageCount);
			$this->assign('items_per_page', $newpager->intItemsPerPage);
			$this->assign('curr_url', $curr_url);
			$this->assign('alllog', $alllog);
			$this->assign('f_rangeStart', $start);
			$this->assign('f_rangeEnd', $end);
			$this->display("configreport.tpl");
		}
	}

	function configreport_edit(){
		$id = get_request("id");
		$configreport = $this->configreport_set->select_by_id($id);
		
		$this->assign("id", $id);
		$this->assign("templates", $this->templates);
		$this->assign("configreport", $configreport);
		$this->display("configreport_edit.tpl");
	}
	
	function configreport_save(){
		$id = get_request("id");
		$template = get_request("template", 1, 1);
		$subject = get_request("subject", 1, 1);
		$cycle = get_request("cycle", 1, 1);
		$newconfigreport = new configreport();
		$newconfigreport->set_data("template", $template);
		$newconfigreport->set_data("subject", $subject);
		$newconfigreport->set_data("cycle", $cycle);
		$newconfigreport->set_data("createtime", date('Y-m-d'));
		if($id){
			$newconfigreport->set_data("id", $id);
			$this->configreport_set->edit($newconfigreport);
		}else{
			$this->configreport_set->add($newconfigreport);
		}
		alert_and_back('操作成功','admin.php?controller=admin_reports&action=configreport');
	}

	function configreport_delete(){
		$this->configreport_set->delete($_POST['chk_member']);
		alert_and_back('操作成功','admin.php?controller=admin_reports&action=configreport');
	}

	function cronreports(){
		$page_num = get_request('page');
		$ac = get_request('ac', 1, 1);
		$week = get_request('week',1,1);
		$month = get_request('month',1,1);
		
		if($ac){			
			if($week)
			$week = implode(',', $week);
			if($month)
			$month = implode(',', $month);
			$sql = ($ac != 'new' ? 'UPDATE' : 'INSERT INTO ')." cronreports SET week='$week', month='$month'";
			$this->config_set->query($sql);
			alert_and_back('修改成功');
			exit;
		}
		$ha = $this->config_set->base_select("SELECT * FROM cronreports LIMIT 1");
		if($ha){			
			$ha_week = explode(',', $ha[0]['week']);
			for($i=0; $i<count($ha_week); $i++){
				$defaultp['week_'.$ha_week[$i]]=1;
			}
			$ha_month = explode(',', $ha[0]['month']);
			
			for($i=0; $i<count($ha_month); $i++){
				$defaultp['month_'.$ha_month[$i]]=1;
			}
			$this->assign('defaultp', $defaultp);
		}
		
		$this->display("cronreports.tpl");
	}

	function docronreports(){
		global $_CONFIG;
		$filename_a = array("commandreport"=>'运行命令报表',"sftpreport"=>'SFTP命令报表',"ftpreport"=>'FTP命令报表',"appreport"=>'应用报表',"logintims"=>'登录统计',"dangercmdreport"=>'违规报表',"logintims"=>'登录统计');

		$ha = $this->config_set->base_select("SELECT * FROM cronreports LIMIT 1");
		$_GET['derive']=2;
		$_GET['derive_forcron']=1;
		if($ha[0]['week']){			
			$ha_week = explode(',', $ha[0]['week']);
			$_GET['f_rangeStart'] = date('Y-m-d', mktime(0,0,0,date('m'),date('d')-date('w')-7,date('Y')));
			$_GET['f_rangeEnd'] = date('Y-m-d', mktime(0,0,0,date('m'),date('d')+7,date('Y')));
			for($i=0; $i<count($ha_week); $i++){
				$pos = strpos($ha_week[$i], '_');
				if($pos===false){
					$prev=$ha_week[$i];
				}else{
					$prev = substr($ha_week[$i], 0, $pos);
					if($pos+1<=strlen($ha_week[$i]))
						$back = substr($ha_week[$i], $pos+1);
				}
				echo "week_".$ha_week[$i].'<br >';
				ob_start();
				switch($prev){
					case 'reportaudit':
						$_GET['number']=$back;
						$this->$prev();
						break;
					default:						
						$this->$prev();
						break;
						
				}
				$contents = ob_get_clean();
				file_put_contents("tmp/week_".$ha_week[$i].".html", $contents);
				
				$savfile = $_CONFIG['REPORT_FILE_PATH']."week_".$ha_week[$i]."_".$_GET['f_rangeStart']."_".$_GET['f_rangeEnd'].".html";
		
				copy("tmp/week_".$ha_week[$i].".html", $savfile);
				
				$crf = new crontab_report_file();
				
				$crf->set_data('filepath', $savfile);
				
				$crf->set_data('title', $filename_a[$ha_week[$i]]);
				
				$crf->set_data('start', $_GET['f_rangeStart']);
				
				$crf->set_data('end', $_GET['f_rangeEnd']);
				
				$this->crontab_report_file_set->add($crf);
				$weekfile[]="tmp/week_".$ha_week[$i].".html";
			}
		}
		if($ha[0]['month']){			
			$ha_month = explode(',', $ha[0]['month']);
			$_GET['f_rangeStart'] = date('Y-m-d', mktime(0,0,0,date('m')-1,1,date('Y')));
			$_GET['f_rangeEnd'] = date('Y-m-d', mktime(0,0,0,date('m'),1,date('Y')));
			for($i=0; $i<count($ha_month); $i++){
				$pos = strpos($ha_month[$i], '_');
				if($pos===false){
					$prev=$ha_month[$i];
				}else{
					$prev = substr($ha_month[$i], 0, $pos);
					if($pos+1<=strlen($ha_month[$i]))
						$back = substr($ha_month[$i], $pos+1);
				}
				echo "month_".$ha_month[$i].'<br >';
				ob_start();
				switch($prev){
					case 'reportaudit':
						$_GET['number']=$back;
						$this->$prev();
						break;
					default:						
						$this->$prev();
						break;
						
				}
				$contents = ob_get_clean();
				file_put_contents("tmp/month_".$ha_month[$i].".html", $contents);
				$savfile = $_CONFIG['REPORT_FILE_PATH']."month_".$ha_week[$i]."_".$_GET['f_rangeStart']."_".$_GET['f_rangeEnd'].".html";
				copy("tmp/month_".$ha_week[$i].".html", $savfile);
				$crf = new crontab_report_file();
				$crf->set_data('filepath', $savfile);
				$crf->set_data('title', $filename_a[$ha_week[$i]]);
				$crf->set_data('start', $_GET['f_rangeStart']);
				$crf->set_data('end', $_GET['f_rangeEnd']);
				$this->crontab_report_file_set->add($crf);
				$monthfile[]="tmp/week_".$ha_week[$i].".html";
			}		
		}
		if($weekfile||$monthfile){
			require_once ROOT. './include/emailattachfile.php';
			$ha = $this->config_set->base_select("SELECT * FROM alarm LIMIT 1");
			$admin = $this->member_set->select_all("username='admin'");
			$e = new CSMTP($ha[0]['MailServer'],"25",$ha[0]['account'],$ha[0]['password']);
	
			$e -> linkSMTP(); 
			$e -> buildMail(array($admin[0]['email']) ,"报表" ,"报表附件中","text/html"); 
			for($i=0; $i<count($weekfile); $i++){echo $weekfile[$i];
				$tmpfilename = substr($weekfile[$i],strpos($weekfile[$i],"_")+1);
				$tmpfilename = substr($tmpfilename, 0, strpos($tmpfilename, "."));
				$tmpfilename = $filename_a[$tmpfilename].".html";
				$e -> attachFile($weekfile[$i],'周报-'.$tmpfilename); 
			}
			for($i=0; $i<count($monthfile); $i++){
				$tmpfilename = substr($monthfile[$i],strpos($monthfile[$i],"_")+1);
				$tmpfilename = substr($tmpfilename, 0, strpos($tmpfilename, "."));
				$tmpfilename = $filename_a[$tmpfilename].".html";
				$e -> attachFile($monthfile[$i],'月报-'.$tmpfilename); 
			}
			$e -> sendMail(); 
			$e -> quitSMTP();
		}
	}


	function systemaccount(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$device_type = get_request('device_type', 0, 1);
		$login_method = get_request('login_method', 0, 1);
		$ip = get_request('ip', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($orderby1)){
			$orderby1 = 'INET_ATON(device_ip)';
		}
		if(strcasecmp($orderby2, 'asc') != 0 ) {
			$orderby2 = 'asc';
		}else{
			$orderby2 = 'desc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($device_type){
			$where .= " AND a.device_type ='".$device_type."'";
		}
		if($login_method){
			$where .= " AND a.login_method ='".$login_method."'";
		}
		if($ip){
			$where .= " AND a.device_ip like '%".$ip."%'";
		}
		$alltem = $this->tem_set->select_all();
		$sql = "SELECT COUNT(*) ct FROM ".$this->devpass_set->get_table_name()." a Where $where";		
		$row_num = $this->sessions_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "SELECT a.*,b.login_method login_method_name,c.device_type device_type_name FROM ".$this->devpass_set->get_table_name()." a LEFT JOIN ".$this->tem_set->get_table_name()." b ON a.login_method=b.id LEFT JOIN ".$this->tem_set->get_table_name()." c ON a.device_type=c.id Where $where ORDER BY $orderby1 $orderby2 ,a.luser ASC";		
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->sessions_set->base_select($sql);
			$str = "日期:\t".$time_start."\t到\t".$time_end."\n";
			$str .= language("序号")."\t".language("服务器IP")."\t".language("主机名")."\t".language("系统")." \t".language("协议")." \t".language("系统用户")."\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['device_ip']."\t".$report['hostname']."\t".$report['device_type_name']."\t".$report['login_method_name']."\t".$report['username'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=SystemAccountReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			ob_start();
			$this->assign('reports', $reports);
			$this->display('systemaccount_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=SystemAccountReport.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->sessions_set->base_select($sql);
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign("alltem", $alltem);
		$this->assign('curr_url', $curr_url);
		$this->assign('device_type', $device_type);
		$this->assign('login_method', $login_method);
		$this->assign('ip', $ip);
		$this->assign('reports', $reports);
		$this->assign('session_num', $row_num);
		$this->assign('number', $number);
		
		$this->display('systemaccount.tpl');
	}

	function appaccount(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'device_ip';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM ".$this->appdevice_set->get_table_name();		
		$row_num = $this->sessions_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$sql = "SELECT b.*,IF(LENGTH(a.username)=0,'空用户',a.username) username FROM ".$this->appdevice_set->get_table_name()." a LEFT JOIN ".$this->apppub_set->get_table_name()." b ON a.apppubid=b.id WHERE b.id IS NOT NULL ORDER BY $orderby1 $orderby2 ,username ASC";		
		
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->sessions_set->base_select($sql);
			$str = "日期:\t".$time_start."\t到\t".$time_end."\n";
			$str .= language("序号")."\t".language("服务器IP")."\t".language("应用名称")."\t".language("应用路径")." \t".language("用户名")." \t".language("URL")."\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['appserverip']."\t".$report['name']."\t".$report['path']."\t".$report['username']."\t".$report['url'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AppAccountReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			ob_start();
			$this->assign('reports', $reports);
			$this->display('appaccount_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AppAccountReport.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->sessions_set->base_select($sql);
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('session_num', $row_num);
		$this->assign('reports', $reports);
		$this->assign('number', $number);
		$this->display('appaccount.tpl');
	}

	function systempriority_process_data($alldev, $type){
		$alltem = $this->tem_set->select_all();
		$allgroup = $this->sgroup_set->select_all();
		$num = count($alldev);
		for($i=0;$i<$num;$i++) {
			foreach($alltem as $tem) {
				if($alldev[$i]['login_method'] == $tem['id']) {
					$alldev[$i]['login_method'] = $tem['login_method'];
				}
				elseif($alldev[$i]['device_type'] == $tem['id']) {
					$alldev[$i]['device_type'] = $tem['device_type'];
				}
			}
			if($allgroup)
			foreach($allgroup as $groupt){
				if($groupt[id]==$alldev[$i][groupid]){
					$alldev[$i][groupname]=$groupt[groupname];
					break;
				}
			}
			if($alldev[$i]['month']  != '') {
				$alldev[$i]['method']  = language('每月').$alldev[$i]['month'].language('日');
			}
			elseif($alldev[$i]['week']  != '') {
				$alldev[$i]['method']  = language('每星期').$alldev[$i]['week'] ;
			}
			elseif($alldev[$i]['user_define']  != '') {
				$alldev[$i]['method']  = language('每隔').$alldev[$i]['user_define'] .language('天');
			}
			if($type=='luser'){
				if($alldev[$i]['luid']){
					$alldev[$i]['webuser']=$alldev[$i]['luname'];
					$alldev[$i]['policyname']=$alldev[$i]['lupolicyname'];
					$alldev[$i]['forbidden_commands_groups']=$alldev[$i]['lufcg'];
					$alldev[$i]['sourceip']=$alldev[$i]['lusourceip'];
					$alldev[$i]['syslogalert']=$alldev[$i]['lusyslogalert'];
					$alldev[$i]['mailalert']=$alldev[$i]['lumailalert'];
					$alldev[$i]['loginlock']=$alldev[$i]['luloginlock'];
					$alldev[$i]['autosu']=$alldev[$i]['luautosu'];
				}elseif($alldev[$i]['ludid']){
					$alldev[$i]['webuser']=$alldev[$i]['ludname'];
					$alldev[$i]['policyname']=$alldev[$i]['ludpolicyname'];
					$alldev[$i]['forbidden_commands_groups']=$alldev[$i]['ludfcg'];
					$alldev[$i]['sourceip']=$alldev[$i]['ludsourceip'];
					$alldev[$i]['syslogalert']=$alldev[$i]['ludsyslogalert'];
					$alldev[$i]['mailalert']=$alldev[$i]['ludmailalert'];
					$alldev[$i]['loginlock']=$alldev[$i]['ludloginlock'];
					$alldev[$i]['autosu']=$alldev[$i]['ludautosu'];
				}elseif($alldev[$i]['lgid']){
					$alldev[$i]['webuser']=$alldev[$i]['lgname'].'('.language('运维组').')';
					$alldev[$i]['policyname']=$alldev[$i]['lgpolicyname'];
					$alldev[$i]['forbidden_commands_groups']=$alldev[$i]['lgfcg'];
					$alldev[$i]['sourceip']=$alldev[$i]['lgsourceip'];
					$alldev[$i]['syslogalert']=$alldev[$i]['lgsyslogalert'];
					$alldev[$i]['mailalert']=$alldev[$i]['lgmailalert'];
					$alldev[$i]['loginlock']=$alldev[$i]['lgloginlock'];
					$alldev[$i]['autosu']=$alldev[$i]['lgautosu'];
				}elseif($alldev[$i]['lgdid']){
					$alldev[$i]['webuser']=$alldev[$i]['lgdname'].'('.language('运维组').')';
					$alldev[$i]['policyname']=$alldev[$i]['lgdpolicyname'];
					$alldev[$i]['forbidden_commands_groups']=$alldev[$i]['lgdfcg'];
					$alldev[$i]['sourceip']=$alldev[$i]['ldgsourceip'];
					$alldev[$i]['syslogalert']=$alldev[$i]['ldgsyslogalert'];
					$alldev[$i]['mailalert']=$alldev[$i]['ldgmailalert'];
					$alldev[$i]['loginlock']=$alldev[$i]['ldgloginlock'];
					$alldev[$i]['autosu']=$alldev[$i]['ldgautosu'];
				}
			}elseif($type=='lgroup'){
				if($alldev[$i]['lgid']){
					$alldev[$i]['gname']=$alldev[$i]['lgname'];
					$alldev[$i]['policyname']=$alldev[$i]['lgpolicyname'];
					$alldev[$i]['forbidden_commands_groups']=$alldev[$i]['lgfcg'];
					$alldev[$i]['sourceip']=$alldev[$i]['lgsourceip'];
					$alldev[$i]['syslogalert']=$alldev[$i]['lgsyslogalert'];
					$alldev[$i]['mailalert']=$alldev[$i]['lgmailalert'];
					$alldev[$i]['loginlock']=$alldev[$i]['lgloginlock'];
					$alldev[$i]['autosu']=$alldev[$i]['lgautosu'];
				}elseif($alldev[$i]['lgdid']){
					$alldev[$i]['gname']=$alldev[$i]['lgdname'];
					$alldev[$i]['policyname']=$alldev[$i]['lgdpolicyname'];
					$alldev[$i]['forbidden_commands_groups']=$alldev[$i]['lgdfcg'];
					$alldev[$i]['sourceip']=$alldev[$i]['lgdsourceip'];
					$alldev[$i]['syslogalert']=$alldev[$i]['lgdsyslogalert'];
					$alldev[$i]['mailalert']=$alldev[$i]['lgdmailalert'];
					$alldev[$i]['loginlock']=$alldev[$i]['lgdloginlock'];
					$alldev[$i]['autosu']=$alldev[$i]['lggautosu'];
				}
			}
			if(empty($alldev[$i]['webuser'])){
				$alldev[$i]['webuser']='空用户';
			}
			if(empty($alldev[$i]['gname'])){
				$alldev[$i]['gname']='NULL';
			}
			if(empty($alldev[$i]['groupname'])){
				$alldev[$i]['groupname']='NULL';
			}
			if(empty($alldev[$i]['policyname'])){
				$alldev[$i]['policyname']='NULL';
			}
			if(empty($alldev[$i]['sourceip'])){
				$alldev[$i]['sourceip']='NULL';
			}
			if(empty($alldev[$i]['forbidden_commands_groups'])){
				$alldev[$i]['forbidden_commands_groups']='NULL';
			}			
			if(empty($alldev[$i]['lastdate'])){
				$alldev[$i]['lastdate']='NULL';
			}
			if(empty($alldev[$i]['device_ip'])){
				$alldev[$i]['device_ip']='NULL';
			}
			if(empty($alldev[$i]['username'])){
				$alldev[$i]['username']='空用户';
			}
		}
		return $alldev;
	}

	function systempriority() {
		$back = get_request('back');
		if($back){
			if(is_array($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'])){
				$_GET = array_merge($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'], $_GET);
				$_SERVER['QUERY_STRING'] = http_build_query($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
			}
		}else{
			$_SESSION[$_GET['controller'].'_'.$_GET['action'].'_'.'QUERY_STRING'] = null;
		}
		$page_num = get_request('page');
		$ip = get_request('ip',1,1) ? get_request('ip',1,1) : get_request('ip',0,1);
		$s_user = get_request('s_user',1,1) ? get_request('s_user',1,1) : get_request('s_user',0,1);
		$user = get_request('user',1,1) ? get_request('user',1,1) : get_request('user',0,1);
		$group = get_request('group',1,1) ? get_request('group',1,1) : get_request('group',0,1);
		$type = get_request('type', 0, 1);
		$derive = get_request('derive', 0, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($orderby1)){
			$orderby1 = 'device_ip';
		}
		if(strcasecmp($orderby2, 'asc') != 0 ) {
			$orderby2 = 'asc';
		}else{
			$orderby2 = 'desc';
		}
		$this->assign("orderby2", $orderby2);

		if(empty($type)){
			$type='luser';
		}
		if($ip != '') {
			$where .= " AND device_ip LIKE '%$ip%'";
		}

		if($s_user != '') {
			$where .= " AND username= '$s_user'";
		}
		if($user != '') {				
			$member = $this->member_set->select_all(" username='".$user."'");
			$member = $member[0];
			if(empty($member)){
				alert_and_back('该用户不存在 ','admin.php?controller=admin_pro&action=dev_priority_search');
				exit;
			}
			$whereuid = " AND uid=".$member['uid'];
		}
		if($group != '') {			
			$groupinfo = $this->usergroup_set->select_all(" GroupName='".$group."'");
			$groupinfo= $groupinfo[0];
			if(empty($groupinfo)){
				alert_and_back('该组不存在 ','admin.php?controller=admin_pro&action=dev_priority_search');
				exit;
			}
			$wheregid = " AND groupid=".(int)$groupinfo['id'];
		}
		
		if($_SESSION['ADMIN_LEVEL'] == 3) {
			$where .= " AND id IN ($_SESSION[DEVS])";
		}
		
		$tem = $this->tem_set->select_by_id($dev['template_id']);
		$this->assign('login_method',$tem['device_type'].'/'.$tem['login_method']);
		if($type=='luser'){
			
			$sql = "SELECT devicesid FROM ".$this->luser_set->get_table_name()." WHERE 1=1 ";
			if($member['uid']){
				$sql .= " AND memberid=".$member['uid'];
			}
			$sql .= " UNION SELECT devicesid FROM ".$this->resgroup_set->get_table_name()." WHERE groupname IN (SELECT b.groupname FROM ".$this->luser_resourcegrp_set->get_table_name()." a LEFT JOIN ".$this->resgroup_set->get_table_name()." b ON a.resourceid=b.id WHERE 1=1 ";
			if($member['uid']){
				$sql .= " AND  a.memberid=".$member['uid'];
			}
			$sql .= ")";
			$sql .= " UNION SELECT devicesid FROM ".$this->lgroup_set->get_table_name()."  WHERE 1=1 ";			
			if($member['uid']){
				$sql .= " AND  groupid=".$member['groupid'];
			}
			$sql .= " UNION SELECT devicesid FROM ".$this->resgroup_set->get_table_name()." WHERE groupname IN (SELECT b.groupname FROM ".$this->lgroup_resourcegrp_set->get_table_name()." a LEFT JOIN ".$this->resgroup_set->get_table_name()." b ON a.resourceid=b.id WHERE 1=1 ";
			if($member['uid']){
				$sql .= " AND  a.groupid=".$member['groupid'];
			}
			$sql .= ")";
			$alldevid = $this->member_set->base_select("$sql");
			for($i=0; $i<count($alldevid); $i++){
				$alldevsid[]=$alldevid[$i]['devicesid'];
			}
			if(empty($alldevsid)){
				$alldevsid[0]=0;
			}
			$sql ="";
			$sql = " SELECT *,if(luid,1,if(ludid,2,if(lgid,3,4))) AS orderby FROM (
						SELECT id,device_ip,username,login_method FROM devices WHERE id IN(".implode(',', $alldevsid).") ".$where.")ds ";
			$sql .= "	LEFT JOIN (
							SELECT '1' as l11,l1.id luid,l1.devicesid ludevicesid,l1.weektime lupolicyname,l1.forbidden_commands_groups lufcg,l1.sourceip lusourceip,l1.syslogalert lusyslogalert, l1.mailalert lumailalert, l1.loginlock luloginlock,l1.autosu luautosu,m.username luname,m.uid,m.groupid lugroupid FROM luser l1 
							LEFT JOIN member m ON l1.memberid=m.uid  WHERE m.uid IS NOT NULL ".$whereuid." 
						) lu ON ds.id=lu.ludevicesid ";
			$sql .= "	LEFT JOIN (
							SELECT '2' as l12,l2.id ludid,r.devicesid luddevicesid, l2.resourceid luresourceid,l2.weektime ludpolicyname,l2.forbidden_commands_groups ludfcg,l2.sourceip ludsourceip,l2.syslogalert ludsyslogalert, l2.mailalert ludmailalert, l2.loginlock ludloginlock,l2.autosu ludautosu,m.username ludname FROM ( 
									SELECT ra.id,ra.groupname,rb.devicesid FROM resourcegroup ra 
									LEFT JOIN resourcegroup rb on ra.groupname=rb.groupname where ra.devicesid=0 and rb.devicesid!=0 
							) r 
							LEFT JOIN luser_resourcegrp l2 ON r.id=l2.resourceid LEFT JOIN member m ON l2.memberid=m.uid  WHERE m.uid IS NOT NULL ".$whereuid.") lud ON ds.id=lud.luddevicesid ";
			$sql .= "	LEFT JOIN (
							SELECT '3' as l13,l3.id lgid,l3.devicesid lgdevicesid,l3.groupid lggroupid,l3.weektime lgpolicyname,l3.forbidden_commands_groups lgfcg,l3.sourceip lgsourceip,l3.syslogalert lgsyslogalert, l3.mailalert lgmailalert, l3.loginlock lgloginlock,l3.autosu lgautosu,ug.GroupName lgname FROM lgroup l3  
							LEFT JOIN usergroup ug ON l3.groupid=ug.id  WHERE ug.id IS NOT NULL
						) lg ON ds.id=lg.lgdevicesid ";
			$sql .= "	LEFT JOIN (
							SELECT '4' as l14,l4.id lgdid,r.devicesid lgddevicesid,l4.resourceid lgresourceid,l4.weektime lgdpolicyname,l4.forbidden_commands_groups lgdfcg,l4.sourceip ldgsourceip,l4.syslogalert ldgsyslogalert, l4.mailalert ldgmailalert, l4.loginlock ldgloginlock,l4.autosu ldgautosu,ug.GroupName lgdname,l4.groupid ldgresgrpid FROM( 
								SELECT ra.id,ra.groupname,rb.devicesid FROM resourcegroup ra 
									LEFT JOIN resourcegroup rb on ra.groupname=rb.groupname where ra.devicesid=0 and rb.devicesid!=0 
							) r 
							LEFT JOIN lgroup_resourcegrp l4 ON r.id=l4.resourceid 
							LEFT JOIN usergroup ug ON l4.groupid=ug.id  WHERE ug.id IS NOT NULL
						) lgd ON ds.id=lgd.lgddevicesid ";
			if($member['uid']){
				$sql .= " AND lu.lugroupid=lgd.ldgresgrpid";
			}

		}elseif($type=='lgroup'){
			$sql .= " SELECT devicesid FROM ".$this->lgroup_set->get_table_name()."  WHERE 1=1 ";			
			if($groupinfo['id']){
				$sql .= " AND  groupid=".$groupinfo['id'];
			}
			$sql .= " UNION SELECT devicesid FROM ".$this->resgroup_set->get_table_name()." WHERE groupname IN (SELECT b.groupname FROM ".$this->lgroup_resourcegrp_set->get_table_name()." a LEFT JOIN ".$this->resgroup_set->get_table_name()." b ON a.resourceid=b.id WHERE 1=1 ";
			if($groupinfo['id']){
				$sql .= " AND  a.groupid=".$groupinfo['id'];
			}
			$sql .= ")";
			$alldevid = $this->member_set->base_select($sql);
			for($i=0; $i<count($alldevid); $i++){
				$alldevsid[]=$alldevid[$i]['devicesid'];
			}
			if(empty($alldevsid)){
				$alldevsid[0]=0;
			}
			$sql = " SELECT *,if(lgid,1,2) AS orderby  FROM (
						SELECT d.*,s.groupid FROM  (
							SELECT id,device_ip,username,login_method FROM devices WHERE id IN(".implode(',', $alldevsid).") ".$where." "."
						) d 
					 LEFT JOIN servers s ON d.device_ip=s.device_ip
					 ) ds ";
			$sql .= "LEFT JOIN (
						SELECT l3.id lgid,l3.devicesid lgdevicesid,l3.weektime lgpolicyname,l3.forbidden_commands_groups lgfcg,l3.sourceip lgsourceip,l3.syslogalert lgsyslogalert, l3.mailalert lgmailalert, l3.loginlock lgloginlock,l3.autosu lgautosu,l3.groupid groupid3,ug.GroupName lgname FROM lgroup l3  
						LEFT JOIN usergroup ug ON l3.groupid=ug.id WHERE ug.id IS NOT NULL ".$wheregid."
					 ) lg ON ds.id=lg.lgdevicesid ";
			$sql .= "LEFT JOIN (
						SELECT l4.id lgdid,r.devicesid lgddevicesid,l4.weektime lgdpolicyname,l4.forbidden_commands_groups lgdfcg,l4.sourceip lgdsourceip,l4.syslogalert lgdsyslogalert, l4.mailalert lgdmailalert, l4.loginlock lgdloginlock,l4.autosu lgdautosu,l4.groupid groupid4,ug.GroupName lgdname FROM ( 
							SELECT ra.id,ra.groupname,rb.devicesid FROM resourcegroup ra 
									LEFT JOIN resourcegroup rb on ra.groupname=rb.groupname where ra.devicesid=0 and rb.devicesid!=0 
							) r 
						LEFT JOIN lgroup_resourcegrp l4 ON r.id = l4.resourceid
						LEFT JOIN usergroup ug ON l4.groupid=ug.id WHERE ug.id IS NOT NULL ".$wheregid."
					 ) lgd ON ds.id=lgd.lgddevicesid ";

		}
		$result = $this->server_set->query("SELECT count(*) AS row_num FROM (".$sql.") t ");
		$row = mysql_fetch_assoc($result);
		$row_num=$row['row_num'];
		
		$newpager = new my_pager($row_num, $page_num, 20, 'page');
		//$alldev = $this->server_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage, $where,$orderby,$orderby2);
		$sql = " $sql ORDER BY $orderby1 $orderby2 , IFNULL(luname,IFNULL(ludname, IFNULL(lgname,lgdname))) ASC ";
		if($derive==1){
			$reports = $this->server_set->base_select($sql);
			$reports=$this->systempriority_process_data($reports, $type);
			$str = language("序号")."\t".(($type == 'luser') ? '运维账号' : '运维组')."\t".language("设备IP")."\t".language("系统用户")." \t".language("黑名单")." \t".language("周组策略 ")." \t".language("来源IP")." \t".language("自动为超级用户")." \t".language("SYSLOG告警")." \t".language("Mail告警")." \t".language("账号锁定")."\t".(($type == 'luser') ? '上次登录'." \t" : '').language("协议")."\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".(($type == 'luser') ? $report['webuser'] :$report['gname'])."\t".$report['device_ip']."\t".$report['username']."\t".$report['forbidden_commands_groups']."\t".$report['policyname']."\t".$report['sourceip']."\t".($report['autosu'] ? '是' : '否')."\t".($report['syslogalert'] ? '是' : '否')."\t".($report['mailalert'] ? '是' : '否')."\t".($report['loginlock'] ? '是' : '否')."\t".(($type == 'luser') ? $report['lastdate']." \t" : '').$report['login_method'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=SystemPriorityReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			$reports=$this->systempriority_process_data($reports, $type);
			ob_start();
			$this->assign('alldev', $reports);
			$this->assign('type', $type);
			$this->assign('ip', $ip);
			$this->assign('s_user', $s_user);
			$this->assign('user', $user);
			$this->assign('group', $group);
			$this->display('systempriority_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=SystemPriorityReport.html"); 
			echo $str;
			exit();
		}
		
		$sql .= "LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$alldev = $this->server_set->base_select($sql);
	
		$alldev=$this->systempriority_process_data($alldev, $type);
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		
		}
		parse_str($_SERVER['QUERY_STRING'], $_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
		//echo '<pre>';print_r($alldev);echo '</pre>';
		$this->assign('curr_url', $curr_url);
		$this->assign('title', language('服务器列表'));
		$this->assign('alldev', $alldev);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('type', $type);
		$this->assign('ip', $ip);
		$this->assign('s_user', $s_user);
		$this->assign('user', $user);
		$this->assign('group', $group);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->display('systempriority.tpl');
	}

	function apppriority_process_data($alldev, $type){
		$alltem = $this->tem_set->select_all();
		$allgroup = $this->sgroup_set->select_all();
		$num = count($alldev);
		for($i=0;$i<$num;$i++) {
			
			if($allgroup)
			foreach($allgroup as $groupt){
				if($groupt[id]==$alldev[$i][groupid]){
					$alldev[$i][groupname]=$groupt[groupname];
					break;
				}
			}
			if($type=='luser'){
				if($alldev[$i]['luid']){
					$alldev[$i]['webuser']=$alldev[$i]['luname'];
				}elseif($alldev[$i]['lurid']){
					$alldev[$i]['webuser']=$alldev[$i]['lurname'];
				}elseif($alldev[$i]['ludid']){
					$alldev[$i]['webuser']=$alldev[$i]['ludname'];
				}elseif($alldev[$i]['lgid']){
					$alldev[$i]['webuser']=$alldev[$i]['lgname'].'('.language('运维组').')';
				}elseif($alldev[$i]['lgdid']){
					$alldev[$i]['webuser']=$alldev[$i]['lgdname'].'('.language('运维组').')';
				}
			}elseif($type=='lgroup'){
				if($alldev[$i]['lgid']){
					$alldev[$i]['gname']=$alldev[$i]['lgname'];
				}elseif($alldev[$i]['lgdid']){
					$alldev[$i]['gname']=$alldev[$i]['lgdname'];
				}
			}
			if(empty($alldev[$i]['webuser'])){
				$alldev[$i]['webuser']='空用户';
			}
			if(empty($alldev[$i]['gname'])){
				$alldev[$i]['gname']='NULL';
			}
			if(empty($alldev[$i]['groupname'])){
				$alldev[$i]['groupname']='NULL';
			}
			if(empty($alldev[$i]['device_ip'])){
				$alldev[$i]['device_ip']='NULL';
			}
			if(empty($alldev[$i]['username'])){
				$alldev[$i]['username']='空用户';
			}
		}
		return $alldev;
	}

	function apppriority() {
		$back = get_request('back');
		if($back){
			if(is_array($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'])){
				$_GET = array_merge($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'], $_GET);
				$_SERVER['QUERY_STRING'] = http_build_query($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
			}
		}else{
			$_SESSION[$_GET['controller'].'_'.$_GET['action'].'_'.'QUERY_STRING'] = null;
		}
		$page_num = get_request('page');
		$device_ip = get_request('device_ip',1,1) ? get_request('device_ip',1,1) : get_request('device_ip',0,1);
		$appserverip = get_request('appserverip',1,1) ? get_request('appserverip',1,1) : get_request('appserverip',0,1);
		$s_user = get_request('s_user',1,1) ? get_request('s_user',1,1) : get_request('s_user',0,1);
		$user = get_request('user',1,1) ? get_request('user',1,1) : get_request('user',0,1);
		$group = get_request('group',1,1) ? get_request('group',1,1) : get_request('group',0,1);
		$type = get_request('type', 0, 1);
		$derive = get_request('derive', 0, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($orderby1)){
			$orderby1 = 'appserverip';
		}
		if(strcasecmp($orderby2, 'asc') != 0 ) {
			$orderby2 = 'asc';
		}else{
			$orderby2 = 'desc';
		}
		$this->assign("orderby2", $orderby2);

		if(empty($type)){
			$type='luser';
		}
		if($appserverip != '') {
			$where .= " AND pub.appserverip LIKE '%$appserverip%'";
		}

		if($device_ip != '') {
			$where .= " AND d.device_ip LIKE '%$device_ip%'";
		}

		if($s_user != '') {
			$where .= " AND username= '$s_user'";
		}
		if($user != '') {				
			$member = $this->member_set->select_all(" username='".$user."'");
			$member = $member[0];
			if(empty($member)){
				alert_and_back('该用户不存在 ','admin.php?controller=admin_pro&action=app_priority_search');
				exit;
			}
			$whereuid = " AND uid=".$member['uid'];
		}
		if($group != '') {			
			$groupinfo = $this->usergroup_set->select_all(" GroupName='".$group."'");
			$groupinfo= $groupinfo[0];
			if(empty($groupinfo)){
				alert_and_back('该组不存在 ','admin.php?controller=admin_pro&action=app_priority_search');
				exit;
			}
			$wheregid = " AND groupid=".(int)$groupinfo['id'];
		}
		
		if($_SESSION['ADMIN_LEVEL'] == 3) {
			$where .= " AND id IN ($_SESSION[DEVS])";
		}
		
		$tem = $this->tem_set->select_by_id($dev['template_id']);
		$this->assign('login_method',$tem['device_type'].'/'.$tem['login_method']);
		if($type=='luser'){
			
			$sql = "SELECT appdeviceid FROM ".$this->appmember_set->get_table_name()." WHERE 1=1 ";
			if($member['uid']){
				$sql .= " AND memberid=".$member['uid'];
			}
			$sql .= " UNION select appdevicesid FROM appresourcegroup WHERE appgroupname IN(select ag.appgroupname FROM luser_appresourcegrp la LEFT JOIN appresourcegroup ag ON la.appresourceid=ag.id WHERE 1";
			if($member['uid']){
				$sql .= " AND memberid=".$member['uid'];
			}
			$sql .= ")";
			
			$sql .= " UNION SELECT appdeviceid FROM ".$this->appgroup_set->get_table_name()."  WHERE 1=1 ";			
			if($member['uid']){
				$sql .= " AND  groupid=".$member['groupid'];
			}
			
			$alldevid = $this->member_set->base_select($sql);
			for($i=0; $i<count($alldevid); $i++){
				$alldevsid[]=$alldevid[$i]['appdeviceid'];
			}
			if(empty($alldevsid)){
				$alldevsid[0]=0;
			}
			$sql ="";
			$sql = " SELECT *,if(luid,1,if(luruid,2,if(lgid,3,4))) AS orderby FROM (
						SELECT d.id,d.username,d.change_password,d.enable,d.device_ip,pub.id apppubid,pub.appserverip,pub.name appname FROM appdevices d LEFT JOIN apppub pub ON d.apppubid=pub.id WHERE d.id IN(".implode(',', $alldevsid).") ".$where."
						)ds ";
			$sql .= "	LEFT JOIN (
							SELECT '1' as l11,l1.id luid,l1.appdeviceid ludevicesid,m.username luname,m.uid,m.groupid lugroupid FROM appmember l1 
							LEFT JOIN member m ON l1.memberid=m.uid  WHERE m.uid IS NOT NULL ".$whereuid." 
						) lu ON ds.id=lu.ludevicesid ";
			$sql .= "	LEFT JOIN (
							SELECT '2' as l12,l2.appresourceid lurid,l2.appdevicesid lurdevicesid,m.username lurname,m.uid luruid,m.groupid lurgroupid FROM (select ag.appdevicesid,la.memberid,la.appresourceid FROM (SELECT a.id,b.appdevicesid FROM appresourcegroup a LEFT JOIN appresourcegroup b ON a.appgroupname=b.appgroupname WHERE a.appdevicesid=0 AND b.appdevicesid!=0) ag LEFT JOIN luser_appresourcegrp la  ON la.appresourceid=ag.id) l2 
							LEFT JOIN member m ON l2.memberid=m.uid  WHERE m.uid IS NOT NULL ".$whereuid." 
						) lur ON ds.id=lur.lurdevicesid ";
			
			$sql .= "	LEFT JOIN (
							SELECT '3' as l13,l3.id lgid,l3.appdeviceid lgdevicesid, ug.GroupName lgname FROM appgroup l3  
							LEFT JOIN usergroup ug ON l3.groupid=ug.id  WHERE ug.id IS NOT NULL
						) lg ON ds.id=lg.lgdevicesid ";

		}elseif($type=='lgroup'){
			$sql .= " SELECT appdeviceid FROM ".$this->appgroup_set->get_table_name()."  WHERE 1=1 ";			
			if($groupinfo['id']){
				$sql .= " AND  groupid=".$groupinfo['id'];
			}
			$alldevid = $this->member_set->base_select($sql);
			for($i=0; $i<count($alldevid); $i++){
				$alldevsid[]=$alldevid[$i]['appdeviceid'];
			}
			if(empty($alldevsid)){
				$alldevsid[0]=0;
			}
			$sql = " SELECT *,if(lgid,1,2) AS orderby  FROM (
						SELECT d.*,pub.appserverip,pub.name appname FROM  (
							SELECT id,username,change_password,enable,apppubid FROM appdevices WHERE id IN(".implode(',', $alldevsid).") ".$where." "."
						) d 
					 LEFT JOIN apppub pub ON d.apppubid=pub.id
					 ) ds ";
			$sql .= "LEFT JOIN (
						SELECT l3.id lgid,l3.appdeviceid lgdevicesid,l3.groupid groupid3,ug.GroupName lgname FROM appgroup l3  
						LEFT JOIN usergroup ug ON l3.groupid=ug.id WHERE ug.id IS NOT NULL ".$wheregid."
					 ) lg ON ds.id=lg.lgdevicesid ";
			$sql .= "	LEFT JOIN (
							SELECT l2.id lgrid,l2.appdevicesid lgrdevicesid,l2.groupid groupid2,ug.GroupName lgrname FROM (select ag.appdevicesid,la.groupid,la.id FROM (SELECT a.id,b.appdevicesid FROM appresourcegroup a LEFT JOIN appresourcegroup b ON a.appgroupname=b.appgroupname WHERE a.appdevicesid=0 AND b.appdevicesid!=0) ag LEFT JOIN lgroup_appresourcegrp la  ON la.appresourceid=ag.id) l2 
							LEFT JOIN usergroup ug ON l2.groupid=ug.id WHERE ug.id IS NOT NULL ".$wheregid." 
						) lur ON ds.id=lur.lgrdevicesid ";

		}
		$result = $this->server_set->query("SELECT count(*) AS row_num FROM (".$sql.") t ");
		$row = mysql_fetch_assoc($result);
		$row_num=$row['row_num'];
		$newpager = new my_pager($row_num, $page_num, 20, 'page');
		//$alldev = $this->server_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage, $where,$orderby,$orderby2);
		$sql  = " $sql ORDER BY $orderby1 $orderby2, IFNULL(luname,IFNULL(lurname, lgname)) ASC ";
		if($derive==1){
			$reports = $this->server_set->base_select($sql);
			$reports=$this->apppriority_process_data($reports, $type);
			$str = language("序号")."\t".(($type == 'luser') ? '运维账号' : '运维组')."\t".language("设备IP")."\t".language("应用发布IP")." \t".language("应用名称")." \t".language("应用用户名")." \t".language("自动修改密码")." \t".language("激活")."\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".(($type == 'luser') ? $report['webuser'] :$report['gname'])."\t".$report['device_ip']."\t".$report['appserverip']."\t".$report['appname']."\t".$report['username']."\t".($report['change_password'] ? '是' : '否')."\t".($report['enable'] ? '是' : '否');
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AppPriorityReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			$reports=$this->apppriority_process_data($reports, $type);
			ob_start();
			$this->assign('alldev', $reports);
			$this->assign('type', $type);
			$this->assign('ip', $ip);
			$this->assign('s_user', $s_user);
			$this->assign('user', $user);
			$this->assign('group', $group);
			$this->display('apppriority_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=SystemPriorityReport.html"); 
			echo $str;
			exit();
		}
		
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$alldev = $this->server_set->base_select($sql);
		
		$alldev = $this->apppriority_process_data($alldev, $type);
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		
		}
		parse_str($_SERVER['QUERY_STRING'], $_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);

		//echo '<pre>';print_r($alldev);echo '</pre>';
		$this->assign('curr_url', $curr_url);
		$this->assign('title', language('服务器列表'));
		$this->assign('alldev', $alldev);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('type', $type);
		$this->assign('ip', $ip);
		$this->assign('s_user', $s_user);
		$this->assign('user', $user);
		$this->assign('group', $group);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->display('apppriority.tpl');
	}

	function admin_log() {
		$page_num = get_request('page');
		$luser = get_request('luser', 1, 1);
		$operation = get_request('operation', 1, 1);
		$administrator = get_request('administrator', 1, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		$derive = get_request('derive', 0, 1);
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		$where = '1=1';
		if($start){
			$where .= " AND optime >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND optime <='".$end." 23:59:59'";
		}
		if(empty($orderby1)){
			$orderby1 = 'optime';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);

		if($luser){
			$where .= " AND luser='$luser'" ;
		}
		if($operation){
			$where .= " AND action='$operation'" ;
		}
		if($administrator){
			$where .= " AND administrator='$administrator'" ;
		}
		$row_num = $this->admin_log_set->select_count($where);
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports=$this->admin_log_set->select_all($where, $orderby1, $orderby2);
			$str = "日期:\t".$start."\t到\t".$end."\n";
			$str .= language("序号")."\t".language("管理员")."\t".language("堡垒用户")."\t".language("操作")." \t".language("资源")." \t".language("资源用户")." \t".language("操作时间")."\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['administrator']."\t".$report['luser']."\t".$report['action']."\t".$report['resource']."\t".$report['resource_user']."\t".$report['optime'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AdminLogReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports=$this->admin_log_set->select_all($where, $orderby1, $orderby2);
			ob_start();
			$this->assign('alldev', $reports);
			$this->assign('type', $type);
			$this->assign('ip', $ip);
			$this->assign('s_user', $s_user);
			$this->assign('user', $user);
			$this->assign('group', $group);
			$this->display('adminlog_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AdminLogReport.html"); 
			echo $str;
			exit();
		}



		$allmember = $this->admin_log_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage,$where, $orderby1, $orderby2);
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		
		}
		parse_str($_SERVER['QUERY_STRING'], $_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);

		//echo '<pre>';print_r($alldev);echo '</pre>';
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		
		$out = $allmember;

		for($i=0;$i<count($out);$i++) {
			$out[$i]['username'] = $allmember[$i]['username'];
		}
		$this->assign('allmember', $out);
		$this->display('adminlog_report.tpl');
	}

	function devloginreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM (SELECT * FROM ".$this->sessions_set->get_table_name()." WHERE $where  GROUP BY if(locate(':',addr)=0, addr,left(addr, locate(':',addr)-1)),user,luser,type) t ";		
		$row_num = $this->sessions_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		
		$sql = "SELECT a.luser,a.type,a.user,if(locate(':',addr)=0, addr,left(addr, locate(':',addr)-1)) device_ip, MIN(start) mstart, MAX(start) mend,IFNULL(COUNT(*),0) ct FROM ".$this->sessions_set->get_table_name()." a LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->commands_set->get_table_name()."  GROUP BY sid) bb ON bb.sid=a.sid WHERE $where GROUP BY if(locate(':',addr)<0, addr,left(addr, locate(':',addr)-1)),user,luser,type";
		$sql .= " UNION SELECT a1.luser,a1.type,a1.user,if(locate(':',addr)=0, addr,left(addr, locate(':',addr)-1)) device_ip, MIN(start) mstart, MAX(start) mend,IFNULL(COUNT(*),0) ct FROM ".$this->rdp_set->get_table_name()." a1 LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->rdpinput_set->get_table_name()."  GROUP BY sid) bb1 ON bb1.sid=a1.sid WHERE $where GROUP BY if(locate(':',addr)<0, addr,left(addr, locate(':',addr)-1)),user,luser,type";
		$sql .= " UNION SELECT a2.radius_user luser,'sftp' type,a2.sftp_user user,if(locate(':',svraddr)=0, svraddr,left(svraddr, locate(':',svraddr)-1)) device_ip, MIN(start) mstart, MAX(start) mend,IFNULL(COUNT(*),0) ct FROM ".$this->sftpsession_set->get_table_name()." a2 LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->sftpcmd_set->get_table_name()."  GROUP BY sid) bb2 ON bb2.sid=a2.sid WHERE $where GROUP BY if(locate(':',svraddr)<0, svraddr,left(svraddr, locate(':',svraddr)-1)),sftp_user,radius_user";
		$sql .= " UNION SELECT a3.radius_user luser,'ftp' type,a3.ftp_user user,if(locate(':',svraddr)=0, svraddr,left(svraddr, locate(':',svraddr)-1)) device_ip, MIN(start) mstart, MAX(start) mend,IFNULL(COUNT(*),0) ct FROM ".$this->ftpsession_set->get_table_name()." a3 LEFT JOIN (SELECT COUNT(*) ct,sid FROM ".$this->ftpcmd_set->get_table_name()."  GROUP BY sid) bb3 ON bb3.sid=a3.sid WHERE $where GROUP BY if(locate(':',svraddr)<0, svraddr,left(svraddr, locate(':',svraddr)-1)),ftp_user,radius_user ";
		
		$sql = "SELECT *,s.hostname FROM ($sql) t LEFT JOIN ".$this->server_set->get_table_name()." s ON t.device_ip=s.device_ip  ORDER BY $orderby1 $orderby2 ";
		
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->sessions_set->base_select($sql);
			$str = "日期:\t".$start."\t到\t".$end."\n";
			$str .= language("序号")."\t".language("运维用户")."\t".language("服务器IP")."\t".language("主机名")." \t".language("协议")."\t".language("系统用户")." \t".language("登录次数")." \t".language("开始日期")." \t".language("结束日期")."\t\n";
			$id=1;
			if($reports)
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['luser']."\t".$report['device_ip']."\t".$report['hostname']."\t".$report['type']."\t".$report['user']."\t".$report['ct']."\t".$report['mstart']."\t".$report['mend'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=DevLoginReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->sessions_set->base_select($sql);
			ob_start();
			$this->assign('reports', $reports);
			$this->display('devloginreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=DevLoginReport.html"); 
			echo $str;
			exit();
		}
		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->sessions_set->base_select($sql);
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('reports', $reports);
		$this->assign('number', $number);
		$this->assign('session_num', $row_num);
		
		$this->display('devloginreport.tpl');
	}

	function apploginreport(){
		global $_CONFIG;
		$page_num = get_request('page');
		$number = get_request('number');
		$start = get_request('f_rangeStart', 0, 1);
		$end = get_request('f_rangeEnd', 0, 1);
		$derive = get_request('derive');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($start)&&empty($end)){
			$start = date('Y-m-d', mktime(0,0,0,date('m')-1,date('d'),date('Y')));
			$end = date('Y-m-d');
		}
		if(empty($orderby1)){
			$orderby1 = 'ct';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$where = '1=1';
		if($start){
			$where .= " AND start >='".$start." 00:00:00'";
		}
		if($end){
			$where .= " AND start <='".$end." 23:59:59'";
		}
		$sql = "SELECT COUNT(*) ct FROM (SELECT * FROM ".$this->appcomm_set->get_table_name()." WHERE $where  GROUP BY serverip,appname,memberid) t ";		
		$row_num = $this->appcomm_set->base_select($sql);	
		$row_num = $row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, 20, 'page');
		$sql = "SELECT a.*,addr device_ip,count(*) ct, MIN(start) mstart, MAX(start) mend,b.username user,c.url FROM ".$this->appcomm_set->get_table_name()." a LEFT JOIN ".$this->member_set->get_table_name()." b ON a.memberid=b.uid LEFT JOIN ".$this->apppub_set->get_table_name()." c ON a.serverip=c.appserverip and a.appname=c.name WHERE $where GROUP BY serverip,appname,memberid ORDER BY $orderby1 $orderby2 ";	
				
		$this->assign('f_rangeStart', $start);
		$this->assign('f_rangeEnd', $end);
		if($derive==1){
			$reports = $this->appcomm_set->base_select($sql);			
			$str = "日期:\t".$start."\t到\t".$end."\n";
			$str .= language("序号")."\t".language("运维用户")."\t".language("服务器IP")."\t".language("应用名称")." \t".language("程序路径")." \t".language("URL")." \t".language("登录次数")." \t".language("开始日期")." \t".language("结束日期")."\t\n";
			$id=1;
			foreach ($reports AS $report){		
				$str .= ($id++)."\t".$report['user']."\t".$report['serverip']."\t".$report['appname']."\t".$report['apppath']."\t".$report['url']."\t".$report['ct']."\t".$report['mstart']."\t".$report['mend'];
				$str .= "\n";
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AppLoginReport.xls"); 
			echo iconv("UTF-8", "GB2312", $str);
			exit();
		}else if($derive==2){
			$reports = $this->appcomm_set->base_select($sql);			
			ob_start();
			$this->assign('reports', $reports);
			$this->display('apploginreport_for_export.tpl');
			$str = ob_get_clean();
			if($_GET['derive_forcron']){
				echo $str;
				return ;
			}
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=AppLoginReport.html"); 
			echo $str;
			exit();
		}

		$sql .= " LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$reports = $this->appcomm_set->base_select($sql);			
		
		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		}
		$this->assign('curr_url', $curr_url);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);
		$this->assign('reports', $reports);
		$this->assign('session_num', $row_num);
		$this->assign('number', $number);
		
		$this->display('apploginreport.tpl');
	}

	function downloadcronreport()
    {
        global $_CONFIG;
		$derive = get_request('derive');
		$page_num = get_request('page');
        $where = "1=1";
		if($derive==1){
			$id = get_request('id');
			$report = $this->crontab_report_file_set->select_by_id($id);
			Header('Cache-Control: private, must-revalidate, max-age=0');
			Header("Content-type: application/octet-stream"); 
			Header("Content-Disposition: attachment; filename=".iconv("UTF-8", "GB2312", $report['title']).".html"); 
			echo file_get_contents($report['filepath']);
			exit();
		}
        $row_num  = $this->crontab_report_file_set->select_count($where);
        $newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
        $this->assign('page_list', $newpager->showSerialList());
        $this->assign('log_num', $row_num);
        $this->assign('curr_page', $newpager->intCurrentPageNumber);
        $this->assign('total_page', $newpager->intTotalPageCount);
        $this->assign('items_per_page', $newpager->intItemsPerPage);
        $reports = $this->crontab_report_file_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage, $where, '', 'asc');
        $this->assign("name", $name);
        $this->assign('alllog', $reports);
        $this->display('downloadcronreport.tpl');
    }

	function crontabreportsdelete(){
		$id = get_request('id');
		if(!empty($id)){
			$_POST['chk_member'][]=$id;
		}
		for($i=0; $i<count($_POST['chk_member']); $i++){
			$report = $this->crontab_report_file_set->select_by_id($_POST['chk_member'][$i]);
			@unlink($report['filepath']);
			$this->crontab_report_file_set->delete($_POST['chk_member'][$i]);
		}
		
		alert_and_back('操作成功');
	}
}
?>
