<?php
if(!defined('CAN_RUN')) {
	exit('Access Denied');
}

class c_admin_member extends c_base {
	function index($radiususer=false) {
		$back = get_request('back');
		if($back){
			if(is_array($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'])){
				$_GET = array_merge($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING'], $_GET);
				$_SERVER['QUERY_STRING'] = http_build_query($_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);
			}
		}else{
			$_SESSION[$_GET['controller'].'_'.$_GET['action'].'_'.'QUERY_STRING'] = null;
		}
		$page_num = get_request('page');
		$gid = get_request("gid");
		$username = get_request("username", 0, 1);
		$orderby1 = get_request("orderby1", 0, 1);
		$orderby2 = get_request("orderby2", 0, 1);
		$level = get_request("level", 0, 1);
		$derive = get_request("derive");
		//$where = 'level < 10 AND level!=2';
		$where = '1=1';
		if($gid){
			$where .= ' AND group='.$gid;
		}
		if($username){
			$where .= " AND username like '%".$username."%'";
		}
		
		if($level){
			$where .= ' AND level='.$level;
		}

		if(empty($orderby1)){
			$orderby1 = 'username';
		}
		if(strcasecmp($orderby2, 'asc') != 0 ) {
			$orderby2 = 'asc';
		}else{
			$orderby2 = 'desc';
		}
		$this->assign("orderby2", $orderby2);

		if($_SESSION['ADMIN_LEVEL']==3){
			if(empty($_SESSION['ADMIN_MUSERGROUP'])){
				alert_and_back('没有可管理的组','admin.php?controller=admin_session');
				exit;
			}
			$where .= "  AND groupid=".$_SESSION['ADMIN_MUSERGROUP']." AND uid!=".$_SESSION['ADMIN_UID'];
		}
		if($radiususer){
			$_SESSION['RADIUSUSERLIST']=true;
			$where .= " AND level=11";
		}else{
			$_SESSION['RADIUSUSERLIST']=false;
			
			$where .= " AND level!=11";
		}
		if($derive){
			$this->memberderive();
			exit;
		}
		


		$curr_url = $_SERVER['PHP_SELF'] . "?";
		if(strstr($_SERVER['QUERY_STRING'], "&page=")) {
			$curr_url .= substr($_SERVER['QUERY_STRING'], 0 , strpos($_SERVER['QUERY_STRING'], "&page="));
		}
		else {
			$curr_url .= $_SERVER['QUERY_STRING'];
		
		}parse_str($_SERVER['QUERY_STRING'], $_SESSION[$_GET['controller'].'_'.($_GET['action'] ? $_GET['action'] : 'index' ).'_'.'QUERY_STRING']);

		$row_num = $this->member_set->select_count($where);
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$allmember = $this->member_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage,$where, $orderby1, $orderby2);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->assign('curr_url', $curr_url);


		$out = $allmember;
		$config = $this->setting_set->select_all(" sname='password_policy'");
		$pwdconfig = unserialize($config[0]['svalue']);
		$usergroup = $this->usergroup_set->select_all('1=1'.($_SESSION['ADMIN_LEVEL']==3 ? ' AND id=(SELECT musergroup FROM member WHERE uid='.$_SESSION['ADMIN_UID'].')' : ''),'GroupName', 'ASC');
		for($i=0;$i<count($out);$i++) {
			for($j=0; $j<count($usergroup); $j++){
				if($usergroup[$j]['id']==$out[$i]['groupid']){
					$out[$i]['groupname']=$usergroup[$j]['GroupName'];
					break;
				}
			}
			$out[$i]['username'] = $allmember[$i]['username'];
			$out[$i]['onlinenumber'] = get_online_number_by_users($allmember[$i]['username'], $pwdconfig['logintimeout']*60);
			if($out[$i]['username']==$_SESSION['ADMIN_USERNAME']){
				$out[$i]['onlinenumber'] = $out[$i]['onlinenumber'] + 1;
			}
		}
		$this->assign('allmember', $out);
		$this->display('member_list.tpl');
	}

	function radiususer(){
		$this->assign('radiususer', 'radiususer');
		$this->index(true);
	}

	function memberderive($where='1'){
		$level = array(
			"0" => '普通用户',
			"1" => '管理员',
			"2" => '审计员',
			"3" => '组管理员',
			"10" => '密码管理员',
			"11" => 'RADIUS用户'
		);
		$result = $this->member_set->base_select("SELECT a.*,b.GroupName FROM ".$this->member_set->get_table_name()." a LEFT JOIN ".$this->usergroup_set->get_table_name()." b ON a.groupid=b.id WHERE $where and level not in(1,2,3,10)");
		//$handle = @fopen('/tmp/member.xls', 'w');
		
		
		$str = language("用户名").",";
		$str .= language("密码").",";
		if(!$_SESSION['RADIUSUSERLIST']){
			$str .= language("真实姓名").",";
			$str .= language("电子邮箱").",";
			$str .= language("等级").",";
			$str .= language("组名").",";
			$str .= language("手机号码").",";
			$str .= language("工作单位").",";
			$str .= language("工作部门").",";
			$str .= language("vpn").",";
			$str .= language("vpnip").",";
			$str .= language("USBKEY").",";
		}
		$str .= "\n";
		$row = 1;
		if(!empty($result))
		foreach($result as $info) {
			$str .= $info['username'].",";
			$str .= $info['password'].",";
			if(!$_SESSION['RADIUSUSERLIST']){
				$str .= $info['realname'].",";
				$str .= $info['email'].",";
				$str .= $level[$info['level']].",";
				$str .= $info['GroupName'].",";
				$str .= $info['mobilenum'].",";
				$str .= $info['workcompany'].",";
				$str .= $info['workdepartment'].",";
				$str .= $info['vpn'].",";
				$str .= $info['vpnip'].",";
				$str .= "'".$info['usbkey']."',";
			}
			$str .= "\n";		
			
			$row++;
		}
		$str = mb_convert_encoding($str, "GB2312", "UTF-8");
		
		//fclose($handle);
		Header('Cache-Control: private, must-revalidate, max-age=0');
		Header("Content-type: application/octet-stream"); 
		Header("Content-Disposition: attachment; filename=audit-member-".date('Ymd').".csv"); 
		echo $str;
		exit;
	}

	

	function online(){
		$username = get_request('username', 0, 1);
		$config = $this->setting_set->select_all(" sname='password_policy'");
		$pwdconfig = unserialize($config[0]['svalue']);
		$online_users = get_online_users($username, $pwdconfig['logintimeout']*60);
		//var_dump($online_users);
		$this->assign("username", $username);
		$this->assign("current_session_id", session_id());
		$this->assign("online_users", $online_users);
		$this->display('online_member_list.tpl');
	}

	function offline(){
		$ssid = get_request('ssid', 0, 1);
		if(offline_user($ssid)){
			alert_and_back('断开成功');
		}else{
			alert_and_back('断开失败');
		}
	}

	function offline_all(){
		$ssids = $_POST['chk_member'];

		for($i=0; $i<count($ssids); $i++){
			offline_user($ssids[$i]);
		}
		alert_and_back('断开成功');
	}

	function add() {
		global $_CONFIG;
		if($_CONFIG['CREATE_LOG_USER']){
			$this->assign("create_log_user", 1);
		}
		$acgroups = $this->acnetwork_set->select_all('1=1','groupname');
		//$allpass = $this->pass_set->select_all();
		$allgroup = $this->sgroup_set->select_all('1=1', 'groupname', 'asc');
		$allusbkey = $this->usbkey_set->select_all('keyid not in(select usbkey from member)', 'keyid', 'ASC');
		$usergroup = $this->usergroup_set->select_all('1=1'.($_SESSION['ADMIN_LEVEL']==3 ? ' AND id=(SELECT musergroup FROM member WHERE uid='.$_SESSION['ADMIN_UID'].')' : ''),'GroupName', 'ASC');
		$weektime = $this->weektime_set->select_all();
		$sourceip = $this->sourceip_set->select_all(" sourceip=''");
		
		global $_CONFIG;
		$filename = $_CONFIG['CONFIGFILE']['SERVERCONF'];	
		$lines = @file($filename);
		$i=0;
		if($lines)
		foreach($lines as $line){
			if(preg_match("/group /",$line)==1) {
				$route = preg_split("/\s{1,}/", $line); 
				$routes[$i]['gname']= $route[1];
				$routes[$i]['start']= $route[2];
				$routes[$i]['end']= $route[3];
				$key1[]=$route[1];
				$i++;
			}
		}
		if(!empty($routes))
		array_multisort($key1,SORT_ASC,$routes);
		
		$dp = $this->config_set->base_select("SELECT * FROM defaultpolicy LIMIT 1");
		$dp = $dp[0];
		$member['netdisksize'] = $dp['netdisksize'];
		$member['default_control'] = $dp['default_control'];
		$member['default_appcontrol'] = '1';
		$member['apphost'] = '1';
		$member['log_priority'] = '-1';
		$member['db_priority'] = '-1';

		if($_SESSION['MEMBERADDTMP']){
			$member = $_SESSION['MEMBERADDTMP'];
		}

		$this->assign('member', $member);

		
		
		$outgroup = array();
		$groupname = '';
		if($acgroups)
		foreach($acgroups as $acgroup) {
			if($acgroup['groupname'] != $groupname) {
				$groupname = $acgroup['groupname'];
				$outgroup[] = $acgroup;
			}
		}
		$this->assign('allusbkey',$allusbkey);
		$this->assign('vpnpool', $routes);
		$this->assign("acgroup",$outgroup);
		$this->assign("allgroup",$allgroup);
		$this->assign("allpasses",$allpass);		
		$this->assign("sourceip", $sourceip);
		$this->assign("weektime", $weektime);
		$this->assign("usergroup", $usergroup);
		$this->assign('title',language('添加新用户'));
		$this->display('member_add2.tpl');
	}

	function edit() {
		global $_CONFIG;
		$member = $this->member_set->select_by_id(get_request('uid'));
		$member["password"] = $this->member_set->udf_decrypt($member["password"]);
		$acgroups = $this->acnetwork_set->select_all('1=1','groupname');
		$allgroup = $this->sgroup_set->select_all('1=1', 'groupname', 'asc');
		$allusbkey = $this->usbkey_set->select_all('keyid not in(select usbkey from member) or keyid=\''.$member[usbkey].'\'');
		$weektime = $this->weektime_set->select_all();
		$sourceip = $this->sourceip_set->select_all(" sourceip=''");
		$usergroup = $this->usergroup_set->select_all('1=1'.($_SESSION['ADMIN_LEVEL']==3 ? ' AND id=(SELECT musergroup FROM member WHERE uid='.$_SESSION['ADMIN_UID'].')' : ''),'GroupName', 'ASC');
		$loguser = $this->member_set->base_select("SELECT * FROM ".LOG_DBNAME.".user where username='".$member['username']."'");
		if(!empty($loguser)){
			$member['log_priority'] = $loguser[0]['level'];
		}else{
			$member['log_priority'] = -1;
		}
		$dbuser = $this->member_set->base_select("SELECT * FROM ".DBAUDIT_DBNAME.".member where username='".$member['username']."'");
		if(!empty($dbuser)){
			$member['db_priority'] = $dbuser[0]['level'];
		}else{
			$member['db_priority'] = -1;
		}
		
		if($_CONFIG['CREATE_LOG_USER']){
			$this->assign("create_log_user", 1);
		}
		$loguser = $this->member_set->base_select("SELECT * FROM ".LOG_DBNAME.".user WHERE username='".$member['username']."'");
		if($loguser){
			$this->assign("allowviewlog", 1);
		}
		
		$outgroup = array();
		$groupname = '';
		if($acgroups)
		foreach($acgroups as $acgroup) {
			if($acgroup['groupname'] != $groupname) {
				$groupname = $acgroup['groupname'];
				$outgroup[] = $acgroup;
			}
		}
		$this->assign("acgroup",$outgroup);
		$bindedacgroup = $this->acgroup_set->select_all("username = '".$member['username']."'");
		if(count($bindedacgroup)>0) {
			$this->assign('$oldacgroup',$bindedacgroup[0]['Value']);
		}
//		$member['flist'] = unserialize($member['flist']);
		//$member["username"] = $member["username"];//print_r($member);
		//echo time($member['end_time']).'--'.time().'--';
		$end_time_arr = explode(' ',$member['end_time']);
		$end_time_ymd = explode('-',$end_time_arr[0]);
		$end_time_time = explode(':',$end_time_arr[1]);
		//echo mktime($end_time_time[0],$end_time_time[1],$end_time_time[2],$end_time_ymd[1],$end_time_ymd[2],$end_time_ymd[0]);
		if($member['end_time'] && mktime($end_time_time[0],$end_time_time[1],$end_time_time[2],$end_time_ymd[1],$end_time_ymd[2],$end_time_ymd[0])<=time()){
			//$member['start_time'] = '2000-01-01 00:00:00';
		}

		$gattr = $this->uattr_set->select_all("UserName = '".$member['username']."' and attribute = '". $_CONFIG['attributes'][2]['name'] ."'");//登陆等级
		$this->assign('priv', substr($gattr[0]['Value'], strpos($gattr[0]['Value'],'=')+1));
		if(strpos($member['vpnip'],'/'))
		$member['vpnip']=substr($member['vpnip'],0,strpos($member['vpnip'],'/'));

		$this->assign('member', $member);
/*
		$keyid = $this->keys_set->select_all(" UserName = '".$member["username"]."' ");
		if($keyid[0]['pc_id'] !=0) {
			$allusbkey[] = $this->usbkey_set->select_by_id($keyid[0]['pc_id']);
		}
*/		
		global $_CONFIG;
		$filename = $_CONFIG['CONFIGFILE']['SERVERCONF'];	
		$lines = @file($filename);
		$i=0;
		if($lines)
		foreach($lines as $line){
			if(preg_match("/group /",$line)==1) {
				$route = preg_split("/\s{1,}/", $line); 
				$routes[$i]['gname']= $route[1];
				$routes[$i]['start']= $route[2];
				$routes[$i]['end']= $route[3];
				$key1[]=$route[1];
				$i++;
			}
		}
		if(!empty($routes))
		array_multisort($key1,SORT_ASC,$routes);

		/**/
		$this->assign('ukid', $keyid[0]['pc_id']);
		$this->assign('vpnpool', $routes);
		$this->assign("sourceip", $sourceip);
		$this->assign("weektime", $weektime);
		$this->assign("usergroup", $usergroup);
		$this->assign("allgroup",$allgroup);
		$this->assign('allusbkey',$allusbkey);
		$this->assign('title',language('编辑用户'));

		$config = $this->setting_set->select_all(" sname='password_policy'");
		//var_dump($config);
		$pwdconfig = unserialize($config[0]['svalue']);
		$pwdshould = '密码中应包含：';
		if($pwdconfig['pwdstrong1']) $pwdshould .= $pwdconfig['pwdstrong1'].'个数字,';
		if($pwdconfig['pwdstrong2']) $pwdshould .= $pwdconfig['pwdstrong2'].'个小写字母,';
		if($pwdconfig['pwdstrong3']) $pwdshould .= $pwdconfig['pwdstrong3'].'个大写字母,';
		if($pwdconfig['pwdstrong4']) $pwdshould .= $pwdconfig['pwdstrong4'].'个特殊字符,';
		if($pwdshould != '密码中应包含：'){
		$this->assign("pwdshould", substr($pwdshould,0,strlen($pwdshould)-1));
		}

		$this->display('member_add2.tpl');
	}
	
	function edit_self() {
		global $_CONFIG;
		$msg = get_request('msg', 0, 1);
		$keyfile = $_CONFIG['PASSEDITSSHPRIVATEKEY']."/".$_SESSION['ADMIN_USERNAME'];
		if(file_exists($keyfile)){
			$fileinfo = stat($keyfile);
			$filedate = date('Y年m月d日 H时i分', $fileinfo['mtime']);
		}
		$member = $this->member_set->select_by_id($_SESSION['ADMIN_UID']);
		$member["password"] = $this->member_set->udf_decrypt($member["password"]);
		$member["username"] = $member["username"];
		$this->assign('msg', empty($msg) ? '' : '请修改密码');
		$this->assign('member', $member);
		$bindedacgroup = $this->acgroup_set->select_all("username = '".$member['username']."'");
		$this->assign('bindedacgroup',$bindedacgroup[0]['Value']);
		
		$config = $this->setting_set->select_all(" sname='password_policy'");
		//var_dump($config);
		$pwdconfig = unserialize($config[0]['svalue']);
		$pwdshould = '密码中应包含：';
		if($pwdconfig['pwdstrong1']) $pwdshould .= $pwdconfig['pwdstrong1'].'个数字,';
		if($pwdconfig['pwdstrong2']) $pwdshould .= $pwdconfig['pwdstrong2'].'个小写字母,';
		if($pwdconfig['pwdstrong3']) $pwdshould .= $pwdconfig['pwdstrong3'].'个大写字母,';
		if($pwdconfig['pwdstrong4']) $pwdshould .= $pwdconfig['pwdstrong4'].'个特殊字符,';
		if($pwdshould != '密码中应包含：'){
			$this->assign("pwdshould", substr($pwdshould,0,strlen($pwdshould)-1));
		}	
		$this->assign("filedate", $filedate);
		$this->display('member_edit_self.tpl');
	}

	function save() {
		global $_CONFIG;
		$type = get_request('type', 0, 1);
		$uid = get_request('uid');
		$newmember = new member();
		$_SESSION['MEMBERADDTMP']['password1']=$password1 = get_request('password1', 1, 1);
		$_SESSION['MEMBERADDTMP']['email']=$email = get_request('email', 1, 1);
		$_SESSION['MEMBERADDTMP']['realname']=$realname  = get_request('realname', 1, 1);
		$_SESSION['MEMBERADDTMP']['password2']=$password2 = get_request('password2', 1, 1);
		$_SESSION['MEMBERADDTMP']['acgroup']=$acgroup = get_request('acgroup',1,1);
		$_SESSION['MEMBERADDTMP']['restrictweb']=$restrictweb = get_request('restrictweb',1,1);
		$_SESSION['MEMBERADDTMP']['username']=$uname = get_request('username', 1, 1);
		$_SESSION['MEMBERADDTMP']['g_id']=$g_id = get_request('g_id',1,0);
		$_SESSION['MEMBERADDTMP']['usbkey']=$usbkey = get_request('usbkey', 1, 1);
		$_SESSION['MEMBERADDTMP']['ip']=$ip = get_request('ip', 1, 1);
		$_SESSION['MEMBERADDTMP']['limit_time']=$limit_time = get_request('limit_time', 1, 1);
		$_SESSION['MEMBERADDTMP']['vpn']=$vpn = get_request('vpn', 1, 1);
		$_SESSION['MEMBERADDTMP']['log_priority']=$log_priority = get_request('log_priority', 1, 0);
		$_SESSION['MEMBERADDTMP']['db_priority']=$db_priority = get_request('db_priority', 1, 0);
		$_SESSION['MEMBERADDTMP']['auth']=$auth = get_request('auth', 1, 0);
		$_SESSION['MEMBERADDTMP']['nolimit']=$nolimit = get_request('nolimit', 1, 1);
		$_SESSION['MEMBERADDTMP']['sourceip']=$sourceip = get_request('sourceip', 1, 1);
		$_SESSION['MEMBERADDTMP']['weektime']=$weektime = get_request('weektime', 1, 1);
		$_SESSION['MEMBERADDTMP']['mobilenum']=$mobilenum = get_request('mobilenum', 1, 1);
		$_SESSION['MEMBERADDTMP']['company']=$company = get_request('company', 1, 1);
		$_SESSION['MEMBERADDTMP']['workcompany']=$workcompany = get_request('workcompany', 1, 1);
		$_SESSION['MEMBERADDTMP']['workdepartment']=$workdepartment = get_request('workdepartment', 1, 1);
		$_SESSION['MEMBERADDTMP']['start_time']=$start_time = get_request('start_time', 1, 1);
		$_SESSION['MEMBERADDTMP']['groupid']=$groupid = get_request('groupid', 1, 0);
		$_SESSION['MEMBERADDTMP']['musergroup']=$musergroup = get_request('musergroup', 1, 0);
		$_SESSION['MEMBERADDTMP']['autosetpwd']=$autosetpwd = get_request('autosetpwd', 1, 0);
		$_SESSION['MEMBERADDTMP']['priv']=$priv = get_request('priv', 1, 0);
		$_SESSION['MEMBERADDTMP']['rdpclipauth']=$rdpclipauth = get_request('rdpclipauth', 1, 0);
		$_SESSION['MEMBERADDTMP']['rdpdiskauth']=$rdpdiskauth = get_request('rdpdiskauth', 1, 0);
		$_SESSION['MEMBERADDTMP']['loginlock']=$loginlock = get_request('loginlock', 1, 1);
		$_SESSION['MEMBERADDTMP']['rdpdisk']=$rdpdisk = get_request('rdpdisk', 1, 1);
		$_SESSION['MEMBERADDTMP']['vpnip']=$vpnip = trim(get_request('vpnip', 1, 1));
		$_SESSION['MEMBERADDTMP']['netdisksize']=$netdisksize = get_request('netdisksize', 1, 1);
		$_SESSION['MEMBERADDTMP']['default_control']=$default_control = get_request('default_control', 1, 0);
		$_SESSION['MEMBERADDTMP']['default_appcontrol']=$default_appcontrol = get_request('default_appcontrol', 1, 0);
		$_SESSION['MEMBERADDTMP']['apphost']=$apphost = get_request('apphost', 1, 1);
		$_SESSION['MEMBERADDTMP']['allowchange']=$allowchange = get_request('allowchange', 1, 1);
		$_SESSION['MEMBERADDTMP']['radius_auth']=$radius_auth = get_request('radius_auth', 1, 1);
		$_SESSION['MEMBERADDTMP']['allowviewlog']=$allowviewlog = get_request('allowviewlog', 1, 1);
		$_SESSION['MEMBERADDTMP']['common_user_pri']=$common_user_pri = get_request('common_user_pri', 1, 1);		
		$_SESSION['MEMBERADDTMP']['passwd_user_pri']=$passwd_user_pri = get_request('passwd_user_pri', 1, 1);		
		$_SESSION['MEMBERADDTMP']['audit_user_pri']=$audit_user_pri = get_request('audit_user_pri', 1, 1);		
	
		if(empty($nolimit) and empty($limit_time)){
			alert_and_back('请选择过期时间');
			exit();
		}
		if(!preg_match('/^[a-zA-Z_]+[a-zA-Z._\-0-9@]*$/', $uname)){
			alert_and_back('用户名必须以字母开头，可包含下划线、字母、数字，小数点');
			exit();
		}
		$newmember->set_data('rdpdiskauth', $rdpdiskauth);
		$newmember->set_data('rdpclipauth', $rdpclipauth);
		$newmember->set_data('rdpdisk', $rdpdisk);
		$newmember->set_data('start_time', $start_time);
		if($nolimit){
			$newmember->set_data('end_time', '2037:1:1 0:0:0');
		}else{
			$newmember->set_data('end_time', $limit_time);
		}
		if($netdisksize){
			$newmember->set_data('netdisksize', $netdisksize);
		}
		if($allowchange == 'on') {
			$newmember->set_data('allowchange',1);
		}
		else {
			$newmember->set_data('allowchange',0);
		}
		if($apphost == 'on') {
			$newmember->set_data('apphost',1);
		}
		else {
			$newmember->set_data('apphost',0);
		}
		if($restrictweb == 'on') {
			$newmember->set_data('restrictweb',1);
		}
		else {
			$newmember->set_data('restrictweb',0);
		}
		if($loginlock == 'on') {
			$newmember->set_data('loginlock',1);
		}
		else {
			$newmember->set_data('loginlock',0);
		}
		if($common_user_pri == 'on') {
			$newmember->set_data('common_user_pri',1);
		}
		else {
			$newmember->set_data('common_user_pri',0);
		}
		if($passwd_user_pri == 'on') {
			$newmember->set_data('passwd_user_pri',1);
		}
		else {
			$newmember->set_data('passwd_user_pri',0);
		}
		if($audit_user_pri == 'on') {
			$newmember->set_data('audit_user_pri',1);
		}
		else {
			$newmember->set_data('audit_user_pri',0);
		}
		if($vpn == 'on') {
			$newmember->set_data('vpn',0);
		}
		else {
			$newmember->set_data('vpn',1);
		}
		
		$newmember->set_data('default_control', $default_control);
		$newmember->set_data('default_appcontrol', $default_appcontrol);
		$oldmember = $this->member_set->select_by_id($uid);

		$filename = $_CONFIG['CONFIGFILE']['SERVERCONF'];		
		$lines = @file($filename);
		if(!empty($lines))
		{			
			for($ii=0; $ii<count($lines); $ii++)
			{
				if(strstr(strtolower($lines[$ii]), "server "))
				{
					$tmp = preg_split("/[\s]+/", $lines[$ii]);
					$network['server1'] = trim($tmp[1]);
					$network['server2'] = trim($tmp[2]);
				}
			}
		}
		if(!empty($vpnip)){
			$vpnipexist = $this->member_set->select_all("vpnip='".$vpnip."' and uid!=$uid");
			if(count($vpnipexist)!=0){
				alert_and_back('vpnip已经存在');
				exit;
			}
		}
		$newmember->set_data('realname', $realname);
		if(!$_SESSION['RADIUSUSERLIST'])
		if(empty($realname)){
			alert_and_back('真实姓名不能重复且不能为空');
				exit;
		}elseif($this->member_set->select_count("realname = '" . $newmember->get_data('realname') . "' AND uid!='$uid' AND level!=11")>0 ) {
			alert_and_back('真实姓名不能重复且不能为空');
				exit;
		}
		if(!empty($password1)){			
			
			$config = $this->setting_set->select_all(" sname='password_policy'");
			//var_dump($config);
			$pwdconfig = unserialize($config[0]['svalue']);
			$reg = '';
			//var_dump($pwdconfig);var_dump($password1);
		
			$pwdmsg = '';
			/*if($pwdconfig['pwdstrong1']&&!preg_match('/[0-9]+/', $password1)){
				//alert_and_back('密码中需要包含数字');
				//exit;
				$pwdmsg .= '数字'." ";
			}
			if(!$pwdconfig['pwdstrong1']&&preg_match('/[0-9]+/', $password1)){
				//alert_and_back('密码中不能包含数字');
				//exit;
				$pwdmsgn .= '数字'." ";
			}
			if($pwdconfig['pwdstrong2']&&!preg_match('/[a-zA-Z]+/', $password1)){
				//alert_and_back('密码中需要包含小写字母');
				//exit;
				$pwdmsg .= '字母'." ";
			}
			if(!$pwdconfig['pwdstrong2']&&preg_match('/[a-zA-Z]+/', $password1)){
				//alert_and_back('密码中不能包含小写字母');
				//exit;
				$pwdmsgn .= '字母'." ";
			}
			
			$pwd_replace = preg_replace('/[0-9a-zA-Z]+/','', $password1);
			if($pwdconfig['pwdstrong4']&&strlen($pwd_replace)==0){
				//alert_and_back('密码中需要包含特殊字符');
				//exit;
				$pwdmsg .= '特殊字符'." ";
			}
			if(!$pwdconfig['pwdstrong4']&&strlen($pwd_replace)>0){
				//alert_and_back('密码中不能包含特殊字符');
				//exit;
				$pwdmsgn .= '特殊字符'." ";
			}*/
			if(intval($pwdconfig['pwdstrong1'])>preg_match_all('/[0-9]/', $password1, $matches)){
				//alert_and_back('密码中需要包含数字');
				//exit;
				$pwdmsg .= '数字'." ";
			}
			if(intval($pwdconfig['pwdstrong2'])>preg_match_all('/[a-z]/', $password1, $matches)){
				//alert_and_back('密码中需要包含小写字母');
				//exit;
				$pwdmsg .= '小写字母'." ";
			}
			if(intval($pwdconfig['pwdstrong3'])>preg_match_all('/[A-Z]/', $password1, $matches)){
				//alert_and_back('密码中需要包含小写字母');
				//exit;
				$pwdmsg .= '大写字母'." ";
			}
			$pwd_replace = preg_replace('/[0-9a-zA-Z]/','', $password1);
			if(intval($pwdconfig['pwdstrong4'])>strlen($pwd_replace)){
				//alert_and_back('密码中需要包含特殊字符');
				//exit;
				$pwdmsg .= '特殊字符'." ";
			}
			if(strlen($password1) < $pwdconfig['login_pwd_length']){
				//alert_and_back(language('密码最少长度为').$pwdconfig['login_pwd_length']);
				//exit();
				$pwdmsgl = language('密码最少长度为').$pwdconfig['login_pwd_length'];
			}

			$pwd_ban_word_arr = explode('1', $_CONFIG['PASSWORD_BAN_WORD']);			
			if($pwd_ban_word_arr){
				$pwd_ban_word_str = implode(' ', $pwd_ban_word_arr);
			}			
			for($pi=0; $pi<count($pwd_ban_word_arr); $pi++){
				if($pwd_ban_word_arr[$pi]&&strpos($password1, $pwd_ban_word_arr[$pi])!==false){
					$pwdmsg2='密码中不能包含以下字符:'.addslashes($pwd_ban_word_str).' \n请重新输入';
					break;
				}
			}
			if(!empty($pwdmsg) || !empty($pwdmsgl) || !empty($pwdmsg2)){
				if($pwdconfig['pwdstrong1'] || $pwdconfig['pwdstrong2'] || $pwdconfig['pwdstrong3'] || $pwdconfig['pwdstrong4']){
					$pwdmsgs .= '密码中需要包含:' .  ($pwdconfig['pwdstrong1'] ? $pwdconfig['pwdstrong1'].'个数字' : '').($pwdconfig['pwdstrong2'] ? $pwdconfig['pwdstrong2'].'个小写字母' : '').($pwdconfig['pwdstrong3'] ? $pwdconfig['pwdstrong3'].'个大写字母' : '').($pwdconfig['pwdstrong4'] ? $pwdconfig['pwdstrong4'].'个特殊字符' : ''). "\\n";
				}
				$pwdmsgs .= language('密码最少长度为').$pwdconfig['login_pwd_length']."\\n";
				if(count($pwd_ban_word_str)>0){
					$pwdmsgs .= '密码中不能包含以下字符:'.addslashes($pwd_ban_word_str).' \n\n请重新输入';
				}
				alert_and_back($pwdmsgs);
				exit;
			}
		}else{
			alert_and_back('请输入密码');
			exit;
		}

		$serverResult = $this->server_set->select_all(" groupid=$g_id");
		if($serverResult){
			foreach ($serverResult AS $key => $value){
				$serverIds[] = $value['id'];
			}
		}
		if($serverIds)
		$serverString=implode(",", $serverIds);
		$newmember->set_data("devs", ",".$serverString.",");
		if($uid != 0) {
			$flist = get_request('flist', 1, 1);
			$uid = get_request('uid');
			$newmember->set_data('uid',$uid);
			
			if(empty($autosetpwd)){
				if(!($password1 == "" && $password2 == "")) {
					if($password1 == $password2) {
						if($_CONFIG['crypt']==1){
							$password1 = encrypt($password1);
						}
						$newmember->set_data('password', $password1);
					}
					else {
						alert_and_back('两次输入的密码不一致');
						exit();
					}
				}
			}else{
				$password1 = genRandomPassword(8);
				$newmember->set_data('password', $password1);
			}
			$this->devpass_set->query("UPDATE ".$this->devpass_set->get_table_name()." SET old_password=cur_password,cur_password='".$this->member_set->udf_encrypt($password1)."' WHERE username='".get_request('username', 1, 1)."' AND radiususer=".$uid);
			$newmember->set_data('flist', serialize($flist));


		}
		else {
			if(empty($autosetpwd)){
				if($password1 == $password2) {
						if($_CONFIG['crypt']==1){
							$password1 = encrypt($password1);
						}
					$newmember->set_data('password', $password1);
					$newmember->set_data('lastdateChpwd', 0);
					
				}
				else {
					alert_and_back('两次输入的密码不一致');
					exit();
				}
			}else{
				$password1 = genRandomPassword(8);
				$newmember->set_data('password', $password1);
				
			}
			
			
		}
		
		$newmember->set_data('username', get_request('username', 1, 1));		
		if($autosetpwd&&empty($email)){
			alert_and_back('由于您设置了随机密码,请输入邮件地址');
			exit;
		}
		$newmember->set_data('email', get_request('email', 1, 1));
		$newmember->set_data('vpnip', $vpnip);
		$newmember->set_data("sourceip", $sourceip);		
		$newmember->set_data("weektime", $weektime);
		$newmember->set_data("mobilenum", $mobilenum);
		$newmember->set_data("company", $company);
		$newmember->set_data("workcompany", $workcompany);
		$newmember->set_data("workdepartment", $workdepartment);
		$newmember->set_data("groupid", $groupid);
		$newmember->set_data("auth", $auth);
		if($_SESSION['ADMIN_LEVEL']==3){
			$newmember->set_data("groupid", $_SESSION['ADMIN_MUSERGROUP']);
		}

		if($uid != 0) {
			$user = $this->member_set->select_by_id($uid);
			if($user['password']!=$password1){
				$adminlog = new admin_log();	
				$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);			
				$adminlog->set_data('action', language('修改密码'));
				$adminlog->set_data('luser', $user['username']);
				$this->admin_log_set->add($adminlog);
				
			}
		}
		
			$this->usbkey_set->query("UPDATE radkey SET isused=1 WHERE keyid='".$usbkey."'");
			$newmember->set_data('usbkey', $usbkey);

		if(!empty($ip)){
			$ip_arr = explode(".", $ip);
			if(count($ip_arr) <= 4 && $ip_arr[0]=='10' && $ip_arr[1]=='11' && ($ip_arr[2]>=0 && $ip_arr[2]<=255) && ($ip_arr[3]>=1 && $ip_arr[3]<=255) && $ip != '10.11.0.1'){
				if($this->member_set->select_all("ip = '" . $ip . "' AND uid != $uid") != NULL ){
					alert_and_back('该IP已存在,请重新选择');exit;
				}
			}else{
				alert_and_back('IP输入不正确');exit;
			}
		}
		$newmember->set_data('ip', $ip);

		if($newmember->get_errnum() == 0) {
			if($uid == 0) {
				//$allpasswd = $this->update_user();
				if($this->member_set->select_all("username = '" . $newmember->get_data('username') . "'") == NULL ) {

					$newgroup = new acgroup();
					$newgroup->set_data('username',$newmember->get_data('username'));
					$newgroup->set_data('value',$acgroup);
					$this->acgroup_set->add($newgroup);

					
					$newmember->set_data('level', get_request('level', 1, 0));
					if($_SESSION['ADMIN_LEVEL']==3){
						$newmember->set_data("level", 0);
					}elseif($_SESSION['RADIUSUSERLIST']){
						$newmember->set_data("level", 11);
					}
					/*只有普通用户才有Radius用户,系统用户和密码托管用户*/
					//if($newmember->get_data('level') == 0) {
						$new_radius = new radius();						
						$new_radius->set_data("UserName",$newmember->get_data('username'));
						$new_radius->set_data("Attribute",'Crypt-Password');
						$new_radius->set_data("email",$newmember->get_data('email'));
						$new_radius->set_data("Value",crypt($newmember->get_data('password'),"\$1\$qY9g/6K4"));
						$this->radius_set->add($new_radius);
						/*
						$new_pro = new pro();
						$new_pro->set_data("username",$this->encryp($newmember->get_data('username')));
						for($i = 1;$i<6;$i++) {
							$new_pro->set_data("user$i",get_request("user$i",1,1));
						}
						$this->pro_set->add($new_pro);
						*/
						$out = '';
						//command("sudo /usr/sbin/useradd ". $newmember->get_data('username'), $out);	
						//command("echo \"".$password1."\" | sudo passwd --stdin " . $newmember->get_data('username'), $out);
					//}
					//else
					//var_dump($newmember->get_data('level')) ;
					if($newmember->get_data('level') == 3) {
						$newmember->set_data('mservergroup',$g_id);
						$newmember->set_data('musergroup',$musergroup);
					}
					$newmember->set_data("password", $this->member_set->udf_encrypt($newmember->get_data("password")));
					
					if(!$_SESSION['RADIUSUSERLIST']){
						
						$dbuser = $this->member_set->base_select("SELECT * FROM ".DBAUDIT_DBNAME.".member where username='".$newmember->get_data('username')."'");
						if(empty($dbuser)){
							if($db_priority>=0){
								$sql = "INSERT INTO ".DBAUDIT_DBNAME.".member set username='".$newmember->get_data('username')."',password='".$newmember->get_data('password')."',realname='".$newmember->get_data('realname')."',email='".$newmember->get_data('email')."',usbkey='".$newmember->get_data('usbkey')."',default_control='".$newmember->get_data('default_control')."',level='".$db_priority."',common_user_pri='".$newmember->get_data('common_user_pri')."',start_time='".$newmember->get_data('start_time')."',end_time='".$newmember->get_data('limit_time')."'";
								$this->member_set->query($sql);
							}
						}else{
							$sql = "UPDATE ".DBAUDIT_DBNAME.".member set username='".$newmember->get_data('username')."',password='".$newmember->get_data('password')."',realname='".$newmember->get_data('realname')."',email='".$newmember->get_data('email')."',usbkey='".$newmember->get_data('usbkey')."',default_control='".$newmember->get_data('default_control')."',common_user_pri='".$newmember->get_data('common_user_pri')."',start_time='".$newmember->get_data('start_time')."',end_time='".$newmember->get_data('limit_time')."',level='".$db_priority."' where uid = $uid";
								$this->member_set->query($sql);
						}
						$loguser = $this->member_set->base_select("SELECT * FROM ".LOG_DBNAME.".user where username='".$newmember->get_data('username')."'");
						if(empty($loguser)){
							if($log_priority>=0){
								$sql = "INSERT INTO ".LOG_DBNAME.".user set username='".$newmember->get_data('username')."',password=md5('".$this->member_set->udf_decrypt($newmember->get_data('password'))."'),email='".$newmember->get_data('email')."',level='".$log_priority."'";
								$this->member_set->query($sql);
							}
						}else{
							$sql = "UPDATE ".LOG_DBNAME.".user set username='".$newmember->get_data('username')."',password=md5('".$this->member_set->udf_decrypt($newmember->get_data('password'))."'),email='".$newmember->get_data('email')."',level='".$log_priority."' WHERE  userid=$uid";
							$this->member_set->query($sql);
						}
					}
					$this->member_set->add($newmember);
					$passwordlog = new passwordlog();
					$passwordlog->set_data('uid', mysql_insert_id());
					$passwordlog->set_data('password', md5($password1));
					$passwordlog->set_data('time', mktime());
					$this->passwordlog_set->add($passwordlog);

					

					//记录日志
					$adminlog = new admin_log();
					$adminlog->set_data('luser', $newmember->get_data('username'));
					$adminlog->set_data('action', language('添加'));
					$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);
					$this->admin_log_set->add($adminlog);	
					if($autosetpwd){
						$ha = $this->config_set->base_select("SELECT * FROM alarm LIMIT 1");
						$smtp = new smtp_mail($ha[0]['MailServer'],"25",$ha[0]['account'],$ha[0]['password'], false);
						$smtp->send($ha[0]['account'],$newmember->get_data('email'),iconv("UTF-8", "GB2312", $_CONFIG['site']['title']." 随机密码"),iconv("UTF-8", "GB2312",($newmember->get_data('username')).",你好:\n  你的随机密码是:".$this->member_set->udf_decrypt($newmember->get_data('password'))));
					}

					$newuattr = new uattr();//添加登陆等级
					$newuattr->set_data('username', $uname);
					$newuattr->set_data('attribute', $_CONFIG['attributes'][2]['name']);
					$newuattr->set_data('value', $_CONFIG['attributes'][2]['default'].$priv);
					$this->uattr_set->add($newuattr);

					/*if($_CONFIG['CREATE_LOG_USER']){
						if($allowviewlog){
							$this->member_set->query("INSERT INTO ".LOG_DBNAME.".user SET username='".$uname."', password='".md5($password1)."', level=0, email='".$email."'");
						}else{
							$this->member_set->query("UPDATE ".LOG_DBNAME.".user SET password='".md5($password1)."', level=0, email='".$email."' WHERE username='".$uname."'");
						}
					}*/
					unset($_SESSION['MEMBERADDTMP']);
					if($_SESSION['RADIUSUSERLIST']){
						alert_and_back('成功添加用户', 'admin.php?controller=admin_member&action=radiususer');
					}else{
						alert_and_back('成功添加用户', 'admin.php?controller=admin_member');
					}
					
				}
				else {
					alert_and_back('该用户已存在', NULL, 1);
					exit();
				}
			}
			else {
				$user = $this->member_set->select_by_id($uid);

				if($user['password'] != $this->member_set->udf_encrypt($newmember->get_data("password"))){
					$passlog = $this->passwordlog_set->select_count(" uid='$uid' and password=md5('$password1')");
					if($passlog>0){
						alert_and_back('该密码已经使用过,请重新选择');
						exit();
					}
				}
				if($user['usbkey'])
				$this->usbkey_set->query("UPDATE radkey SET isused=0 WHERE keyid='".$user['usbkey']."'");
				if($this->acgroup_set->select_count("username = '".$user['username']."'") == 0) {
					$newgroup = new acgroup();
					$newgroup->set_data('username',$user['username']);
					$newgroup->set_data('value',$acgroup);
					$this->acgroup_set->add($newgroup);
				}
				else {
					$newgroup = new acgroup();
					$oldgroup = $this->acgroup_set->select_all("username ='".$user['username']."'");
					$newgroup->set_data('id',$oldgroup[0]['id']);
					$newgroup->set_data('value',$acgroup);
					$this->acgroup_set->edit($newgroup);
				}
				/*只有普通用户才有Radius用户*/
				//if($newmember->get_data('level') != 3)
				{
					$old_radius = $this->radius_set->select_all("UserName = '".$user['username']."'");
					$new_radius = new radius();
					$new_radius->set_data("id",$old_radius[0]['id']);
					$new_radius->set_data("email",$newmember->get_data('email'));
					if($newmember->get_data('password') != '') {
 						$new_radius->set_data("Value",crypt($newmember->get_data('password'),"\$1\$qY9g/6K4"));
						//$newmember->set_data('lastdateChpwd', mktime());
					}						
					$this->radius_set->edit($new_radius);

				}
				if($user['level'] == 3) {
						$newmember->set_data('mservergroup',$g_id);
						$newmember->set_data('musergroup',$musergroup);
						
				}

				$adminlog = new admin_log();
				$adminlog->set_data('luser', $user['username']);
				$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);
				$adminlog->set_data('action', language('编辑'));
				$this->admin_log_set->add($adminlog);
				if($user['username']=='password'){
						$cmd = "echo \"".$password1."\" | sudo passwd --stdin " . $user['username'];
						command($cmd, $out);	
				}
				$newmember->set_data("password", $this->member_set->udf_encrypt($newmember->get_data("password")));
				if($user['password']!=$newmember->get_data("password")){					
					$newmember->set_data('lastdateChpwd', 0);
					$passwordlog = new passwordlog();
					$passwordlog->set_data('uid', $uid);
					$passwordlog->set_data('password', md5($password1));
					$passwordlog->set_data('time', mktime());
					$this->passwordlog_set->add($passwordlog);
					if($pwdconfig['oldpassnumber']&&($cpnum=$this->passwordlog_set->select_count("uid=".$passwordlog->get_data('uid')))>$pwdconfig['oldpassnumber']){
						
						$this->passwordlog_set->query("DELETE FROM ".$this->passwordlog_set->get_table_name()." WHERE uid=$uid ORDER BY id ASC LIMIT ".($cpnum-$pwdconfig['oldpassnumber']));
					}
				}
				if(1){
					$dbuser = $this->member_set->base_select("SELECT * FROM ".DBAUDIT_DBNAME.".member where username='".$newmember->get_data('username')."'");
					if(empty($dbuser)){
						if($db_priority>=0){
							$sql = "INSERT INTO ".DBAUDIT_DBNAME.".member set username='".$newmember->get_data('username')."',password='".$newmember->get_data('password')."',realname='".$newmember->get_data('realname')."',email='".$newmember->get_data('email')."',usbkey='".$newmember->get_data('usbkey')."',default_control='".$newmember->get_data('default_control')."',level='".$db_priority."',common_user_pri='".$newmember->get_data('common_user_pri')."',start_time='".$newmember->get_data('start_time')."',end_time='".$newmember->get_data('limit_time')."'";
							$this->member_set->query($sql);
						}
					}else{
						$sql = "UPDATE ".DBAUDIT_DBNAME.".member set password='".$newmember->get_data('password')."',realname='".$newmember->get_data('realname')."',email='".$newmember->get_data('email')."',usbkey='".$newmember->get_data('usbkey')."',default_control='".$newmember->get_data('default_control')."',common_user_pri='".$newmember->get_data('common_user_pri')."',level='".$db_priority."',start_time='".$newmember->get_data('start_time')."',end_time='".$newmember->get_data('limit_time')."',lastdateChpwd=UNIX_TIMESTAMP() where username = '".$newmember->get_data('username')."'";
						$this->member_set->query($sql);
					}
					
					$loguser = $this->member_set->base_select("SELECT * FROM ".LOG_DBNAME.".user where username='".$newmember->get_data('username')."'");
					if(empty($loguser)){
						if($log_priority>=0){
							$sql = "INSERT INTO ".LOG_DBNAME.".user set username='".$newmember->get_data('username')."',password=md5('".$this->member_set->udf_decrypt($newmember->get_data('password'))."'),email='".$newmember->get_data('email')."',level='".$log_priority."'";
							$this->member_set->query($sql);
						}
					}else{
						$sql = "UPDATE ".LOG_DBNAME.".user set password=md5('".$this->member_set->udf_decrypt($newmember->get_data('password'))."'),level='".$log_priority."',email='".$newmember->get_data('email')."' WHERE  username='".$newmember->get_data('username')."'";
						$this->member_set->query($sql);
					}
					if($log_priority==-1){
						$sql = "DELETE FROM `log`.`user`  WHERE  username='".$newmember->get_data('username')."'";
						$this->member_set->query($sql);
					}
					if($db_priority==-1){
						$sql = "DELETE FROM ".DBAUDIT_DBNAME.".member WHERE  username='".$newmember->get_data('username')."'";
						$this->member_set->query($sql);
					}
				}
				$this->member_set->edit($newmember);
				if($autosetpwd){
						$ha = $this->config_set->base_select("SELECT * FROM alarm LIMIT 1");
						$smtp = new smtp_mail($ha[0]['MailServer'],"25",$ha[0]['account'],$this->member_set->udf_decrypt($ha[0]['password']), false);
						$smtp->send($ha[0]['account'],$newmember->get_data('email'),$_CONFIG['site']['title']." 随机密码",($user['username']).",你好:\n  你的随机密码是:".$this->member_set->udf_decrypt($newmember->get_data('password')));
				}

				$olduattr = $this->uattr_set->select_all("username = '".$user['username']."' and attribute = '". $_CONFIG['attributes'][2]['name'] ."'");
				if(empty($olduattr)){
					$newuattr = new uattr();//添加登陆等级
					$newuattr->set_data('username', $user['username']);
					$newuattr->set_data('attribute', $_CONFIG['attributes'][2]['name']);
					$newuattr->set_data('value',$_CONFIG['attributes'][2]['default'].$priv);
					$this->uattr_set->add($newuattr);
				}else{
					$newuattr = new uattr();//修改登陆等级
					$newuattr->set_data('id', $olduattr[0]['id']);
					$newuattr->set_data('value', $_CONFIG['attributes'][2]['default'].$priv);

					$this->uattr_set->edit($newuattr);
				}
				if($_CONFIG['CREATE_LOG_USER']){
					if($allowviewlog){
						$loguser = $this->member_set->base_select("select * from ".LOG_DBNAME.".user where username='".$uname."'");
						if(empty($loguser)){
							$this->member_set->query("INSERT INTO ".LOG_DBNAME.".user SET username='".$uname."', password='".md5($password1)."', level=0, email='".$email."'");
						}else{
							$this->member_set->query("UPDATE ".LOG_DBNAME.".user SET password='".md5($password1)."', level=0, email='".$email."' WHERE username='".$uname."'");
						}
					}else{
						$this->member_set->query("DELETE FROM ".LOG_DBNAME.".user WHERE username='".$uname."'");
					}
				}
				unset($_SESSION['MEMBERADDTMP']);
				if($oldmember['level']==11){
					alert_and_back('成功编辑用户', 'admin.php?controller=admin_member&action=radiususer');
				}else{
					alert_and_back('成功编辑用户', 'admin.php?controller=admin_member');
				}
			}
		}
		else {
			alert_and_back($newmember->get_firsterr(), NULL, 1);
			exit();
		}
	}

	
	function batchadd(){
		$usergroup = $this->usergroup_set->select_all('1=1'.($_SESSION['ADMIN_LEVEL']==3 ? ' AND id=(SELECT musergroup FROM member WHERE uid='.$_SESSION['ADMIN_UID'].')' : ''),'GroupName', 'ASC');
		$this->assign("usergroup", $usergroup);
		$this->display('batchadd.tpl');
	}

	function batchadd_save($encrypt=0){
		global $_CONFIG;
		$error = null;
		$_POSTS=$_POST;
		$filename = $_CONFIG['CONFIGFILE']['SERVERCONF'];		
		$lines = @file($filename);
		if(!empty($lines))
		{			
			for($ii=0; $ii<count($lines); $ii++)
			{
				if(strstr(strtolower($lines[$ii]), "server "))
				{
					$tmp = preg_split("/[\s]+/", $lines[$ii]);
					$network['server1'] = trim($tmp[1]);
				}
			}
		}
		
		for($i=0; $i<count($_POSTS['username']); $i++){
			
			$newmember = new member();
			$username = $_POSTS['username'][$i];
			$level = $_POSTS['level'][$i];
			if(empty($username)){
				continue;
			}
			if($level!=0&&empty($level)){
				$error[]=$username.':'.'只能导入普通用户和RADIUS用户'.'\n';
				continue;
			}
	
			$password = $_POSTS['password'][$i];
			$confirm_password = $_POSTS['confirm_password'][$i];
			
			$mobilenum = $_POSTS['mobilenum'][$i];
			$company = $_POSTS['company'][$i];
			$workcompany = $_POSTS['workcompany'][$i];
			$workdepartment = $_POSTS['workdepartment'][$i];
			$email = $_POSTS['email'][$i];
			$realname = $_POSTS['realname'][$i];
			$vpn = $_POSTS['vpn'][$i];
			$vpnip = $_POSTS['vpnip'][$i];
			$usbkey = $_POSTS['usbkey'][$i];
			if(preg_match("/[\\r\\n]/", $username)||preg_match("/[\\r\\n]/", $level)||preg_match("/[\\r\\n]/", $password)||preg_match("/[\\r\\n]/", $confirm_password)||preg_match("/[\\r\\n]/", $mobilenum)||preg_match("/[\\r\\n]/", $company)||preg_match("/[\\r\\n]/", $email)||preg_match("/[\\r\\n]/", $realname)||preg_match("/[\\r\\n]/", $vpn)||preg_match("/[\\r\\n]/", $vpnip)||preg_match("/[\\r\\n]/", $usbkey)){
				$error[]=$username.':'.'用户信息中含有回车符'.'\n';
				continue;
			}
			$vpnipexist = $this->member_set->select_all("vpnip='".$vpnip."' and username!='$username'");
			if($network['server1']==$vpnip&&count($vpnipexist)==0){
				$vpnip = $vpnip;
			}else{
				$vnpip = $oldmember['vpnip'];
			}
			$newmember->set_data('netdisksize', $netdisksize);
			$newmember->set_data('allowchange',0);
			$newmember->set_data('default_control', $default_control);
			$newmember->set_data('end_time', '2037:1:1 0:0:0');
			$newmember->set_data('mobilenum', $mobilenum);
			$newmember->set_data('workdepartment', $workdepartment);
			$newmember->set_data('workcompany', $workcompany);
			$newmember->set_data('email', $email);
			$newmember->set_data('realname', $realname);
			$newmember->set_data('vpn', $vpn);
			$newmember->set_data('vpnip', $vpnip);
			$newmember->set_data('usbkey', $usbkey);

			if(!preg_match('/^[a-zA-Z_]+[a-zA-Z._\-0-9@]*$/', $username)){
				$error[]=$username.':'.'用户名以字母和下划线开头包含大小写字母、数字、下划线、小数点'.'\n';
				continue;
			}
			if(!empty($password)){			
				$config = $this->setting_set->select_all(" sname='password_policy'");
				$pwdconfig = unserialize($config[0]['svalue']);
				$reg = '';			
				$pwdmsg = '';
				$pwdmsgl = null;
				$pwdmsg2 = null;
				$pwdmsgn = null;
				if(intval($pwdconfig['pwdstrong1'])>preg_match_all('/[0-9]/', $password1, $matches)){
					//alert_and_back('密码中需要包含数字');
					//exit;
					$pwdmsg .= '数字'." ";
				}
				if(intval($pwdconfig['pwdstrong2'])>preg_match_all('/[a-z]/', $password1, $matches)){
					//alert_and_back('密码中需要包含小写字母');
					//exit;
					$pwdmsg .= '小写字母'." ";
				}
				if(intval($pwdconfig['pwdstrong3'])>preg_match_all('/[A-Z]/', $password1, $matches)){
					//alert_and_back('密码中需要包含小写字母');
					//exit;
					$pwdmsg .= '大写字母'." ";
				}
				$pwd_replace = preg_replace('/[0-9a-zA-Z]/','', $password1);
				if(intval($pwdconfig['pwdstrong4'])>strlen($pwd_replace)){
					//alert_and_back('密码中需要包含特殊字符');
					//exit;
					$pwdmsg .= '特殊字符'." ";
				}
				
				if(strlen($password) < $pwdconfig['login_pwd_length']){
					$pwdmsgl = language('密码最少长度为').$pwdconfig['login_pwd_length'].',';
				}

				
				$pwd_ban_word_arr = explode('1', $_CONFIG['PASSWORD_BAN_WORD']);			
				if($pwd_ban_word_arr){
					$pwd_ban_word_str = implode(' ', $pwd_ban_word_arr);
				}			
				if(!empty($pwd_ban_word_arr[0]))
				for($pi=0; $pi<count($pwd_ban_word_arr); $pi++){
					if(strpos($password1, $pwd_ban_word_arr[$pi])!==false){
						$pwdmsg2='密码中不能包含以下字符:'.addslashes($pwd_ban_word_str).'';
						break;
					}
				}
				$pwdmsgs=null;
				if(!empty($pwdmsg) || !empty($pwdmsgl) || !empty($pwdmsg2)){
					if($pwdconfig['pwdstrong1'] || $pwdconfig['pwdstrong2'] || $pwdconfig['pwdstrong3'] || $pwdconfig['pwdstrong4']){
						$pwdmsgs .= '密码中需要包含:' .  ($pwdconfig['pwdstrong1'] ? $pwdconfig['pwdstrong1'].'个数字' : '').($pwdconfig['pwdstrong2'] ? $pwdconfig['pwdstrong2'].'个小写字母' : '').($pwdconfig['pwdstrong3'] ? $pwdconfig['pwdstrong3'].'个大写字母' : '').($pwdconfig['pwdstrong4'] ? $pwdconfig['pwdstrong4'].'个特殊字符' : ''). "\\n";
					}
					$pwdmsgs .= language('密码最少长度为').$pwdconfig['login_pwd_length'];
					if(count($pwd_ban_word_str)>0){
						$pwdmsgs .= '密码中不能包含以下字符:'.addslashes($pwd_ban_word_str);
					}
					$error[]=$username.':'.$pwdmsgs.'\n';
					//alert_and_back($pwdmsgs);
					//exit;
					continue;
				}
			}

			
			if($password == $confirm_password) {
				if($_CONFIG['crypt']==1){
					//$password1 = encrypt($password);
				}
				if($encrypt){
					$newmember->set_data('password', $this->member_set->udf_encrypt($password));
				}else{
					$newmember->set_data('password', $password);
				}
			}
			else {
				//alert_and_back('两次输入的密码不一致');
				$error[]=$username.':两次输入的密码不一致\n';
				continue;
			}
			if($this->member_set->select_count("username!='" . $username . "' and realname = '" . $newmember->get_data('realname') . "' AND level!=11")>0 ) {
				$error[]=$username.":真实名\'$realname\'已经存在".'\n';
				continue;
			}
			$newmember->set_data('username', $username);

			

			$newgroup = new acgroup();
			$newgroup->set_data('username',$newmember->get_data('username'));
			$newgroup->set_data('value',$acgroup);
			$this->acgroup_set->add($newgroup);
			
			$newmember->set_data('level', $level);
			if(isset($_POST['groupid'][$i])){
				$newmember->set_data("groupid", $_POST['groupid'][$i]);
			}
			if($_SESSION['ADMIN_LEVEL']==3){
				$newmember->set_data("level", 0);
				$newmember->set_data("groupid", $_SESSION['ADMIN_MUSERGROUP']);
			}
			/*只有普通用户才有Radius用户,系统用户和密码托管用户*/
			//if($newmember->get_data('level') == 0) {
			$new_radius = new radius();						
			$new_radius->set_data("UserName",$newmember->get_data('username'));
			$new_radius->set_data("Attribute",'Crypt-Password');
			$new_radius->set_data("email",$newmember->get_data('email'));
			
			$new_radius->set_data("Value",crypt($this->member_set->udf_decrypt($newmember->get_data('password')),"\$1\$qY9g/6K4"));
			//var_dump($this->member_set->udf_decrypt($newmember->get_data('password')));exit;
			
			if(($user=$this->member_set->select_all("username = '" . $newmember->get_data('username') . "'")) != NULL){
				//$error[]=$username.':帐户已经存在\n';
				$radiususer = $this->radius_set->select_all("UserName = '" . $newmember->get_data('username') . "'");
				$new_radius->set_data("id",$radiususer[0]['id']);
				$this->radius_set->edit($new_radius);
				$newmember->set_data('uid', $user[0]['uid']);
				$this->member_set->edit($newmember);
				$modified[]=$newmember->get_data('username');
				continue;
			}
			$this->radius_set->add($new_radius);

			if(!$_SESSION['RADIUSUSERLIST']){
				$dbuser = $this->member_set->base_select("SELECT * FROM ".DBAUDIT_DBNAME.".member where username='".$newmember->get_data('username')."'");
				if(empty($dbuser)){
					if($db_priority>=0){
						$sql = "INSERT INTO ".DBAUDIT_DBNAME.".member set username='".$newmember->get_data('username')."',password='".$newmember->get_data('password')."',realname='".$newmember->get_data('realname')."',email='".$newmember->get_data('email')."',usbkey='".$newmember->get_data('usbkey')."',default_control='".$newmember->get_data('default_control')."',level='".$newmember->get_data('level')."',common_user_pri='".$newmember->get_data('common_user_pri')."',start_time='".$newmember->get_data('start_time')."',end_time='".$newmember->get_data('limit_time')."'";
						$this->member_set->query($sql);
						
					}
				}else{
					$sql = "UPDATE ".DBAUDIT_DBNAME.".member set username='".$newmember->get_data('username')."',password='".$newmember->get_data('password')."',realname='".$newmember->get_data('realname')."',email='".$newmember->get_data('email')."',usbkey='".$newmember->get_data('usbkey')."',default_control='".$newmember->get_data('default_control')."',common_user_pri='".$newmember->get_data('common_user_pri')."',start_time='".$newmember->get_data('start_time')."',end_time='".$newmember->get_data('limit_time')."',level='".$newmember->get_data('level')."' where uid = '".$dbuser[0]['uid']."'";
					$this->member_set->query($sql);
				}
				$loguser = $this->member_set->base_select("SELECT * FROM ".LOG_DBNAME.".user where username='".$newmember->get_data('username')."'");
				if(empty($loguser)){
					if($log_priority>=0){
						$sql = "INSERT INTO ".LOG_DBNAME.".user set username='".$newmember->get_data('username')."',password=md5('".$this->member_set->udf_decrypt($newmember->get_data('password'))."'),email='".$newmember->get_data('email')."',level='".$newmember->get_data('level')."'";
						$this->member_set->query($sql);
					}
				}else{
					$sql = "UPDATE ".LOG_DBNAME.".user set username='".$newmember->get_data('username')."',password=md5('".$this->member_set->udf_decrypt($newmember->get_data('password'))."'),email='".$newmember->get_data('email')."',level='".$newmember->get_data('level')."' WHERE  userid='".$loguser[0]['userid']."'";
					$this->member_set->query($sql);
				}
			}

			$this->member_set->add($newmember);
			$added[]=$newmember->get_data('username');

			$passwordlog = new passwordlog();
			$passwordlog->set_data('uid', mysql_insert_id());
			$passwordlog->set_data('password', md5($password1));
			$passwordlog->set_data('time', mktime());
			$this->passwordlog_set->add($passwordlog);
			//记录日志
			$adminlog = new admin_log();
			$adminlog->set_data('luser', $newmember->get_data('username'));
			$adminlog->set_data('action', language('添加'));
			$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);
			$this->admin_log_set->add($adminlog);			
		}

		if($added || $modified){
			if(empty($error)){
				$msg = '全部操作成功';
			}else{
				if($added){
					$msg = '成功添加用户:'.implode(',',$added).'\n';
				}
				if($modified){
					$msg .= '成功修改用户:'.implode(',',$modified).'\n';
				}
				if($error){
					$msg .= '\n添加失败的用户:\n'.implode('\n',$error).'\n';
				}
			}
			if($_SESSION['RADIUSUSERLIST']){
				alert_and_back($msg,'admin.php?controller=admin_member&action=radiususer');
			}else{
				alert_and_back($msg,'admin.php?controller=admin_member');
			}
		}else{
			if($_SESSION['RADIUSUSERLIST']){
				alert_and_back('添加失败:\n'.implode('\n',$error).'\n','admin.php?controller=admin_member&action=radiususer');
			}else{
				alert_and_back('添加失败:\n'.implode('\n',$error).'\n','admin.php?controller=admin_member');
			}
		}
	}


	function batchedit(){
		//var_dump($_POST);
		if(empty($_POST['chk_member'])){
			alert_and_back('请至少选择一个用户');
			exit;
		}
		$users = $this->member_set->select_all("uid IN(".implode(',', $_POST['chk_member']).")");
		for($i=0; $i<count($users); $i++){
			$users[$i]['password']=$this->member_set->udf_decrypt($users[$i]['password']);
		}
		$this->assign("users", $users);
		$this->display('batchedit.tpl');
	}

	function batchedit_save(){
		global $_CONFIG;
		$error = null;
		$_POSTS=$_POST;
		
		for($i=0; $i<count($_POSTS['uid']); $i++){
			
			$newmember = new member();
			$uid = $_POSTS['uid'][$i];
			$username = $_POSTS['username'][$i];
			if(empty($uid)){
				continue;
			}
	
			$password = $_POSTS['password'][$i];
			$confirm_password = $_POSTS['confirm_password'][$i];
			$rdpdiskauth = $_POSTS['rdpdiskauth'][$i];
			$rdpclipauth = $_POSTS['rdpclipauth'][$i];
			$rdpdisk = $_POSTS['rdpdisk'][$i];
			$limit_time = $_POSTS['limit_time'][$i];
			$newmember->set_data('end_time', $limit_time);
			$newmember->set_data('rdpdiskauth', $rdpdiskauth);
			$newmember->set_data('rdpclipauth', $rdpclipauth);
			$newmember->set_data('rdpdisk', $rdpdisk);

			if(!empty($password)){			
				$config = $this->setting_set->select_all(" sname='password_policy'");
				$pwdconfig = unserialize($config[0]['svalue']);
				$reg = '';			
				$pwdmsg = '';
				if(intval($pwdconfig['pwdstrong1'])>preg_match_all('/[0-9]/', $password1, $matches)){
					//alert_and_back('密码中需要包含数字');
					//exit;
					$pwdmsg .= '数字'." ";
				}
				if(intval($pwdconfig['pwdstrong2'])>preg_match_all('/[a-z]/', $password1, $matches)){
					//alert_and_back('密码中需要包含小写字母');
					//exit;
					$pwdmsg .= '小写字母'." ";
				}
				if(intval($pwdconfig['pwdstrong3'])>preg_match_all('/[A-Z]/', $password1, $matches)){
					//alert_and_back('密码中需要包含小写字母');
					//exit;
					$pwdmsg .= '大写字母'." ";
				}
				$pwd_replace = preg_replace('/[0-9a-zA-Z]/','', $password1);
				if(intval($pwdconfig['pwdstrong4'])>strlen($pwd_replace)){
					//alert_and_back('密码中需要包含特殊字符');
					//exit;
					$pwdmsg .= '特殊字符'." ";
				}
				if(strlen($password) < $pwdconfig['login_pwd_length']){
					$pwdmsgl = language('密码最少长度为').$pwdconfig['login_pwd_length'].',';
				}

				
				$pwd_ban_word_arr = explode('1', $_CONFIG['PASSWORD_BAN_WORD']);			
				if($pwd_ban_word_arr){
					$pwd_ban_word_str = implode(' ', $pwd_ban_word_arr);
				}			
				for($pi=0; $pi<count($pwd_ban_word_arr); $pi++){
					if(strpos($password1, $pwd_ban_word_arr[$pi])!==false){
						$pwdmsg2='密码中不能包含以下字符:'.addslashes($pwd_ban_word_str).'';
						break;
					}
				}
				$pwdmsgs=null;
				if(!empty($pwdmsg) || !empty($pwdmsgl) || !empty($pwdmsg2)){
					if($pwdconfig['pwdstrong1'] || $pwdconfig['pwdstrong2'] || $pwdconfig['pwdstrong3'] || $pwdconfig['pwdstrong4']){
						$pwdmsgs .= '密码中需要包含:' .  ($pwdconfig['pwdstrong1'] ? '数字' : '').($pwdconfig['pwdstrong2'] ? '小写字母' : '').($pwdconfig['pwdstrong3'] ? '大写字母' : '').($pwdconfig['pwdstrong4'] ? '特殊字符' : '');
					}
					$pwdmsgs .= language('密码最少长度为').$pwdconfig['login_pwd_length'];
					if(count($pwd_ban_word_str)>0){
						$pwdmsgs .= '密码中不能包含以下字符:'.addslashes($pwd_ban_word_str);
					}
					$error[]=$username.':'.$pwdmsgs.'\n';
					//alert_and_back($pwdmsgs);
					//exit;
					continue;
				}
			}

			$encrypt=1;
			if($password == $confirm_password) {
				if($_CONFIG['crypt']==1){
					$password1 = encrypt($password);
				}
				if($encrypt){
					$newmember->set_data('password', $this->member_set->udf_encrypt($password));
				}else{
					$newmember->set_data('password', $password);
				}
			}
			else {
				//alert_and_back('两次输入的密码不一致');
				$error[]=$username.':两次输入的密码不一致\n';
				continue;
			}
			/*只有普通用户才有Radius用户,系统用户和密码托管用户*/
			//if($newmember->get_data('level') == 0) {
			$new_radius = new radius();						
			$new_radius->set_data("UserName",$username);
			$new_radius->set_data("Attribute",'Crypt-Password');
			$new_radius->set_data("Value",crypt($password,"\$1\$qY9g/6K4"));
			
			$succeed[]=$username;
			if(($user=$this->member_set->select_by_id($uid)) != NULL){
				//$error[]=$username.':帐户已经存在\n';
				$radiususer = $this->radius_set->select_all("UserName = '" . $username . "'");
				$new_radius->set_data("id",$radiususer[0]['id']);
				$this->radius_set->edit($new_radius);
				$newmember->set_data('uid', $user['uid']);
				$this->member_set->edit($newmember);
			}
			$passwordlog = new passwordlog();
			$passwordlog->set_data('uid', mysql_insert_id());
			$passwordlog->set_data('password', md5($password1));
			$passwordlog->set_data('time', mktime());
			$this->passwordlog_set->add($passwordlog);
			//记录日志
			$adminlog = new admin_log();
			$adminlog->set_data('luser', $newmember->get_data('username'));
			$adminlog->set_data('action', language('修改'));
			$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);
			$this->admin_log_set->add($adminlog);			
		}

		$msg = '成功修改用户:'.implode(',',$succeed);
		if($error){
			$msg .= '\n添加失败的用户:\n'.implode('\n',$error).'\n';
		}
		alert_and_back($msg,'admin.php?controller=admin_member');
	}

	function usergroup() {
		$page_num = get_request('page');
		$orderby1 = get_request('orderby1',0, 1);
		$orderby2 = get_request('orderby2',0, 1);
		$where = '1=1';
		if(empty($orderby1)){
			$orderby1 = 'id';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		if($_SESSION['ADMIN_LEVEL']==3){
			$where .= " AND `id`=(SELECT musergroup FROM ".$this->member_set->get_table_name()." WHERE uid='".$_SESSION['ADMIN_UID']."')";
		}		
		$row_num = $this->usergroup_set->select_count($where);
		$newpager = new my_pager($row_num, $page_num, 20, 'page');
		$sql = "SELECT a.*,(SELECT COUNT(*) FROM ".$this->member_set->get_table_name()." WHERE groupid=a.id) AS userct FROM ".$this->usergroup_set->get_table_name()." a WHERE $where ORDER BY $orderby1 $orderby2 LIMIT ".$newpager->intStartPosition.",". $newpager->intItemsPerPage;
		//$allgroup = $this->usergroup_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage, $where, $orderby1, $orderby2);
		$allgroup = $this->usergroup_set->base_select($sql);
		$this->assign('title', language('用户组列表'));
		$this->assign('allgroup', $allgroup);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->display('user_group_index.tpl');
	}
	
	function delete_usergroup(){
		$gid = get_request("id");
		$this->usergroup_set->delete($gid);
		$this->lgroup_set->query("DELETE FROM lgroup WHERE groupid=".$gid);
		$this->lgroup_set->query("DELETE FROM lgroup_devgrp WHERE groupid=".$gid);
		alert_and_back('删除成功','admin.php?controller=admin_member&action=usergroup');
	}
	
	function delete_user_from_group(){
		$uid = get_request("uid");
		$member = new member();
		$member->set_data('uid', $uid);
		$member->set_data('groupid', 0);
		$this->member_set->edit($member);
		alert_and_back('删除成功');
	}
	
	function groupuser(){
		$gid = get_request("gid");
		$page_num = get_request('page');
		$where = ' groupid='.$gid;
		$row_num = $this->member_set->select_count($where);
		$newpager = new my_pager($row_num, $page_num, $this->config['site']['items_per_page'], 'page');
		$allmember = $this->member_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage,$where, 'username', "ASC");
		$this->assign("gid", $gid);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);		
		$this->assign('allmember', $allmember);
		$this->display('groupuser.tpl');
	}
	
	function groupadduser(){
		$gid = get_request("gid");
		$allmember = $this->member_set->select_all(' uid NOT IN (SELECT uid FROM '.$this->member_set->get_table_name().' WHERE groupid='.$gid.') and level!=1 and level!=3 and level!=2 and level!=10');
		$this->assign("gid", $gid);
		$this->assign("title", language("增加用户"));
		$this->assign("allmember", $allmember);
		$this->display('groupadduser.tpl');
	}
	
	function groupadduser_save(){
		$gid = get_request("gid");
		$this->member_set->query("UPDATE ".$this->member_set->get_table_name()." SET groupid=".$gid." WHERE uid IN (".implode(',', $_POST['uid']).")");
		alert_and_back('添加成功','admin.php?controller=admin_member&action=groupuser&gid='.$gid);
	}
	
	
	
	function weektime(){
		$page_num = get_request('page');
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($orderby1)){
			$orderby1 = 'policyname';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);

		$where = '1=1';
		$row_num = $this->weektime_set->select_count($where);
		$newpager = new my_pager($row_num, $page_num, 20, 'page');
		$weektime = $this->weektime_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage, $where, $orderby1, $orderby2);
		$this->assign('title', language('周组策略列表'));
		$this->assign('weektime', $weektime);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->display('weektime.tpl');
	}
	
	function weektime_edit(){
		$sid = get_request("sid");
		$wt = $this->weektime_set->select_by_id($sid);
		$wt['start_time1']=substr($wt['start_time1'], 0, 5);
		$wt['end_time1']=substr($wt['end_time1'], 0, 5);
		$wt['start_time2']=substr($wt['start_time2'], 0, 5);
		$wt['end_time2']=substr($wt['end_time2'], 0, 5);
		$wt['start_time3']=substr($wt['start_time3'], 0, 5);
		$wt['end_time3']=substr($wt['end_time3'], 0, 5);
		$wt['start_time4']=substr($wt['start_time4'], 0, 5);
		$wt['end_time4']=substr($wt['end_time4'], 0, 5);
		$wt['start_time5']=substr($wt['start_time5'], 0, 5);
		$wt['end_time5']=substr($wt['end_time5'], 0, 5);
		$wt['start_time6']=substr($wt['start_time6'], 0, 5);
		$wt['end_time6']=substr($wt['end_time6'], 0, 5);
		$wt['start_time7']=substr($wt['start_time7'], 0, 5);
		$wt['end_time7']=substr($wt['end_time7'], 0, 5);
		$this->assign("title", language('添加周组策略'));
		$this->assign("wt", $wt);
		$this->display('weektime_edit.tpl');
	}
	
	function delete_weektime(){
		$sid = get_request("sid");
		$weektime = $this->weektime_set->select_by_id($sid);
		$a = $this->weektime_set->base_select("select sum(num) b FROM (SELECT count(*) as num FROM luser where weektime='".$weektime['policyname']."' 
		UNION SELECT count(*) as num FROM lgroup where weektime='".$weektime['policyname']."' 
		UNION SELECT count(*) as num FROM luser_devgrp where weektime='".$weektime['policyname']."' 
		UNION SELECT count(*) as num FROM luser where weektime='".$weektime['policyname']."') t");
		if($a[0]['b']>0){
			alert_and_back('该策略已被绑定,不能删除');
			exit;
		}
		$this->weektime_set->delete($sid);
		alert_and_back('删除成功','admin.php?controller=admin_member&action=weektime');
	}
	
	function weektime_save(){
		$sid = get_request("sid");
		$policyname = get_request("policyname", 1, 1);
		$s1 = get_request("start1", 1, 1);
		$e1 = get_request("end1", 1, 1);
		$s2 = get_request("start2", 1, 1);
		$e2 = get_request("end2", 1, 1);
		$s3 = get_request("start3", 1, 1);
		$e3 = get_request("end3", 1, 1);
		$s4 = get_request("start4", 1, 1);
		$e4 = get_request("end4", 1, 1);
		$s5 = get_request("start5", 1, 1);
		$e5 = get_request("end5", 1, 1);
		$s6 = get_request("start6", 1, 1);
		$e6 = get_request("end6", 1, 1);
		$s7 = get_request("start7", 1, 1);
		$e7 = get_request("end7", 1, 1);
		if(empty($s1)||empty($e1)||empty($s2)||empty($e2)||empty($s3)||empty($e3)||empty($s4)||empty($e4)||empty($s5)||empty($e5)||empty($s6)||empty($e6)||empty($s7)||empty($e7)){
			alert_and_back('请填写完整');
			exit;
		}
		
		$weektime = $this->weektime_set->select_by_id($sid);
		$a = $this->weektime_set->base_select("select sum(num) b FROM (SELECT count(*) as num FROM luser where weektime='".$weektime['policyname']."' 
		UNION SELECT count(*) as num FROM lgroup where weektime='".$weektime['policyname']."' 
		UNION SELECT count(*) as num FROM luser_devgrp where weektime='".$weektime['policyname']."' 
		UNION SELECT count(*) as num FROM luser where weektime='".$weektime['policyname']."') t");
		if($sid&&$policyname!=$weektime['policyname']&&$a[0]['b']>0){
			alert_and_back('该策略已被绑定,不能改名');
			exit;
		}
		
		$allgp = $this->weektime_set->select_all('policyname="'.$policyname.'" and sid!='.$sid);
		if(!empty($allgp)){
			alert_and_back('该策略名已经存在');
			exit;
		}
		
		$weektime = new weektime();
		$weektime->set_data('policyname', $policyname);
		$weektime->set_data('start_time1', $s1);
		$weektime->set_data('end_time1', $e1);
		$weektime->set_data('start_time2', $s2);
		$weektime->set_data('end_time2', $e2);
		$weektime->set_data('start_time3', $s3);
		$weektime->set_data('end_time3', $e3);
		$weektime->set_data('start_time4', $s4);
		$weektime->set_data('end_time4', $e4);
		$weektime->set_data('start_time5', $s5);
		$weektime->set_data('end_time5', $e5);
		$weektime->set_data('start_time6', $s6);
		$weektime->set_data('end_time6', $e6);
		$weektime->set_data('start_time7', $s7);
		$weektime->set_data('end_time7', $e7);
		if($sid){
			$weektime->set_data("sid", $sid);
			$this->weektime_set->edit($weektime);
			alert_and_back('修改成功');
			exit;
		}
		
		$this->weektime_set->add($weektime);
		alert_and_back('添加成功','admin.php?controller=admin_member&action=weektime');
	}
	
	function addgroup(){
		$gname = get_request("gname", 1, 1);
		if(empty($gname)){
			alert_and_back('请输入组名');
			exit;
		}
		$allgp = $this->usergroup_set->select_all('groupname="'.$gname.'"');
		if(!empty($allgp)){
			alert_and_back('该组名已经存在');
			exit;
		}
		
		$group = new usergroup();
		$group->set_data('groupname', $gname);
		$this->usergroup_set->add($group);
		alert_and_back('添加成功');
	}
	
	function loginlock() {
		$loginlock = get_request('loginlock', 0, 0);
		$uid = get_request('uid');
		$userinfo = $this->member_set->select_by_id($uid);
		if($userinfo['username'] == 'admin'){
			alert_and_back('管理员不允许被锁');
			exit;
		}
		$member = new member();
		$member->set_data('uid', $uid);
		$member->set_data('logintimes', ($loginlock ? 0 : 100));
		$member->set_data('loginlock', ($loginlock ? 0 : 1));
		$this->member_set->edit($member);
		alert_and_back('操作成功');
	}
	


	function delete() {
		global $_CONFIG;
		$uid = get_request('uid');
		$user = $this->member_set->select_by_id($uid);
		if($user['level']==11){
			$bindusers = $this->devpass_set->select_all("radiususer=".$uid);
			for($i=0; $i<count($bindusers); $i++){
				$bindip[]=$bindusers[$i]['device_ip'];
			}
			if(count($bindip)>0){
				alert_and_back('该用户已被下列ip绑定:\n'.implode('\n',$bindip), 'admin.php?controller=admin_member&action=radiususer');
				exit;
			}
		}
		if($_CONFIG['CREATE_LOG_USER'])
		$this->member_set->query("DELETE FROM ".LOG_DBNAME.".user WHERE username='".$user['username']."'");
		$this->member_set->query("DELETE FROM ".DBAUDIT_DBNAME.".member WHERE username='".$user['username']."'");
		$out = "";
		if($user['level'] == 0) {
			command("who | grep ".$user['username'],$out);
			if(count($out)<1 || $out == "" || 1) {
				if($user['username']=='password'){
					$cmd = "sudo /usr/sbin/userdel -r " . $user['username'];
					//echo $cmd;
					command($cmd, $out);	
				}
				
				$this->acgroup_set->delete($user['username'],'username');
				$this->radius_set->delete($user['username'],'username');
				$this->member_set->delete($uid);
				$this->luser_set->delete_all(' memberid='.$uid);
				$this->luser_resourcegrp_set->delete_all(' memberid='.$uid);
				/*
				$keys = $this->keys_set->select_all("UserName = '$user[username]'");
				$this->usbkey_set->release($keys[0]['pc_id']);
				$this->usbkey_set->remove($keys[0][pc_id]);
				*/
				$adminlog = new admin_log();
				$adminlog->set_data('luser', $user['username']);
				$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);
				$adminlog->set_data('action', language('删除'));
				$this->admin_log_set->add($adminlog);
				$radius = $this->radius_set->select_all("UserName='".$user['username']."'");
				for($i=0; $i<count($radius); $i++){
					$rid[]=$radius[$i]['id'];
				}
				if($rid){
					$this->radius_set->delete($rid);
				}
				
				$this->luser_set->query("DELETE FROM luser WHERE memberid=".$user['uid']);
				$this->luser_set->query("DELETE FROM luser_devgrp WHERE memberid=".$user['uid']);
				if($user['level']==11){
					alert_and_back('成功删除用户', 'admin.php?controller=admin_member&action=radiususer');
					exit;
				}else{
					alert_and_back('成功删除用户', 'admin.php?controller=admin_member');
					exit;
				}
			}
			else {
				if($user['level']==11){
					alert_and_back('用户还在线,无法删除', 'admin.php?controller=admin_member&action=radiususer');
					exit;
				}else{
					alert_and_back('用户还在线,无法删除', 'admin.php?controller=admin_member');
					exit;
				}
			}
		}
		else {
				$this->acgroup_set->delete($user['username'],'username');
				$this->member_set->delete($uid);
				
				$adminlog = new admin_log();
				$adminlog->set_data('luser', $user['username']);
				$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);
				$adminlog->set_data('action', language('删除'));
				$this->admin_log_set->add($adminlog);
				if($user['level']==11){
					alert_and_back('成功删除用户', 'admin.php?controller=admin_member&action=radiususer');
					exit;
				}else{
					alert_and_back('成功删除用户', 'admin.php?controller=admin_member');
					exit;
				}
		}
	}
	
	function save_self() {
		global $_CONFIG;
		$newmember = new member();
		$oripassword = get_request('oripassword', 1, 1);
		$password1 = get_request('password1', 1, 1);
		$password2 = get_request('password2', 1, 1);
		$default_control = get_request('default_control', 1, 0);
		$rdp_screen = get_request('rdp_screen', 1, 0);
		$login_tip = get_request('login_tip', 1, 1);
		$rdpdisk = get_request('rdpdisk', 1, 1);
		$searchcache = get_request('searchcache', 1, 0);
		
		$uid = $_SESSION['ADMIN_UID'];
		$user = $this->member_set->select_by_id($uid);
		$newmember->set_data('uid',$uid);		
		$newmember->set_data('rdp_screen', $rdp_screen);
		$newmember->set_data('searchcache', $searchcache);
		$newmember->set_data('login_tip', $login_tip);
		if($password1){
			$passlog = $this->passwordlog_set->select_count(" uid='$uid' and password=md5('$password1')");
			if($passlog>0){
				alert_and_back('改密码已经使用过,请重新选择');
				exit();
			}
		}
					
		if(!($password1 == "" && $password2 == "")) {
			
			$config = $this->setting_set->select_all(" sname='password_policy'");
			//var_dump($config);
			$pwdconfig = unserialize($config[0]['svalue']);
			$reg = '';
			//var_dump($pwdconfig);var_dump($password1);
			$pwdmsg = '';
			if(intval($pwdconfig['pwdstrong1'])>preg_match_all('/[0-9]/', $password1, $matches)){
				//alert_and_back('密码中需要包含数字');
				//exit;
				$pwdmsg .= '数字'." ";
			}
			if(intval($pwdconfig['pwdstrong2'])>preg_match_all('/[a-z]/', $password1, $matches)){
				//alert_and_back('密码中需要包含小写字母');
				//exit;
				$pwdmsg .= '小写字母'." ";
			}
			if(intval($pwdconfig['pwdstrong3'])>preg_match_all('/[A-Z]/', $password1, $matches)){
				//alert_and_back('密码中需要包含小写字母');
				//exit;
				$pwdmsg .= '大写字母'." ";
			}
			$pwd_replace = preg_replace('/[0-9a-zA-Z]/','', $password1);
			if(intval($pwdconfig['pwdstrong4'])>strlen($pwd_replace)){
				//alert_and_back('密码中需要包含特殊字符');
				//exit;
				$pwdmsg .= '特殊字符'." ";
			}
			if(strlen($password1) < $pwdconfig['login_pwd_length']){
				//alert_and_back(language('密码最少长度为').$pwdconfig['login_pwd_length']);
				//exit();
				$pwdmsgl = language('密码最少长度为').$pwdconfig['login_pwd_length'];
			}

			$pwd_ban_word_arr = explode('1', $_CONFIG['PASSWORD_BAN_WORD']);			
			if($pwd_ban_word_arr){
				$pwd_ban_word_str = implode(' ', $pwd_ban_word_arr);
			}
			for($pi=0; $pi<count($pwd_ban_word_arr); $pi++){
				if($pwd_ban_word_arr[$pi]&&strpos($password1, $pwd_ban_word_arr[$pi])!==false){
					$pwdmsg2='密码中不能包含以下字符:'.addslashes($pwd_ban_word_str).' \n请重新输入';
					break;
				}
			}
			if(!empty($pwdmsg) || !empty($pwdmsgl) || !empty($pwdmsg2)){
				if($pwdconfig['pwdstrong1'] || $pwdconfig['pwdstrong2'] || $pwdconfig['pwdstrong3'] || $pwdconfig['pwdstrong4']){
					$pwdmsgs .= '密码中需要包含:' .  ($pwdconfig['pwdstrong1'] ? $pwdconfig['pwdstrong1'].'个数字' : '').($pwdconfig['pwdstrong2'] ? $pwdconfig['pwdstrong2'].'个小写字母' : '').($pwdconfig['pwdstrong3'] ? $pwdconfig['pwdstrong3'].'个大写字母' : '').($pwdconfig['pwdstrong4'] ? $pwdconfig['pwdstrong4'].'个特殊字符' : ''). "\\n";
				}
				$pwdmsgs .= language('密码最少长度为').$pwdconfig['login_pwd_length']."\\n";
				if(count($pwd_ban_word_str)>0){
					$pwdmsgs .= '密码中不能包含以下字符:'.addslashes($pwd_ban_word_str).' \n\n请重新输入';
				}
				alert_and_back($pwdmsgs);
				exit;
			}

			if($oripassword!=$this->member_set->udf_decrypt($user['password'])){
				alert_and_back('原密码不正确');
				exit();
			}
			if($oripassword==$password1){
				alert_and_back('不能与原密码相同');
				exit();
			}
			if($password1 == $password2) {
				if($_CONFIG['crypt']==1){
					$password1 = encrypt($password1);
				}
				$newmember->set_data('password', $this->member_set->udf_encrypt($password1));
				$newmember->set_data('lastdateChpwd', mktime());
				$this->devpass_set->query("UPDATE ".$this->devpass_set->get_table_name()." SET old_password=cur_password,cur_password='".$this->devpass_set->udf_encrypt('"'.$password1.'"')."' WHERE username='".$user['username']."' AND radiususer=".$uid);
				
				$passwordlog = new passwordlog();
				$passwordlog->set_data('uid', $uid);
				$passwordlog->set_data('password', md5($password1));
				$passwordlog->set_data('time', mktime());
				$this->passwordlog_set->add($passwordlog);
				if($pwdconfig['oldpassnumber']&&($cpnum=$this->passwordlog_set->select_count("uid=".$passwordlog->get_data('uid')))>$pwdconfig['oldpassnumber']){
					$this->passwordlog_set->query("DELETE FROM ".$this->passwordlog_set->get_table_name()." WHERE uid=$uid ORDER BY id ASC LIMIT ".($cpnum-$pwdconfig['oldpassnumber']));
				}
			}
			else {
				alert_and_back('两次输入的密码不一致');
				exit();
			}

			
		}
		$newmember->set_data('email', get_request('email', 1, 1));
		$newmember->set_data('default_control', $default_control);
		$newmember->set_data('rdpdisk', $rdpdisk);
		
		
		//if($user['level'] == 0 || $_CONFIG["OTHER_MEMBER_RADIUS"]==1) 
		{
			$old_radius = $this->radius_set->select_all("UserName = '".$user['username']."'");
			$new_radius = new radius();
			$new_radius->set_data("id",$old_radius[0]['id']);
			$new_radius->set_data("email",$user['email']);
			if($newmember->get_data('password') != '') {
				$new_radius->set_data("Value",crypt($password1,"\$1\$qY9g/6K4"));
			}						
			$this->radius_set->edit($new_radius);
			

			//$cmd = "echo \"".$password1."\" | sudo passwd --stdin " . $user['username'];
			//echo $cmd;
			//command($cmd, $out);	
		}

		$url =  'admin.php?controller=admin_session&action=index';
		if($_SESSION['ADMIN_LEVEL']==10){
			$url = 'admin.php?controller=admin_index&action=main';
		}elseif($_SESSION['ADMIN_LEVEL']==0){
			$url = 'admin.php?controller=admin_index&action=main';
		}
		
		$newmember->set_data('sshprivatekey', $sshprivatekey);
		$newmember->set_data('sshpublickey', $sshpublickey);

		if($newmember->get_errnum() == 0) {
			$loguser = $this->member_set->base_select("SELECT * FROM ".LOG_DBNAME.".user where username='".$user['username']."'");
			if(!empty($loguser)){
				$sql = "UPDATE ".LOG_DBNAME.".user set password=md5('".$this->member_set->udf_decrypt($newmember->get_data('password'))."'),email='".$newmember->get_data('email')."' WHERE  username='".$user['username']."'";
				$this->member_set->query($sql);
			}
			$dbuser = $this->member_set->base_select("SELECT * FROM ".DBAUDIT_DBNAME.".member where username='".$user['username']."'");
			if(!empty($dbuser)){
				$sql = "UPDATE ".DBAUDIT_DBNAME.".member set password='".$newmember->get_data('password')."',realname='".$newmember->get_data('realname')."',email='".$newmember->get_data('email')."',default_control='".$newmember->get_data('default_control')."',lastdateChpwd='".mktime()."' where username='".$user['username']."'";				
				$this->member_set->query($sql);
			}
			$this->member_set->edit($newmember);
			if($user['level'] == 0) {
				alert_and_back('成功编辑个人信息','admin.php?controller=admin_index',0,1);
			}else{
				alert_and_back('成功编辑个人信息','admin.php?controller=admin_index',0,1);
			}
		}
	}
	
	function delete_all() {
		global $_CONFIG;
		$uid = get_request('chk_member', 1, 1);
		$usernames = $this->member_set->select_all(" uid IN (".implode(',', $uid).")");
		for($i=0; $i<count($usernames); $i++){
			$usernames_u[]=$usernames[$i]['username'];
		}
		$radius = $this->radius_set->select_all("UserName IN ('".implode("','",$usernames_u)."')");
		$this->member_set->query("DELETE FROM ".LOG_DBNAME.".user WHERE username IN ('".implode("','",$usernames_u)."')");
		$this->member_set->query("DELETE FROM ".DBAUDIT_DBNAME.".member WHERE username IN ('".implode("','",$usernames_u)."')");

		for($i=0; $i<count($radius); $i++){
			$rid[]=$radius[$i]['id'];
		}
		if($rid){
			$this->radius_set->delete($rid);
		}

		$this->member_set->delete($uid);
		
		$adminlog = new admin_log();
		$adminlog->set_data('luser', implode(',', $usernames_u));
		$adminlog->set_data('administrator', $_SESSION['ADMIN_USERNAME']);
		$adminlog->set_data('action', '删除');
		$this->admin_log_set->add($adminlog);
		
		alert_and_back('成功删除用户');
	}

	function update_user() {
		$out = '';
		command("cat /etc/passwd |cut -f 1 -d :", $out);
		$allpasswd = explode("\n", $out);
		return $allpasswd;
		
	}

	function protect_dev() {
		$uid = get_request('uid');
		$g_id = get_request('g_id');
		$type = get_request('type', 0, 1);
		if($type=='group'){
			$group = $this->usergroup_set->select_by_id($uid);	
			$this->assign('grouporuser',language('组名'));
			$this->assign('name',$group['GroupName']);
			$sql .= " SELECT devicesid FROM ".$this->lgroup_set->get_table_name()." WHERE groupid=".$uid;
			//$sql .= " UNION SELECT id FROM ".$this->devpass_set->get_table_name()." WHERE device_ip IN (SELECT b.device_ip FROM ".$this->lgroup_devgrp_set->get_table_name()." a LEFT JOIN ".$this->server_set->get_table_name()." b ON a.serversid=b.groupid WHERE a.groupid=".$uid.")";

		}else{
			$member = $this->member_set->select_by_id($uid);	
			$this->assign('grouporuser',language('用户名'));		
			$this->assign('name',$member['username']);
			$sql = "SELECT devicesid FROM ".$this->luser_set->get_table_name()." WHERE memberid=".$uid;
			//$sql .= " UNION SELECT devicesid FROM ".$this->lgroup_set->get_table_name()." WHERE groupid=".(int)$member['groupid'];
			//$sql .= " UNION SELECT id FROM ".$this->devpass_set->get_table_name()." WHERE device_ip IN (SELECT b.device_ip FROM ".$this->luser_devgrp_set->get_table_name()." a LEFT JOIN ".$this->server_set->get_table_name()." b ON a.serversid=b.groupid WHERE  a.memberid=".$uid.")";
			//$sql .= " UNION SELECT id FROM ".$this->devpass_set->get_table_name()." WHERE device_ip IN (SELECT b.device_ip FROM ".$this->lgroup_devgrp_set->get_table_name()." a LEFT JOIN ".$this->server_set->get_table_name()." b ON a.serversid=b.groupid WHERE a.groupid=".(int)$member['groupid'].")";
	
		}
		$alldev = $this->server_set->select_all("groupid = $g_id");
		if(count($alldev) == 0) {
			alert_and_back('该设备组没有设备',"admin.php?controller=admin_member&action=protect_group&uid=$uid");
			exit(0);
		}
			
		$allpass = $this->devpass_set->select_all(" id in (".$sql.")");
		$ip = '';
		$s_dev = array();
		if(!empty($allpass))
		foreach($allpass as $pass) {
			if($pass['device_ip'] != $ip) {
				$s_dev[] = $pass;
				$ip = $pass['device_ip'];
			}
		}
		$this->assign('title',language('选择要绑定的设备'));
		$this->assign('id',$uid);
		$this->assign('g_id',$g_id);
		$this->assign('s_dev',$s_dev);
		$this->assign('alldev',$alldev);
		$this->assign('type', $type);
		$this->assign('allpass',$allpass);
		$this->display('dev_user1.tpl');
	}

	function protect_group() {
		
		$type = get_request('type', 0, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);

		if(empty($orderby1)){
			$orderby1 = 'id';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);
		
		$alldevgroup = $this->sgroup_set->select_all(($_SESSION['ADMIN_LEVEL']==3 ? 'id=(SELECT mservergroup FROM member WHERE uid='.$_SESSION['ADMIN_UID'].')' : '1=1'), 'groupname', 'asc');
		if($type!='group'){
			$id = get_request('uid');
			$user = $this->member_set->select_by_id($id);
			$this->assign('username',$user['username']);
			$tpl = 'dev_group_user.tpl';
			$sql = "SELECT d.*,u.memberid,u.weektime,u.sourceip,u.forbidden_commands_groups,u.id AS lid FROM ".$this->devpass_set->get_table_name()." d LEFT JOIN ".$this->luser_set->get_table_name()." u ON d.id=u.devicesid WHERE u.memberid=$id ORDER BY $orderby1 $orderby2";
		}else{			
			$id = get_request('gid');
			$group = $this->usergroup_set->select_by_id($id);
			$this->assign('groupname',$group['GroupName']);
			$tpl = 'dev_group_group.tpl';
			$sql = "SELECT d.*,u.groupid,u.weektime,u.sourceip,u.forbidden_commands_groups,u.id AS lid FROM ".$this->devpass_set->get_table_name()." d LEFT JOIN ".$this->lgroup_set->get_table_name()." u ON d.id=u.devicesid WHERE u.groupid=$id ORDER BY $orderby1 $orderby2";
		}
		
		$allpass = $this->devpass_set->base_select($sql);
		
		$s_dev = array();
		$alltem = $this->tem_set->select_all();
		$allweektime = $this->weektime_set->select_all();
		$sourceip = $this->sourceip_set->select_all(" sourceip=''");
		$fcg = $this->forbiddengps_set->select_all('1=1', 'black_or_white','asc');
		if(!empty($allpass))
		foreach($allpass as $pass) {
			if($pass['device_ip'] != $ip) {
				$s_dev[] = $pass;
				$ip = $pass['device_ip'];
			}
		}
		$num = count($allpass);
		for($ii=0; $ii<$num; $ii++){
			foreach($alltem as $tem) {
					if($allpass[$ii]['login_method'] == $tem['id']) {
						$allpass[$ii]['login_method'] = $tem['login_method'];
					}
				
				}
			if(empty($allpass[$ii]['weektime'])){
				$allpass[$ii]['weektime'] = '';
			}
			if(empty($allpass[$ii]['sourceip'])){
				$allpass[$ii]['sourceip'] = '';
			}
			if(empty($allpass[$ii]['forbidden_commands_groups'])){
				$allpass[$ii]['forbidden_commands_groups'] = '';
			}
		}
		$this->assign('title',language('选择要绑定的设备'));
		$this->assign('id',$id);
		$this->assign("type", $type);
		$this->assign('s_dev',$s_dev);
		$this->assign('alldevgroup',$alldevgroup);
		$this->assign('allpass',$allpass);
		$this->display($tpl);
	}
	
	function protect_group_devgrp() {
		$gid = get_request('gid');
		$type = get_request('type', 0, 1);
		
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($orderby1)){
			$orderby1 = 'groupname';
		}
		if(strcasecmp($orderby2, 'asc') != 0 ) {
			$orderby2 = 'asc';
		}else{
			$orderby2 = 'desc';
		}
		$this->assign("orderby2", $orderby2);

		$group = $this->usergroup_set->select_by_id($gid);
		$sql = "SELECT s.*,u.groupid,u.weektime,u.sourceip,u.forbidden_commands_groups,u.id lgid FROM ".$this->sgroup_set->get_table_name()." s LEFT JOIN ".$this->lgroup_devgrp_set->get_table_name()." u ON s.id=u.serversid WHERE u.groupid=$gid ORDER BY $orderby1 $orderby2";

		$allpass = $this->sgroup_set->base_select($sql);
		$allweektime = $this->weektime_set->select_all();
		$sourceip = $this->sourceip_set->select_all(" sourceip=''");
		$fcg = $this->forbiddengps_set->select_all('1=1', 'black_or_white','asc');
		
		$num = count($allpass);
		for($ii=0; $ii<$num; $ii++){
			if(empty($allpass[$ii]['weektime'])){
				$allpass[$ii]['weektime'] = '';
			}else
			foreach($allweektime as $tem) {			
				if($allpass[$ii]['weektime'] == $tem['sid']) {
					$allpass[$ii]['weektime'] = $tem['policyname'];
				}
					
			}
			if(empty($allpass[$ii]['sourceip'])){
				$allpass[$ii]['sourceip'] = '';
			}
			if(empty($allpass[$ii]['forbidden_commands_groups'])){
				$allpass[$ii]['forbidden_commands_groups'] = '';
			}
		}
		$this->assign('title',language('选择要绑定的设备'));
		$this->assign('gid',$gid);
		$this->assign('groupname',$group['GroupName']);
		$this->assign('allpass',$allpass);
		$this->display('dev_group_sgroup.tpl');
	}

	function protect_group_resgrp() {
		$gid = get_request('gid');
		$type = get_request('type', 0, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($orderby1)){
			$orderby1 = 'id';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		$this->assign("orderby2", $orderby2);

		$group = $this->usergroup_set->select_by_id($gid);
		$sql = "SELECT s.*,u.groupid,u.weektime,u.sourceip,u.forbidden_commands_groups,u.id lgid FROM ".$this->resgroup_set->get_table_name()." s LEFT JOIN ".$this->lgroup_resourcegrp_set->get_table_name()." u ON s.id=u.resourceid WHERE u.groupid=$gid  ORDER BY $orderby1 $orderby2";

		$allpass = $this->sgroup_set->base_select($sql);
		$allweektime = $this->weektime_set->select_all();
		$sourceip = $this->sourceip_set->select_all(" sourceip=''");
		$fcg = $this->forbiddengps_set->select_all('1=1', 'black_or_white','asc');
		
		$num = count($allpass);
		for($ii=0; $ii<$num; $ii++){
			if(empty($allpass[$ii]['weektime'])){
				$allpass[$ii]['weektime'] = '';
			}else
			foreach($allweektime as $tem) {			
				if($allpass[$ii]['weektime'] == $tem['sid']) {
					$allpass[$ii]['weektime'] = $tem['policyname'];
				}
					
			}
			if(empty($allpass[$ii]['sourceip'])){
				$allpass[$ii]['sourceip'] = '';
			}
			if(empty($allpass[$ii]['forbidden_commands_groups'])){
				$allpass[$ii]['forbidden_commands_groups'] = '';
			}
		}
		$this->assign('title',language('选择要绑定的设备'));
		$this->assign('gid',$gid);
		$this->assign('groupname',$group['GroupName']);
		$this->assign('allpass',$allpass);
		$this->display('res_group_sgroup.tpl');
	}
	
	function protect_user_devgrp() {
		$uid = get_request('uid');
		$type = get_request('type', 0, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);

		if(empty($orderby1)){
			$orderby1 = 'groupname';
		}
		if(strcasecmp($orderby2, 'asc') != 0 ) {
			$orderby2 = 'asc';
		}else{
			$orderby2 = 'desc';
		}
		$this->assign("orderby2", $orderby2);

		$member = $this->member_set->select_by_id($uid);
		$sql = "SELECT s.*,u.weektime,u.sourceip,u.forbidden_commands_groups,u.id lgid FROM ".$this->sgroup_set->get_table_name()." s LEFT JOIN ".$this->luser_devgrp_set->get_table_name()." u ON s.id=u.serversid WHERE u.memberid=$uid ORDER BY $orderby1 $orderby2";
		
		$allpass = $this->sgroup_set->base_select($sql);
		$allweektime = $this->weektime_set->select_all();
		$sourceip = $this->sourceip_set->select_all(" sourceip=''");
		$fcg = $this->forbiddengps_set->select_all('1=1', 'black_or_white','asc');
		
		$num = count($allpass);
		for($ii=0; $ii<$num; $ii++){
		if(empty($allpass[$ii]['weektime'])){
			$allpass[$ii]['weektime'] = '';
		}
		if(empty($allpass[$ii]['sourceip'])){
			$allpass[$ii]['sourceip'] = '';
		}
		if(empty($allpass[$ii]['forbidden_commands_groups'])){
			$allpass[$ii]['forbidden_commands_groups'] = '';
		}
		}
		$this->assign('title',language('选择要绑定的设备'));
		$this->assign('uid',$uid);
		$this->assign('username',$member['username']);
		$this->assign('allpass',$allpass);
		$this->display('dev_user_devgrp.tpl');
	}

	function protect_user_resgrp() {
		$uid = get_request('uid');
		$type = get_request('type', 0, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);

		if(empty($orderby1)){
			$orderby1 = 'u.id';
		}
		if(strcasecmp($orderby2, 'desc') != 0 ) {
			$orderby2 = 'desc';
		}else{
			$orderby2 = 'asc';
		}
		if($orderby1=='groupname'){
			$orderby1='s.'.$orderby1;
		}
		$this->assign("orderby2", $orderby2);
		$member = $this->member_set->select_by_id($uid);
		$sql = "SELECT s.groupname,u.weektime,u.sourceip,u.forbidden_commands_groups,u.id lgid FROM ".$this->resgroup_set->get_table_name()." s LEFT JOIN ".$this->luser_resourcegrp_set->get_table_name()." u ON s.id=u.resourceid WHERE u.memberid=$uid ORDER BY $orderby1 $orderby2";
		
		$allpass = $this->resgroup_set->base_select($sql);
		$allweektime = $this->weektime_set->select_all();
		$sourceip = $this->sourceip_set->select_all(" sourceip=''");
		$fcg = $this->forbiddengps_set->select_all('1=1', 'black_or_white','asc');
		
		$num = count($allpass);
		for($ii=0; $ii<$num; $ii++){
		if(empty($allpass[$ii]['weektime'])){
			$allpass[$ii]['weektime'] = '';
		}
		if(empty($allpass[$ii]['sourceip'])){
			$allpass[$ii]['sourceip'] = '';
		}
		if(empty($allpass[$ii]['forbidden_commands_groups'])){
			$allpass[$ii]['forbidden_commands_groups'] = '';
		}
		}
		$this->assign('title',language('选择要绑定的设备'));
		$this->assign('uid',$uid);
		$this->assign('username',$member['username']);
		$this->assign('allpass',$allpass);
		$this->display('dev_user_resgrp.tpl');
	}
	
	function protect_user_edit(){
		$uid = get_request("uid");
		$sessionluser = 'PROTECTGROUP_LUSER';
		$member = $this->member_set->select_by_id($uid);
		$alldevgroup = $this->sgroup_set->select_all('1=1'.($_SESSION['ADMIN_LEVEL']==3 ? 'id=(SELECT mservergroup FROM member WHERE uid='.$_SESSION['ADMIN_UID'].')' : '1=1'), 'groupname', 'ASC');
		$lgroup = $this->luser_devgrp_set->select_all(' memberid='.$uid);
		for($i=0; $i<count($alldevgroup); $i++){
			for($j=0; $j<count($lgroup); $j++){
				if($alldevgroup[$i]['id']==$lgroup[$j]['serversid']&&$lgroup[$j]['memberid']==$uid){
					$alldevgroup[$i]['check']='checked';
				}
			}			
		}
		//echo '<pre>';print_r($alldevgroup);echo '</pre>';
		//echo '<pre>';print_r($lgroup);echo '</pre>';
		$_SESSION[$sessionluser] = $lgroup;
		$this->assign("uid", $uid);
		$this->assign("member", $member);
		$this->assign('sessionluser', $sessionluser);
		$this->assign('alldevgroup', $alldevgroup);
		$this->display('dev_select_userdevgrp.tpl');
	}

	function protect_user_resgrp_edit(){
		$uid = get_request("uid");
		$sessionluser = 'PROTECTGROUP_LUSER_RESOURCEGRP';
		$member = $this->member_set->select_by_id($uid);
		$alldevgroup = $this->resgroup_set->select_all('devicesid=0', 'groupname', 'ASC');
		$lgroup = $this->luser_resourcegrp_set->select_all(' memberid='.$uid);
		for($i=0; $i<count($alldevgroup); $i++){
			for($j=0; $j<count($lgroup); $j++){
				if($alldevgroup[$i]['id']==$lgroup[$j]['resourceid']&&$lgroup[$j]['memberid']==$uid){
					$alldevgroup[$i]['check']='checked';
				}
			}			
		}
		//echo '<pre>';print_r($alldevgroup);echo '</pre>';
		//echo '<pre>';print_r($lgroup);echo '</pre>';
		$_SESSION[$sessionluser] = $lgroup;
		$this->assign("uid", $uid);
		$this->assign("member", $member);
		$this->assign('sessionluser', $sessionluser);
		$this->assign('alldevgroup', $alldevgroup);
		$this->display('dev_select_userresgrp.tpl');
	}
	function protect_user_save(){
		$uid = get_request('uid');
		$sessionluser = get_request('sessionluser', 1, 1);
		$alldevgroup = $this->sgroup_set->select_all('1', 'groupname', 'asc');
		//echo $passcount;
		for($i = 0;$i<count($alldevgroup);$i++) {
			$alldevid[]=$alldevgroup[$i]['id'];
		}
		$lgroup = $this->luser_devgrp_set->select_all(' memberid='.$uid);		

		for($i = 0;$i<count($alldevgroup);$i++) {
			if(0 != get_request("Check$i",1,0)) {
				$idtmp[] = get_request("Check$i",1,0);
			}
		}	
		$this->luser_devgrp_save($sessionluser, $uid, $idtmp, $alldevid);	
	
		alert_and_back('操作成功',"admin.php?controller=admin_member&action=protect_user_devgrp&uid=".$uid);
	}

	function protect_user_resgrp_save(){
		$uid = get_request('uid');
		$sessionluser = get_request('sessionluser', 1, 1);
		$alldevgroup = $this->resgroup_set->select_all('devicesid=0');
		//echo $passcount;
		for($i = 0;$i<count($alldevgroup);$i++) {
			$alldevid[]=$alldevgroup[$i]['id'];
		}
		$lgroup = $this->luser_resourcegrp_set->select_all(' memberid='.$uid);		

		for($i = 0;$i<count($alldevgroup);$i++) {
			if(0 != get_request("Check$i",1,0)) {
				$idtmp[] = get_request("Check$i",1,0);
			}
		}	
		$this->luser_resgrp_save($sessionluser, $uid, $idtmp, $alldevid);	
	
		alert_and_back('操作成功',"admin.php?controller=admin_member&action=protect_user_resgrp&uid=".$uid);
	}
	
	function protect_group_edit(){
		$gid = get_request("gid");
		$sessionlgroup = 'PROTECTGROUP_LGROUP_RESGRP';
		$group = $this->usergroup_set->select_by_id($gid);
		$alldevgroup = $this->sgroup_set->select_all('1=1','groupname', 'ASC');
		$lgroup = $this->lgroup_devgrp_set->select_all(' groupid='.$gid);
		for($i=0; $i<count($alldevgroup); $i++){
			for($j=0; $j<count($lgroup); $j++){
				if($alldevgroup[$i]['id']==$lgroup[$j]['serversid']&&$lgroup[$j]['groupid']==$gid){
					$alldevgroup[$i]['check']='checked';
				}
			}			
		}
		//echo '<pre>';print_r($alldevgroup);echo '</pre>';
		//echo '<pre>';print_r($lgroup);echo '</pre>';
		$_SESSION[$sessionlgroup] = $lgroup;
		$this->assign("gid", $gid);
		$this->assign("group", $group);
		$this->assign('sessionlgroup', $sessionlgroup);
		$this->assign('alldevgroup', $alldevgroup);
		$this->display('dev_group.tpl');
	}

	function protect_group_resgrp_edit(){
		$gid = get_request("gid");
		$sessionlgroup = 'PROTECTGROUP_LGROUP_RESGRP';
		$group = $this->usergroup_set->select_by_id($gid);
		$alldevgroup = $this->resgroup_set->select_all('devicesid=0','groupname', 'ASC');
		$lgroup = $this->lgroup_resourcegrp_set->select_all(' groupid='.$gid);
		for($i=0; $i<count($alldevgroup); $i++){
			for($j=0; $j<count($lgroup); $j++){
				if($alldevgroup[$i]['id']==$lgroup[$j]['resourceid']&&$lgroup[$j]['groupid']==$gid){
					$alldevgroup[$i]['check']='checked';
				}
			}			
		}
		//echo '<pre>';print_r($alldevgroup);echo '</pre>';
		//echo '<pre>';print_r($lgroup);echo '</pre>';
		$_SESSION[$sessionlgroup] = $lgroup;
		$this->assign("gid", $gid);
		$this->assign("group", $group);
		$this->assign('sessionlgroup', $sessionlgroup);
		$this->assign('alldevgroup', $alldevgroup);
		$this->display('resource_group.tpl');
	}

	function protect_group_save(){
		$gid = get_request('gid');
		$sessionlgroup = get_request('sessionlgroup', 1, 1);
		$alldevgroup = $this->sgroup_set->select_all('1', 'groupname', 'asc');
		//echo $passcount;
		for($i = 0;$i<count($alldevgroup);$i++) {
			$alldevid[]=$alldevgroup[$i]['id'];
		}
		$lgroup = $this->lgroup_devgrp_set->select_all(' groupid='.$gid);		

		for($i = 0;$i<count($alldevgroup);$i++) {
			if(0 != get_request("Check$i",1,0)) {
				$idtmp[] = get_request("Check$i",1,0);
			}
		}	
		$this->lgroup_devgrp_save($sessionlgroup, $gid, $idtmp, $alldevid);	
		alert_and_back('操作成功',"admin.php?controller=admin_member&action=protect_group_devgrp&gid=".$gid);
	}

	function protect_group_resgrp_save(){
		$gid = get_request('gid');
		$sessionlgroup = get_request('sessionlgroup', 1, 1);
		$alldevgroup = $this->resgroup_set->select_all('devicesid=0');
		//echo $passcount;
		for($i = 0;$i<count($alldevgroup);$i++) {
			$alldevid[]=$alldevgroup[$i]['id'];
		}
		$lgroup = $this->lgroup_resourcegrp_set->select_all(' groupid='.$gid);		

		for($i = 0;$i<count($alldevgroup);$i++) {
			if(0 != get_request("Check$i",1,0)) {
				$idtmp[] = get_request("Check$i",1,0);
			}
		}	
		$this->lgroup_resgrp_save($sessionlgroup, $gid, $idtmp, $alldevid);	
		alert_and_back('操作成功',"admin.php?controller=admin_member&action=protect_group_resgrp&gid=".$gid);
	}
	
	private function luser_devgrp_save( $sessionluser, $uid, $bind, $all){
		$user[]=0;
		if(empty($bind)){
			$bind[0]=0;
		}
		$this->luser_devgrp_set->query("delete FROM ".$this->luser_devgrp_set->get_table_name()." WHERE serversid NOT IN(".implode(',',$bind).") AND memberid=$uid");
		
		for($i=0; $i<count($_SESSION[$sessionluser]); $i++){
			if(in_array($_SESSION[$sessionluser][$i]['serversid'], $bind)){
				$luser = new luser_devgrp();			
				$luser->set_data('weektime', $_SESSION[$sessionluser][$i]['weektime']);
				$luser->set_data('sourceip', $_SESSION[$sessionluser][$i]['sourceip']);
				$luser->set_data('memberid', $_SESSION[$sessionluser][$i]['memberid']);
				$luser->set_data('serversid', $_SESSION[$sessionluser][$i]['serversid']);
				$luser->set_data('forbidden_commands_groups', $_SESSION[$sessionluser][$i]['forbidden_commands_groups']);		
				if($_SESSION[$sessionluser][$i]['id']){
					$luser->set_data('id', $_SESSION[$sessionluser][$i]['id']);
					$this->luser_devgrp_set->edit($luser);
				}else{
					$this->luser_devgrp_set->add($luser);
				}
				$user[] = $_SESSION[$sessionluser][$i]['serversid'];
			}
		}
		
		if($bind)
		$u = array_diff($bind, $user);
		$dp = $this->config_set->base_select("SELECT * FROM defaultpolicy LIMIT 1");
		$dp = $dp[0];
		if($u)
		foreach($u AS $key => $value){
			$luser = new luser_devgrp();
			$luser->set_data('weektime', $dp['weektime']);
			$luser->set_data('sourceip', $dp['sourceip']);
			$luser->set_data('memberid', $uid);
			$luser->set_data('serversid', $value);
			$this->luser_devgrp_set->add($luser);
		}
		
		unset($_SESSION[$sessionluser]);
	}

	private function luser_resgrp_save( $sessionluser, $uid, $bind, $all){
		$user[]=0;
		if(empty($bind)){
			$bind[0]=0;
		}
		$this->luser_resourcegrp_set->query("delete FROM ".$this->luser_resourcegrp_set->get_table_name()." WHERE resourceid NOT IN(".implode(',',$bind).") AND memberid=$uid");
		
		for($i=0; $i<count($_SESSION[$sessionluser]); $i++){
			if(in_array($_SESSION[$sessionluser][$i]['resourceid'], $bind)){
				$luser = new luser_resourcegrp();			
				$luser->set_data('syslogalert', $_SESSION[$sessionluser][$i]['syslogalert']);
				$luser->set_data('mailalert', $_SESSION[$sessionluser][$i]['mailalert']);
				$luser->set_data('autosu', $_SESSION[$sessionluser][$i]['autosu']);
				$luser->set_data('loginlock', $_SESSION[$sessionluser][$i]['loginlock']);
				$luser->set_data('weektime', $_SESSION[$sessionluser][$i]['weektime']);
				$luser->set_data('sourceip', $_SESSION[$sessionluser][$i]['sourceip']);
				$luser->set_data('memberid', $_SESSION[$sessionluser][$i]['memberid']);
				$luser->set_data('resourceid', $_SESSION[$sessionluser][$i]['resourceid']);
				$luser->set_data('forbidden_commands_groups', $_SESSION[$sessionluser][$i]['forbidden_commands_groups']);
				if($_SESSION[$sessionluser][$i]['id']){
					$luser->set_data('id', $_SESSION[$sessionluser][$i]['id']);
					$this->luser_resourcegrp_set->edit($luser);
				}else{
					$this->luser_resourcegrp_set->add($luser);
				}
				$user[] = $_SESSION[$sessionluser][$i]['resourceid'];
			}
		}
		
		if($bind)
		$u = array_diff($bind, $user);
		$dp = $this->config_set->base_select("SELECT * FROM defaultpolicy LIMIT 1");
		$dp = $dp[0];
		if($u)
		foreach($u AS $key => $value){
			$luser = new luser_resourcegrp();
			$luser->set_data('syslogalert', $dp['syslogalert']);
			$luser->set_data('mailalert', $dp['mailalert']);
			$luser->set_data('autosu', $dp['autosu']);
			$luser->set_data('loginlock', $dp['loginlock']);
			$luser->set_data('weektime', $dp['weektime']);
			$luser->set_data('sourceip', $dp['sourceip']);
			$luser->set_data('memberid', $uid);
			$luser->set_data('resourceid', $value);
			$this->luser_resourcegrp_set->add($luser);
		}
		
		unset($_SESSION[$sessionluser]);
	}
	
	private function lgroup_devgrp_save( $sessionlgroup, $gid, $bind, $all){
		$user[]=0;
		if(empty($bind)){
			$bind[0]=0;
		}
		$this->lgroup_devgrp_set->query("delete FROM ".$this->lgroup_devgrp_set->get_table_name()." WHERE serversid NOT IN(".implode(',',$bind).") AND groupid=$gid");
		
		for($i=0; $i<count($_SESSION[$sessionlgroup]); $i++){
			if(in_array($_SESSION[$sessionlgroup][$i]['serversid'], $bind)){
				$luser = new lgroup_devgrp();			
				$luser->set_data('weektime', $_SESSION[$sessionlgroup][$i]['weektime']);
				$luser->set_data('sourceip', $_SESSION[$sessionlgroup][$i]['sourceip']);
				$luser->set_data('groupid', $_SESSION[$sessionlgroup][$i]['groupid']);
				$luser->set_data('serversid', $_SESSION[$sessionlgroup][$i]['serversid']);
				$luser->set_data('forbidden_commands_groups', $_SESSION[$sessionlgroup][$i]['forbidden_commands_groups']);		
				if($_SESSION[$sessionlgroup][$i]['id']){
					$luser->set_data('id', $_SESSION[$sessionlgroup][$i]['id']);
					$this->lgroup_devgrp_set->edit($luser);
				}else{
					$this->lgroup_devgrp_set->add($luser);
				}
				$user[] = $_SESSION[$sessionlgroup][$i]['serversid'];
			}
		}
		if($bind)
		$u = array_diff($bind, $user);
		$dp = $this->config_set->base_select("SELECT * FROM defaultpolicy LIMIT 1");
		$dp = $dp[0];
		if($u)
		foreach($u AS $key => $value){
			$luser = new lgroup_devgrp();
			$luser->set_data('weektime', $dp['weektime']);
			$luser->set_data('sourceip', $dp['sourceip']);
			$luser->set_data('groupid', $gid);
			$luser->set_data('serversid', $value);
			$this->lgroup_devgrp_set->add($luser);
		}
		
		unset($_SESSION[$sessionlgroup]);
	}

	private function lgroup_resgrp_save( $sessionlgroup, $gid, $bind, $all){
		$user[]=0;
		if(empty($bind)){
			$bind[0]=0;
		}
		$this->lgroup_resourcegrp_set->query("delete FROM ".$this->lgroup_resourcegrp_set->get_table_name()." WHERE resourceid NOT IN(".implode(',',$bind).") AND groupid=$gid");
		
		for($i=0; $i<count($_SESSION[$sessionlgroup]); $i++){
			if(in_array($_SESSION[$sessionlgroup][$i]['resourceid'], $bind)){
				$lgroup = new lgroup_resourcegrp();			
				$lgroup->set_data('syslogalert', $_SESSION[$sessionlgroup][$i]['syslogalert']);
				$lgroup->set_data('mailalert', $_SESSION[$sessionlgroup][$i]['mailalert']);
				$lgroup->set_data('autosu', $_SESSION[$sessionlgroup][$i]['autosu']);
				$lgroup->set_data('loginlock', $_SESSION[$sessionlgroup][$i]['loginlock']);
				$lgroup->set_data('weektime', $_SESSION[$sessionlgroup][$i]['weektime']);
				$lgroup->set_data('sourceip', $_SESSION[$sessionlgroup][$i]['sourceip']);
				$lgroup->set_data('groupid', $_SESSION[$sessionlgroup][$i]['groupid']);
				$lgroup->set_data('resourceid',$_SESSION[$sessionlgroup][$i]['resourceid']);
				$lgroup->set_data('forbidden_commands_groups', $_SESSION[$sessionlgroup][$i]['forbidden_commands_groups']);		
				if($_SESSION[$sessionlgroup][$i]['id']){
					$lgroup->set_data('id', $_SESSION[$sessionlgroup][$i]['id']);
					$this->lgroup_resourcegrp_set->edit($lgroup);
				}else{
					$this->lgroup_resourcegrp_set->add($lgroup);
				}
				$user[] = $_SESSION[$sessionlgroup][$i]['resourceid'];
			}
		}
		if($bind)
		$u = array_diff($bind, $user);
		$dp = $this->config_set->base_select("SELECT * FROM defaultpolicy LIMIT 1");
		$dp = $dp[0];
		if($u)
		foreach($u AS $key => $value){
			$lgroup = new lgroup_resourcegrp();
			$lgroup->set_data('syslogalert', $dp['syslogalert']);
			$lgroup->set_data('mailalert', $dp['mailalert']);
			$lgroup->set_data('autosu', $dp['autosu']);
			$lgroup->set_data('loginlock', $dp['loginlock']);
			$lgroup->set_data('weektime', $dp['weektime']);
			$lgroup->set_data('sourceip', $dp['sourceip']);
			$lgroup->set_data('groupid', $gid);
			$lgroup->set_data('resourceid', $value);
			$this->lgroup_resourcegrp_set->add($lgroup);
		}
		
		unset($_SESSION[$sessionlgroup]);
	}

	function protect_luser_devgrp_delete(){
		$id = get_request('id');
		if(empty($id)){
			$id = get_request('id', 1, 1);
		}
		$this->luser_devgrp_set->delete($id);
		alert_and_back('成功删除');
		
	}

	function protect_luser_resgrp_delete(){
		$id = get_request('id');
		if(empty($id)){
			$id = get_request('id', 1, 1);
		}
		$this->luser_resourcegrp_set->delete($id);
		alert_and_back('成功删除');
		
	}
	
	function protect_lgroup_devgrp_delete(){
		$id = get_request('id');
		if(empty($id)){
			$id = get_request('id', 1, 1);
		}
		$this->lgroup_devgrp_set->delete($id);
		alert_and_back('成功删除');
		
	}

	function protect_lgroup_resgrp_delete(){
		$id = get_request('id');
		if(empty($id)){
			$id = get_request('id', 1, 1);
		}
		$this->lgroup_resourcegrp_set->delete($id);
		alert_and_back('成功删除');
		
	}

	
	function protect_group_delete(){
		$id = get_request('id', 1, 1);
		$uid = get_request('uid', 1, 1);
		$type=get_request('type', 0, 1);
		switch($type){
			case 'luser':
				$this->luser_set->delete($id);
				$url = 'admin.php?controller=admin_member&action=protect_group&uid='.$uid;
				break;
			case 'luser-devgrp':
				$this->luser_devgrp_set->delete($id);
				$url = 'admin.php?controller=admin_member&action=protect_user_devgrp&uid='.$uid;
				break;
			case 'lgroup':
				$this->lgroup_set->delete($id);
				$url = 'admin.php?controller=admin_member&action=protect_group&type=group&gid='.$uid;
				break;			
			case 'lgroup-devgrp':
				$this->lgroup_devgrp_set->delete($id);
				$url = 'admin.php?controller=admin_member&action=protect_group_devgrp&gid='.$uid;
				break;
			case 'luser-resourcegrp':
				$this->luser_resourcegrp_set->delete($id);
				$url = 'admin.php?controller=admin_member&action=protect_user_resgrp_devgrp&uid='.$uid;
				break;
			case 'lgroup-resourcegrp':
				$this->lgroup_resourcegrp_set->delete($id);
				$url = 'admin.php?controller=admin_member&action=protect_group_resgrp&gid='.$uid;
				break;
		}
		alert_and_back('成功删除',$url);
		
	}

	function protect_edit() {
		$uid = get_request('uid');
		$ip = get_request('ip',0,1);
		$g_id = get_request('g_id');
		$member = $this->member_set->select_by_id($uid);
		$sessionluser = 'MEMBER_LUSER';
		if($ip == '') {
			$ip = get_request('ip',1,1);
		}
		$allpass = $this->devpass_set->select_all(" device_ip = '$ip'",'username', 'ASC');
		$alltem = $this->tem_set->select_all();
		//echo '<pre>';print_r($allpass);echo '</pre>';
		$num = count($allpass);
		if($num == 0) {
			alert_and_back('该设备还没有用户或IP输入错误',"admin.php?controller=admin_member&action=protect_dev&uid=$uid&g_id=$g_id");
			exit(0);
		}
		
		$allpassuser = array();
		for($ii=0; $ii < $num ; $ii++){//去掉重复
			if(empty($allpass[$ii][username])){
				$allpass[$ii][username]='空';
			}/*
			if(in_array($allpass[$ii][username],$allpassuser))
				continue;
			$allpassuser[]=$allpass[$ii][username];
			*/
			for($iii=0; $iii<count($alltem); $iii++){
				if($alltem[$iii]['id']==$allpass[$ii][login_method]){
					$allpass[$ii]['lmname'] = $alltem[$iii]['login_method'];
				}
			}
			$allpasstmp[]=$allpass[$ii];
			$allsid[]=$allpass[$ii]['id'];
		}

		$allluser = $this->luser_set->select_all('devicesid IN('.implode(',',$allsid).')');

		$allpass=$allpasstmp;
		for($j=0;$j<$num;$j++) {
			for($jj=0; $jj<count($allluser); $jj++){
				if($allluser[$jj]['memberid']==$uid&&$allluser[$jj]['devicesid']==$allpass[$j]['id']){
					//echo $_SESSION[$sessionluser][$jj]['memberid'];
					$allpass[$j]['check'] = 'checked';
					$_SESSION[$sessionluser][]=$allluser[$jj];
					break;
				}
			}			
		}		
		
		$this->assign('title',language('绑定托管用户'));
		$this->assign('ip',$ip);
		$this->assign('id',$uid);
		$this->assign('username',$member['username']);
		$this->assign("sessionluser", $sessionluser);
		$this->assign('allpass',$allpass);
		$this->assign('server_reference',$_SERVER['HTTP_REFERER']);
		$this->display('dev_user.tpl');
	}
	
	function protect_groupgrp() {
		$uid = get_request('uid');
		$ip = get_request('ip',0,1);
		$g_id = get_request('g_id');
		$group = $this->usergroup_set->select_by_id($uid);
		$alltem = $this->tem_set->select_all();
		$sessionlgroup = 'MEMBER_LGROUP';
		unset($_SESSION[$sessionlgroup]);
		if($ip == '') {
			$ip = get_request('ip',1,1);
		}
		$allpass = $this->devpass_set->select_all(" device_ip = '$ip'",'username', 'ASC');
		//echo '<pre>';print_r($allpass);echo '</pre>';
		$num = count($allpass);
		if($num == 0) {
			alert_and_back('该设备还没有用户或IP输入错误',"admin.php?controller=admin_member&action=protect_dev&uid=$uid&g_id=$g_id&type=group");
			exit(0);
		}
		
		$allpassuser = array();
		for($ii=0; $ii < $num ; $ii++){//去掉重复
			if(empty($allpass[$ii][username])){
				$allpass[$ii][username]='空';
			}/*
			if(in_array($allpass[$ii][username],$allpassuser))
				continue;
			$allpassuser[]=$allpass[$ii][username];
			*/
			for($iii=0; $iii<count($alltem); $iii++){
				if($alltem[$iii]['id']==$allpass[$ii][login_method]){
					$allpass[$ii]['lmname'] = $alltem[$iii]['login_method'];
				}
			}
			$allpasstmp[]=$allpass[$ii];
			$allsid[]=$allpass[$ii]['id'];
		}

		$alllgroup = $this->lgroup_set->select_all('devicesid IN('.implode(',',$allsid).')');

		$allpass=$allpasstmp;
		for($j=0;$j<$num;$j++) {
			for($jj=0; $jj<count($alllgroup); $jj++){
				if($alllgroup[$jj]['groupid']==$uid&&$alllgroup[$jj]['devicesid']==$allpass[$j]['id']){
					//echo $_SESSION[$sessionluser][$jj]['memberid'];
					$allpass[$j]['check'] = 'checked';
					$_SESSION[$sessionlgroup][]=$alllgroup[$jj];
					break;
				}
			}			
		}
		//echo '<pre>';print_r($allpass);echo '</pre>';		
		$this->assign('title',language('绑定托管用户'));
		$this->assign('ip',$ip);
		$this->assign('id',$uid);
		$this->assign('groupname',$group['GroupName']);
		$this->assign("sessionlgroup", $sessionlgroup);
		$this->assign('allpass',$allpass);
		$this->display('dev_user_group.tpl');
	}
	

	function protect_save() {
		$id = get_request('id');
		$ip = get_request('ip',0,1);
		$sessionluser = get_request('sessionluser', 1, 1);
		$devpass = '';
		$passcount = $this->devpass_set->select_count("device_ip = '$ip'");
		//echo $passcount;
		$olddev = $this->devpass_set->select_all("device_ip = '$ip'");
		for($i = 0;$i<$passcount;$i++) {
			$alldevid[]=$olddev[$i]['id'];
		}
		$allluser = $this->luser_set->select_all('devicesid IN('.implode(',',$alldevid).')');		
		
		//echo '<pre>';print_r($olddev);echo '</pre>';	
		for($j=0; $j<count($allluser); $j++){
			if(empty($alldevicebindnum[$allluser[$j]['devicesid']])){
				$alldevicebindnum[$allluser[$j]['devicesid']]=1;
			}else{
				$alldevicebindnum[$allluser[$j]['devicesid']]++;
			}
			$allluserid[] = $allluser[$i]['memberid'];
		}

		for($i = 0;$i<$passcount;$i++) {
			if(0 != get_request("Check$i",1,0)) {				
				$alldevicebindnum[get_request("Check$i",1,0)]++;
				if($alldevicebindnum[get_request("Check$i",1,0)]>20){
					$nopass[]=$olddev[$i]['username'];
				}else{
					$idtmp[] = get_request("Check$i",1,0);
				}
			}
		}		
				
		//print_r($_SESSION[$sessionluser]);print_r($idtmp);print_r($alldevicebindnum);print_r($nopass);
		$this->luser_save($sessionluser, $sessionlgroup, $id, $idtmp, $alldevid);
		if(count($nopass) == 0) {			
			alert_and_back('修改成功', 'admin.php?controller=admin_member&action=protect_group&uid='.$id);			
		}
		else{
			$nopass = implode(',',$nopass);
			alert_and_back(language("以下用户已绑定5个普通用户，绑定失败 ").":$nopass", 'admin.php?controller=admin_member');			
		}
	}
	
	function protect_groupgrp_save() {
		$id = get_request('id');
		$ip = get_request('ip',0,1);
		$sessionlgroup = get_request('sessionlgroup', 1, 1);
		$devpass = '';
		$passcount = $this->devpass_set->select_count("device_ip = '$ip'");
		//echo $passcount;
		$olddev = $this->devpass_set->select_all("device_ip = '$ip'");
		for($i = 0;$i<$passcount;$i++) {
			$alldevid[]=$olddev[$i]['id'];
		}
		$alllgroup = $this->lgroup_set->select_all('devicesid IN('.implode(',',$alldevid).')');		
		
		//echo '<pre>';print_r($olddev);echo '</pre>';	
		for($j=0; $j<count($alllgroup); $j++){
			if(empty($alldevicebindnum[$alllgroup[$j]['devicesid']])){
				$alldevicebindnum[$alllgroup[$j]['devicesid']]=1;
			}else{
				$alldevicebindnum[$alllgroup[$j]['devicesid']]++;
			}
			$allluserid[] = $alllgroup[$i]['memberid'];
		}

		for($i = 0;$i<$passcount;$i++) {
			if(0 != get_request("Check$i",1,0)) {				
				$alldevicebindnum[get_request("Check$i",1,0)]++;
				if($alldevicebindnum[get_request("Check$i",1,0)]>20){
					$nopass[]=$olddev[$i]['username'];
				}else{
					$idtmp[] = get_request("Check$i",1,0);
				}
			}
		}		
		
		//print_r($_SESSION[$sessionlgroup]);print_r($idtmp);print_r($alldevid);
		$this->lgroup_save( $sessionlgroup, $id, $idtmp, $alldevid);
		if(count($nopass) == 0) {			
			alert_and_back('修改成功', 'admin.php?controller=admin_member&action=protect_group&gid='.$id.'&type=group');			
		}
		else{
			$nopass = implode(',',$nopass);
			alert_and_back(language("以下用户已绑定5个普通用户，绑定失败 ").":$nopass", 'admin.php?controller=admin_member&action=usergroup');			
		}
	}
	
	private function luser_save($sessionluser, $sessionlgroup, $uid, $bind, $all){
		global $_CONFIG;
		$user[]=0;
		if(empty($bind)){
			$bind[0]=0;
			$release=$all;
		}else{
			$release = array_diff($all, $bind);
		}
		if(empty($release)){
			$release[]=0;
		}
		$this->luser_set->query("delete FROM ".$this->luser_set->get_table_name()." WHERE devicesid IN(".implode(',',$release).") AND memberid=$uid");
		
		for($i=0; $i<count($_SESSION[$sessionluser]); $i++){
			if(in_array($_SESSION[$sessionluser][$i]['devicesid'], $bind)){
				$luser = new luser();
				$luser->set_data('syslogalert', $_SESSION[$sessionluser][$i]['syslogalert']);
				$luser->set_data('mailalert', $_SESSION[$sessionluser][$i]['mailalert']);
				$luser->set_data('autosu', $_SESSION[$sessionluser][$i]['autosu']);
				$luser->set_data('loginlock', $_SESSION[$sessionluser][$i]['loginlock']);
				$luser->set_data('weektime', $_SESSION[$sessionluser][$i]['weektime']);
				$luser->set_data('sourceip', $_SESSION[$sessionluser][$i]['sourceip']);
				$luser->set_data('memberid', $_SESSION[$sessionluser][$i]['memberid']);
				$luser->set_data('devicesid', $_SESSION[$sessionluser][$i]['devicesid']);
				$luser->set_data('forbidden_commands_groups', $_SESSION[$sessionluser][$i]['forbidden_commands_groups']);
				
				$member = $this->member_set->select_by_id($_SESSION[$sessionluser][$i]['memberid']);
				$device = $this->devpass_set->select_by_id($_SESSION[$sessionluser][$i]['devicesid']);
				$sshprivatekey = $_CONFIG['PASSEDITSSHPRIVATEKEY'].'/'.$member['username'].'--'.$_SESSION[$sessionluser][$i]['devicesid'];
				if($device['publickey_auth']&&!file_exists($sshprivatekey)){				
					alert_and_back('请上传用户:"'.$device['username'].'"的私钥文件');
					exit;
				}
				if($this->sshprivatekey_set->select_count("memberid=".$_SESSION[$sessionluser][$i]['memberid']." and devicesid=".$_SESSION[$sessionluser][$i]['devicesid'])<=0){
					$newsshprivatekey = new sshprivatekey();
					$newsshprivatekey->set_data('memberid', $_SESSION[$sessionluser][$i]['memberid']);
					$newsshprivatekey->set_data('devicesid', $_SESSION[$sessionluser][$i]['devicesid']);
					$newsshprivatekey->set_data('path', $sshprivatekey);
					$this->sshprivatekey_set->add($newsshprivatekey);
				}else{
					$oldsshkey = $this->sshprivatekey_set->select_all("memberid=".$_SESSION[$sessionluser][$i]['memberid']." and devicesid=".$_SESSION[$sessionluser][$i]['devicesid']);
					$newsshprivatekey = new sshprivatekey();
					$newsshprivatekey->set_data('id', $oldsshkey[0]['id']);
					$newsshprivatekey->set_data('memberid', $_SESSION[$sessionluser][$i]['memberid']);
					$newsshprivatekey->set_data('devicesid', $_SESSION[$sessionluser][$i]['devicesid']);
					$newsshprivatekey->set_data('path', $sshprivatekey);
					$this->sshprivatekey_set->edit($newsshprivatekey);
				}
				if($_SESSION[$sessionluser][$i]['id']){
					$luser->set_data('id', $_SESSION[$sessionluser][$i]['id']);
					$this->luser_set->edit($luser);
				}else{
					$this->luser_set->add($luser);
				}
				$user[] = $_SESSION[$sessionluser][$i]['devicesid'];
			}
		}
		if($bind)
		$u = array_diff($bind, $user);
		$dp = $this->config_set->base_select("SELECT * FROM defaultpolicy LIMIT 1");
		$dp = $dp[0];
		if($u)
		foreach($u AS $key => $value){
			$luser = new luser();
			$luser->set_data('syslogalert', $dp['syslogalert']);
			$luser->set_data('mailalert', $dp['mailalert']);
			$luser->set_data('autosu', $dp['autosu']);
			$luser->set_data('loginlock', $dp['loginlock']);
			$luser->set_data('weektime', $dp['weektime']);
			$luser->set_data('sourceip', $dp['sourceip']);
			$luser->set_data('memberid', $uid);
			$luser->set_data('devicesid', $value);

			$member = $this->member_set->select_by_id($uid);
			$device = $this->devpass_set->select_by_id($value);
			$sshprivatekey = $_CONFIG['PASSEDITSSHPRIVATEKEY'].'/'.$member['username'].'--'.$value;
			if($device['publickey_auth']&&!file_exists($sshprivatekey)){				
				alert_and_back('请上传用户:"'.$device['username'].'"的私钥文件');
				exit;
			}
			if($this->sshprivatekey_set->select_count("memberid=".$uid." and devicesid=".$value)<=0){
				$newsshprivatekey = new sshprivatekey();
				$newsshprivatekey->set_data('memberid', $uid);
				$newsshprivatekey->set_data('devicesid', $value);
				$newsshprivatekey->set_data('path', $sshprivatekey);
				$this->sshprivatekey_set->add($newsshprivatekey);
			}else{
				$oldsshkey = $this->sshprivatekey_set->select_all("memberid=".$uid." and devicesid=".$value);
				$newsshprivatekey = new sshprivatekey();
				$newsshprivatekey->set_data('id', $oldsshkey[0]['id']);
				$newsshprivatekey->set_data('memberid', $value);
				$newsshprivatekey->set_data('devicesid', $sid);
				$newsshprivatekey->set_data('path', $sshprivatekey);
				$this->sshprivatekey_set->edit($newsshprivatekey);
			}

			$this->luser_set->add($luser);
		}
		
		unset($_SESSION[$sessionluser]);
	} 
	
	private function lgroup_save( $sessionlgroup, $gid, $bind, $all){
		$user[]=0;
		$release[]=0;
		if(empty($bind)){
			$bind[0]=0;
			$release = $all;
		}else{
			$release = array_diff($all, $bind);
		}
		if(empty($release)){
			$release[]=0;
		}
		
		$this->lgroup_set->query("delete FROM ".$this->lgroup_set->get_table_name()." WHERE devicesid IN(".implode(',',$release).") AND groupid=$gid");
		
		for($i=0; $i<count($_SESSION[$sessionlgroup]); $i++){
			if(in_array($_SESSION[$sessionlgroup][$i]['devicesid'], $bind)){
				$luser = new lgroup();
				$luser->set_data('syslogalert', $_SESSION[$sessionlgroup][$i]['syslogalert']);
				$luser->set_data('mailalert', $_SESSION[$sessionlgroup][$i]['mailalert']);
				$luser->set_data('autosu', $_SESSION[$sessionlgroup][$i]['autosu']);
				$luser->set_data('loginlock', $_SESSION[$sessionlgroup][$i]['loginlock']);
				$luser->set_data('weektime', $_SESSION[$sessionlgroup][$i]['weektime']);
				$luser->set_data('sourceip', $_SESSION[$sessionlgroup][$i]['sourceip']);
				$luser->set_data('groupid', $_SESSION[$sessionlgroup][$i]['groupid']);
				$luser->set_data('devicesid', $_SESSION[$sessionlgroup][$i]['devicesid']);
				$luser->set_data('forbidden_commands_groups', $_SESSION[$sessionlgroup][$i]['forbidden_commands_groups']);		
				if($_SESSION[$sessionlgroup][$i]['id']){
					$luser->set_data('id', $_SESSION[$sessionlgroup][$i]['id']);
					$this->lgroup_set->edit($luser);
				}else{
					$this->lgroup_set->add($luser);
				}
				$user[] = $_SESSION[$sessionlgroup][$i]['devicesid'];
			}
		}
		if($bind)
		$u = array_diff($bind, $user);
		$dp = $this->config_set->base_select("SELECT * FROM defaultpolicy LIMIT 1");
		$dp = $dp[0];
		if($u)
		foreach($u AS $key => $value){
			$luser = new lgroup();
			$luser->set_data('syslogalert', $dp['syslogalert']);
			$luser->set_data('mailalert', $dp['mailalert']);
			$luser->set_data('autosu', $dp['autosu']);
			$luser->set_data('loginlock', $dp['loginlock']);
			$luser->set_data('weektime', $dp['weektime']);
			$luser->set_data('sourceip', $dp['sourceip']);
			$luser->set_data('groupid', $gid);
			$luser->set_data('devicesid', $value);
			$this->lgroup_set->add($luser);
		}
		
		unset($_SESSION[$sessionlgroup]);
	} 

	function encryp($code) {
		$chars = preg_split('//', $code, -1, PREG_SPLIT_NO_EMPTY);
		$i=10;
		$result = array();
		foreach($chars as $char) {
			
			$result[] = ord($char) ^ $i;
			$i++;
		}
		$string = '';
		foreach($result as $char) {
			$string.= chr($char);
		}
		return $string;
	}

	function keys_index() {
		$page_num = get_request('page');
		$type = get_request('type');
		$ac = get_request('ac', 1, 1);
		$keyid = get_request('keyid', 1, 1);
		$username = get_request('username', 1, 1);
		$orderby1 = get_request('orderby1', 0, 1);
		$orderby2 = get_request('orderby2', 0, 1);
		if(empty($orderby1)){
			$orderby1 = 'keyid';
		}
		if(strcasecmp($orderby2, 'asc') != 0 ) {
			$orderby2 = 'asc';
		}else{
			$orderby2 = 'desc';
		}
		$this->assign("orderby2", $orderby2);

		$this->assign('type', $type);
		$key_set = $this->usbkey_set;
		$this->assign('title', 'usbkey'.language("列表"));
		/*if($ac == 'new'){
			$cmd = 'python /opt/freesvr/audit/bin/md5.py '.$keyid;
			$a = exec($cmd, $output, $return);
			//var_dump($a); 
			//print_r($output);//exit;
			$radkey = $this->radkey_set->select_all("keyid='".$keyid."'");
			$radkeyid = $radkey[0]['id'];
			if(empty($radkey)){
				$newradkey = new radkey();
				$newradkey->set_data('pc_index', $output[0]);
				$newradkey->set_data('keyid', $keyid);
				$newradkey->set_data('isused', '1');
				$newradkey->set_data('limittime', '2019-01-01');
				$this->radkey_set->add($newradkey);
				$radkeyid = mysql_insert_id();
			}else{
				alert_and_close('key id已经存在');
				exit;
			}			
			$cmd = 'cp /tmp/'.$keyid. ' /opt/freesvr/audit/usbkeys/'.$keyid;
			exec($cmd);
			alert_and_close('操作成功');
		}*/
		$where = '1=1';
		if($keyid){
			$where .= " AND keyid like '%".$keyid."%'";
		}

		if($username){
			$where .= " AND username like '%".$username."%'";
		}
		
		$row_num = $key_set->base_select("SELECT count(0) ct FROM ".$key_set->get_table_name().' k LEFT JOIN '.$this->member_set->get_table_name()." m ON k.keyid=m.usbkey WHERE $where");
		$row_num=$row_num[0]['ct'];
		$newpager = new my_pager($row_num, $page_num, 20, 'page', $where);
		//$allkeys = $key_set->select_limit($newpager->intStartPosition, $newpager->intItemsPerPage);
		$sql = "SELECT k.*,m.username FROM ".$key_set->get_table_name().' k LEFT JOIN '.$this->member_set->get_table_name()." m ON k.keyid=m.usbkey WHERE $where ORDER BY $orderby1 $orderby2 LIMIT $newpager->intStartPosition, $newpager->intItemsPerPage";
		$allkeys = $key_set->base_select($sql);

		$this->assign('allkeys', $allkeys);
		$this->assign('page_list', $newpager->showSerialList());
		$this->assign('total', $row_num);
		$this->assign('curr_page', $newpager->intCurrentPageNumber);
		$this->assign('total_page', $newpager->intTotalPageCount);
		$this->assign('items_per_page', $newpager->intItemsPerPage);
		$this->display('keys_list.tpl');
	}
	
	
	function keybinduser(){
		$keyid = get_request('keyid');
		$key = $this->usbkey_set->select_by_id($keyid);
		$keys = $this->usbkey_set->select_all();
		$members = $this->member_set->select_all("uid not in (SELECT radiususer FROM ".$this->devpass_set->get_table_name()." WHERE radiususer>0)");
		$num = count($members);
		for($i=0; $i<$num; $i++){
			for($j=0; $j<count($keys); $j++){
				if($members[$i]['usbkey']==$keys[$j]['keyid']){
					$members[$i]['usbkeystr'] = $keys[$j]['keyid'];
				}
			}
			if($members[$i]['usbkey']&&$members[$i]['usbkey']!=$keyid){
				$members[$i]['color']='red';
			}else{
				$members[$i]['color']='blue';
			}
		}
		$this->assign('keyid', $keyid);
		$this->assign('key', $key);
		$this->assign("allmem", $members);	
		$this->display('keybinduser.tpl');
	}
	
	function keybinduser_save(){
		$keyid = get_request('keyid');
		$member = get_request('member', 1, 1);
		$key = $this->usbkey_set->select_by_id($keyid);
		if($this->usbkey_set->query('UPDATE '.$this->member_set->get_table_name().' SET usbkey="'.$key[keyid].'",usbkeystatus=1 WHERE uid ='.$member)){
			$usbkey = new usbkey();
			$usbkey->set_data('id', $keyid);
			$usbkey->set_data('isused', 1);
			$this->usbkey_set->edit($usbkey);
			//$this->usbkey_set->query('UPDATE '.$this->member_set->get_table_name().' SET usbkey=0,usbkeystatus=0 WHERE uid ='.$member);
			alert_and_back("绑定成功", 'admin.php?controller=admin_member&action=keybinduser&keyid='.$keyid);
		}else{
			alert_and_back('绑定失败', 'admin.php?controller=admin_member&action=keybinduser&keyid='.$keyid);
		}		
	}

	function keys_delete() {
		//$type = get_request('type');
		$id = get_request('id');
		//if($type == 1) {
			$key_set = $this->usbkey_set;
		//}
		//else {
		//	$key_set = $this->wmkey_set;
		//}
		$key_set->delete($id);
		$key_set->remove($id);
		alert_and_back('删除成功', "admin.php?controller=admin_member&action=keys_index");
	}
	
	function create_file_usbkey(){
		$username = get_request('username', 0, 1);
		if(empty($username)){
			alert_and_close('没有用户名');
			exit;
		}
		$cmd = 'python /opt/freesvr/audit/bin/md5.py '.$username;
		$a = exec($cmd, $output, $return);
		//var_dump($a); 
		//print_r($output);//exit;
		$radkey = $this->radkey_set->select_all("keyid='".$username."'");
		$radkeyid = $radkey[0]['id'];
		if(empty($radkey)){
			$newradkey = new radkey();
			$newradkey->set_data('pc_index', $output[0]);
			$newradkey->set_data('keyid', $username);
			$newradkey->set_data('isused', '1');
			$newradkey->set_data('limittime', '2019-01-01');
			$this->radkey_set->add($newradkey);
			$radkeyid = mysql_insert_id();
		}else{
			$newradkey = new radius();
			$newradkey->set_data('id',	$radkeyid);
			$newradkey->set_data('pc_index', $output[0]);
			$this->radkey_set->edit($newradkey);
		}
		$memberinfo = $this->member_set->select_all("username='".$username."'");
		$newmember = new member();
		$newmember->set_data('uid', $memberinfo[0]['uid']);
		$newmember->set_data('usbkey', $radkeyid);
		$newmember->set_data('usbkeystatus', '1');
		$this->member_set->edit($newmember);
		$cmd = 'cp /tmp/'.$username. ' /opt/freesvr/audit/usbkeys/'.$username;
		exec($cmd);
		alert_and_close('操作成功');
		exit;
	}
	
	function importusbkey(){
		$this->display("importusbkey.tpl");
	}
	
	function doimportusbkey(){
		if($_FILES['usbkey']['error']==1 or $_FILES['usbkey']['error']==2){
			alert_and_back("上传得文件超过系统限制");
			exit;
		}
		if(!is_uploaded_file($_FILES['usbkey']['tmp_name']))
		{
			alert_and_back("请上传文件");
			exit;
		}
		$lines = file($_FILES['usbkey']['tmp_name']);
		
		$insertstr = "INSERT INTO ".$this->usbkey_set->get_table_name()."(keyid,isused,limittime,pc_index) values";
		$dateA3yearstamp = mktime(date('H'),date('i'),date('s'),date('m'),date('d'),date('Y')+3);
		$dateA3year = date('Y-m-d', $dateA3yearstamp);
		$j=0;
		for($i=0; $i<count($lines); $i++){
			if(trim($lines[$i])==""){
				continue;
			}

			$linearr = preg_split ("/\s{1,}/",trim($lines[$i]));
			if(count($linearr)>2){
				alert_and_back("文件非法,请重新上传正确的");
				exit;
			}
			if($this->usbkey_set->select_count("keyid='".$linearr[0]."'") > 0){
				$keyexists[]=$linearr[0]."\n";
				continue;
			}
			if($j!=0){
				$insertstr .=",";
			}
			$j++;
			$insertstr .= "('$linearr[0]','0','$dateA3year','$linearr[1]')";
		}
		
		if($j&&$this->usbkey_set->query($insertstr)){
			alert_and_back('导入成功', "admin.php?controller=admin_member&action=keys_index&type=1");
		}else{
			alert_and_back('导入失败,请检查文件, 重复的key:\n'.implode("", $keyexists));
		}
	}

	
	
	function userdisk(){
		//include "include/login_inc.php";
		//include "config/config_inc.php";
		//include "include/fun_inc.php";
		//include "language/$CFG_LANGUAGE"."_inc.php";
		//include "include/class_ftpquota_inc.php";
		require_once(ROOT . './include/class_ftpquota_inc.php');
		global $_CONFIG;
		$CFG_NETDISK_PATH = $_CONFIG['NETDISKPATH'];
		$user  = $this->member_set->select_by_id($_SESSION['ADMIN_UID']);
		$CFG_NETDISK_DEFAULT_QUOTA = $user['netdisksize'];						// MB
		$SG_USERNAME = $_SESSION['ADMIN_USERNAME'];

	$get_Cmd = $_GET['Cmd'];

	// 建立用户目录
	if(!is_dir("$CFG_NETDISK_PATH")) @mkdir("$CFG_NETDISK_PATH");
	if(!is_dir("$CFG_NETDISK_PATH/$SG_USERNAME")) @mkdir("$CFG_NETDISK_PATH/$SG_USERNAME");

	$netdisk_path = "$CFG_NETDISK_PATH/$SG_USERNAME";
	chdir($netdisk_path);

	switch($get_Cmd)
	{
		case 'download':
			$get_filename = $_GET['filename'];
			$get_path = $_GET['path'];
			
			$filename = "$netdisk_path/$get_path/$get_filename";
			$stat = @stat($filename);
			$size = $stat['size'];
			
			($FD_ATTACH = @fopen($filename,"r"))	|| die("Error open !filename");
		
			$buff = "";
			while($line = @fread($FD_ATTACH,4096)){
				
				$buff .= $line;
			}
			fclose($FD_ATTACH);
			
			header("Content-type: binary; name=\"$get_filename\"\n");
			header("Accept-Ranges: bytes\n");
			header("Content-Length: $size\n");
			header("Content-Disposition: attachment; filename=\"$get_filename\"\n\n");
			header("Pragma: public"); // for SSL
			header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
			header("Cache-Control: post-check=0, pre-check=0", false);
			//header("Pragma: no-cache");                          // HTTP/1.0 
			echo $buff;
			exit();
			break;
		
		case 'send':
			$get_filename = $_GET['filename'];
			$get_path = $_GET['path'];
			
			$filename = "$netdisk_path/$get_path/$get_filename";
			$attach = "$CFG_TEMP/$SG_DOMAIN/$SG_USERNAME/attach/$get_filename";
			$stat = @stat($filename);
			$size = $stat['size'];
			$type = "binary";
			
			if(@copy($filename, $attach)||@copy( $filename, $attach)){
				($FD_ATTACH = @fopen("$CFG_TEMP/$SG_DOMAIN/$SG_USERNAME/list_attach", "a")) || die("Error open !filename");
				fputs($FD_ATTACH, "$get_filename\t$size\t$type\n");
				fclose($FD_ATTACH);		
			}
			
			header("location: send.php");
			break;
			
		case 'mkdir':
			$post_dirname = $_POST['dirname'];
			$post_path = $_POST['path'];
			
			@chdir("$netdisk_path/$post_path");
			@mkdir($post_dirname);
			
			header("Location: admin.php?controller=admin_member&action=userdisk&cmd=list&path=$post_path");
			break;
			
		case 'Deldir':
			$get_dir = urldecode($_GET['dir']);
			$post_path = $_POST['path'];
			
			@rmdir("$netdisk_path/$post_path/".$get_dir);
			header("Location: admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$post_path");
			break;
				
		case 'Del':
			$get_filename = basename($_GET['filename']);
			$post_path = $_POST['path'];
			
			$file_stat = @stat($netdisk_path ."/$post_path/". $get_filename);
			$size = $file_stat['size'];
					
			unlink("$netdisk_path/$post_path/".$get_filename);
			
			$ftpquota = new FtpQuota($netdisk_path);
			$ftpquota->decFile($size);
			$ftpquota->close();
			
			header("Location: admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$post_path");
			break;
			
		case 'Add':
			// 处理上传的文件
			$upload 	 = $_FILES['upload']['tmp_name'];
			$upload_name = $_FILES['upload']['name'];
			$upload_size = $_FILES['upload']['size'];
			$upload_type = $_FILES['upload']['type'];

			$post_path = $_POST['path'];
			
			$ftpquota = new FtpQuota($netdisk_path);
			$ftpquota->plusFile($upload_size);
			if($ftpquota->fileTotalsize > $CFG_NETDISK_DEFAULT_QUOTA*1024*1024)
			{
					$ftpquota->decFile($size);
					 echo "<script>" .
					 "alert('空间不够!');" .
					 "document.location='admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$post_path';" .
					 "</script>";
					 exit;				
			}
			$ftpquota->close();		

			$dest = "$netdisk_path/$post_path/". $upload_name;
			if(is_file($dest))
			{
				$desttmp = $dest.time();
				@copy($upload,$desttmp);
				echo "<script>file=prompt('警告: 网络文件夹已有同名文件,请输入新文件名.','$get_saveas');
				if(file!='null' && file!='none'){
					//alert('admin.php?controller=admin_member&action=userdisk&Cmd=save&File=$desttmp&saveas='+file+'&url=$get_url');
					document.location = 'admin.php?controller=admin_member&action=userdisk&Cmd=save&File=$desttmp&path=$post_path&saveas='+file+'&url=$get_url';
			}
				</script>";
				exit();	
			}
			
			if (($upload<>"none")&&($upload<>"")){
				 
				 // 判断文件是否为正常文件
				 if (is_file($upload)!=1){
					 echo "<script>" .
					 "alert('文件不正常!');" .
					 "document.location='admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$post_path';" .
					 "</script>";
					 exit;	
				  }
				 
				 // 上传文件
				 //$dest = "$netdisk_path/".$post_path ."/". $upload_name;
				 if (@copy($upload, $dest))
				 @unlink($upload);
			}
				
			header("Location: admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$post_path");
			break;
			
		case 'save':
			$get_filename = $_GET['File'];
			$get_saveas   = $_GET['saveas'];
			$get_url = $_GET['url'];
		
			if($_GET['saveas']=='' || $_GET['saveas']=='null' || $_GET['saveas']=='none'){
				$get_saveas = $get_filename;
			}
			//var_dump($get_saveas);
			$dest = "$netdisk_path/". $get_saveas;
			
			$attach = "$get_filename";
			
			if(is_file($dest))
			{
				echo "<script>file=prompt('警告: 网络文件夹已有同名文件,请输入新文件名.','$get_saveas');
				if(file!='null' && file!='none')
					document.location = 'admin.php?controller=admin_member&action=userdisk&Cmd=save&File=$get_filename&saveas='+file+'&url=$get_url';
				</script>";
				exit();	
			}
			
			
			if(is_file($attach))
			{
				$attach_stat = @stat($attach);
				$ftpquota = new FtpQuota($netdisk_path);
				$ftpquota->plusFile($attach_stat['size']);
				if($ftpquota->fileTotalsize > $CFG_NETDISK_DEFAULT_QUOTA*1024*1024)
				{
						 echo "<script>" .
						 "alert('空间不够!');" .
						 "document.location='admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$post_path';" .
						 "</script>";
						 exit;				
				}
				$ftpquota->close();
				@copy($attach, $dest);

	echo "<script>alert('该附件已经存放到网络文件夹的根目录中');</script>";
			}
			
			echo "<script>document.location='admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$post_path'</script>";
			exit();
			break;		
	}


	// list
	$get_path = $_GET['path'];
	if($get_path=='/') $get_path='';

	$ListOut = '';
	$ListDir = '';
	$totalfile = 0;

	@chdir($netdisk_path ."/" . $get_path);
	$base_path = $netdisk_path ."/" . $get_path;
	$dh = @opendir($base_path);

	if ($dh = @opendir($base_path))
	{
		while (($file = readdir($dh)) !== false)
		{
			$file_type = filetype($base_path ."/". $file);

			$file_stat = @stat($base_path ."/". $file);
	//	    	print_r($file_stat);
			$size = $file_stat['size'];
			if($size>=1024*1024){
				$size = intval($size/(1024*1024)*10)/10;
				$size = $size." MB";
			}elseif($size>=1024) {
				$size = intval($size/(1024)*10)/10;
				$size = $size." KB";
			}else{
				$size = $size."Byte";
			}
			$mtime = date( "Y-m-d H:i:s", $file_stat['mtime']);
			
			$urlfile = urlencode($file);
			
			if($file!='.' && $file!='..')
			{
				if($file_type=='file' && $file!='.ftpquota')
				{
					$totalfile++;
					$type = '';
					$ListOut .= "<TR ALIGN='CENTER' >\n\t".
						"\t<TD><A HREF=\"admin.php?controller=admin_member&action=userdisk&Cmd=download&filename=$file&path=$get_path\">$file</A></TD>\n".
						"\t<TD>$type</TD>\n".
						"\t<TD NOWRAP>$size</TD>\n".
						"\t<TD NOWRAP>$mtime</TD>\n".
						"<TD align=center NOWRAP>".
						"</td><td align=center><A onClick='DelAddr(\"$file\");return false;' href=#>".
						"<IMG src=template/admin/images/trash.gif border=0 ALT='删除' width=14 height=14></A></TD>\n</TR>\n"; 
				}
				if($file_type=='dir')
				{
					$type = '文件夹';
					$size = '';
					$ListDir .= "<TR ALIGN='CENTER' >\n\t".
						"\t<TD><A HREF=\"admin.php?controller=admin_member&action=userdisk&Cmd=list&path=$get_path/$urlfile\">$file</A></TD>\n".
						"\t<TD>$type</TD>\n".
						"\t<TD NOWRAP>$size</TD>\n".
						"\t<TD NOWRAP>$mtime</TD>\n".
						"<TD NOWRAP align=center colspan=2>".
						"<A onClick='Deldir(\"$file\");return false;' href=#>".
						"<IMG src=template/admin/images/trash.gif border=0 ALT='删除' width=14 height=14></A></TD>\n</TR>\n";
				}
			}
		}
		closedir($dh);
	}

	$ListOut = $ListDir . $ListOut;

	$ftpquota = new FtpQuota($netdisk_path);
	$OUT['totalfile'] = $ftpquota->fileTotalNum;
	$OUT['totalsize'] = $ftpquota->fileTotalsize;

		$OUT['totalsize'] = intval($OUT['totalsize']/(1024*1024)*10)/10;
		$OUT['totalsize'] = $OUT['totalsize']."MB";

	$OUT['remain'] = $CFG_NETDISK_DEFAULT_QUOTA*1024*1024 - $ftpquota->fileTotalsize;
	if($OUT['remain']<0) $OUT['remain'] = 0;

		$OUT['remain'] = intval($OUT['remain']/(1024*1024)*10)/10;
			$OUT['remain'] = $OUT['remain']."MB";

		$OUT['pre_path'] = dirname($get_path);
		$OUT['LANG_FILE_DISK_QUOTA'] = $CFG_NETDISK_DEFAULT_QUOTA;

		$OUT['NICKNAME'] = $SG_NICKNAME;                    // 用户姓名
		$OUT['EMAIL']    = "$SG_USERNAME@$SG_DOMAIN";       // 用户email地址
		$OUT['path']     = $get_path;
		$OUT['pathname'] = $OUT['path'];
		if($OUT['pathname']=='') $OUT['pathname'] = '/';
		
		$this->assign("OUT", $OUT);
		$this->assign("ListOut", $ListOut);
		$this->display('userdisk.tpl');
	}

	function memberimport(){
		$this->display("memberimport.tpl");
	}
	
	function domemberimport(){
		set_time_limit(0);
		setlocale(LC_ALL, 'zh_CN');
		$levels = array(
			"普通用户" => '0',
			/*"管理员" => '1',
			"审计员" => '2',
			"组管理员" => '3',
			"密码管理员" => '10',*/
			'RADIUS用户' => '11'
		);
		$encrypt = get_request("encrypt", 1, 0);
		if($_FILES['devfile']['error']==1 or $_FILES['devfile']['error']==2){
			alert_and_back("上传得文件超过系统限制");
			exit;
		}
		if(!is_uploaded_file($_FILES['devfile']['tmp_name']))
		{
			alert_and_back("请上传文件");
			exit;
		}
		
		if (($handle = fopen($_FILES['devfile']['tmp_name'], "r")) !== FALSE) {
			while(($lines[] = fgetcsv($handle))!==false);
		}else{
			alert_and_back("打开文件失败");
			exit;
		}
		if(!$_SESSION['RADIUSUSERLIST']){
			if(iconv("GB2312", "UTF-8", trim($lines[0][0]))!='用户名' || iconv("GB2312", "UTF-8", trim($lines[0][1]))!='密码' || iconv("GB2312", "UTF-8", trim($lines[0][2]))!='真实姓名' || iconv("GB2312", "UTF-8", trim($lines[0][3]))!='电子邮箱'|| iconv("GB2312", "UTF-8", trim($lines[0][4]))!='等级'){
				alert_and_back("文件有问题，请上传正确的文件");
				exit;
			}
		}else{
			if(iconv("GB2312", "UTF-8", trim($lines[0][0]))!='用户名' || iconv("GB2312", "UTF-8", trim($lines[0][1]))!='密码'){
				alert_and_back("文件有问题，请上传正确的文件");
				exit;
			}
		}
		//var_dump($lines);
		//echo '<pre>';print_r($lines);echo '</pre>';exit;
		unset($_POST);
		$j=0;
		for($i=1; $i<count($lines); $i++){
			if(empty($lines[$i])){
				continue;
			}

			$linearr = $lines[$i];	
			for($ii=0; $ii<count($linearr); $ii++){
				$linearr[$ii]=iconv("GB2312", "UTF-8", $linearr[$ii]);
			}//var_dump($linearr);
			if(!$_SESSION['RADIUSUSERLIST']){
				$username=$linearr[0];
				$password=$linearr[1];
				$realname=$linearr[2];
				$email=$linearr[3];
				$level=(($levels[$linearr[4]]==0 or $levels[$linearr[4]]==11) ? $levels[$linearr[4]] : -1) ;
				$groupname=$linearr[5];
				$mobilenum=$linearr[6];
				$workcompany=$linearr[7];
				$workdepartment=$linearr[8];
				$vpn=$linearr[9];
				$vpnip=$linearr[10];
				$usbkey=$linearr[11];
			}else{
				$username=$linearr[0];
				$password=$linearr[1];
				$level = 11;
				$vpn=0;
			}
			if(empty($username)){
				continue;
			}

			$group = $this->usergroup_set->select_all("groupname='".$groupname."'");
			$groupid=$group[0]['id'];
			if(empty($group)&&!empty($groupname)){
				$newgroup = new usergroup();
				$newgroup->set_data("groupname", $groupname);
				$newgroup->set_data("priority", 0);
				$this->usergroup_set->add($newgroup);
				$groupid = mysql_insert_id();
			}
			$_POST['username'][$j]=$username;
			$_POST['password'][$j]=$password;
			$_POST['confirm_password'][$j]=$password;
			$_POST['level'][$j]=$level;
			$_POST['groupid'][$j]=$groupid;
			$_POST['mobilenum'][$j]=$mobilenum;
			$_POST['workdepartment'][$j]=$workdepartment;
			$_POST['workcompany'][$j]=$workcompany;
			$_POST['email'][$j]=$email;
			$_POST['realname'][$j]=$realname;
			$_POST['vpn'][$j]=$vpn;
			$_POST['vpnip'][$j]=$vpnip;
			$_POST['usbkey'][$j]=trim($usbkey," '");
			$j++;
		}
		
		$this->batchadd_save($encrypt);
		exit;
	}
	

	
}
?>
