<?php
function docronreports(){
	$host = "localhost";
	$username = "freesvr";
	$pwd = "freesvr";
	$db = "audit_sec";
	$link = mysql_connect($host, $username, $pwd);
	mysql_select_db($db);
	$filename_a = array("index"=>'ͳ�Ʊ���',"reportaudit_1"=>'�û���¼����',"reportaudit_2"=>'���������',"reportaudit_3"=>'FTP/SFTP�����',"reportaudit_4"=>'Oracle�����',"reportaudit_5"=>'DB2�����',"reportaudit_6"=>'Ӧ�ñ���',"logintims"=>'��¼ͳ��',"loginacct"=>'��¼��ϸ',"loginfailed"=>'��¼����');
	
	$rs = mysql_query("SELECT * FROM cronreports LIMIT 1");
	$ha = mysql_fetch_array($rs);
	$_GET['derive']=2;
	$_GET['derive_forcron']=1;
	if($ha[0]['week']){			
		$ha_week = explode(',', $ha[0]['week']);
		$_GET['f_rangeStart'] = date('Y-m-d H:i:s', mktime(0,0,0,date('m'),date('d')-date('w')-7,date('Y')));
		$_GET['f_rangeEnd'] = date('Y-m-d H:i:s', mktime(0,0,0,date('m'),date('d')+7,date('Y')));
		for($i=0; $i<count($ha_week); $i++){
			$pos = strpos($ha_week[$i], '_');
			if($pos===false){
				$prev=$ha_week[$i];
			}else{
				$prev = substr($ha_week[$i], 0, $pos);
				if($pos+1<=strlen($ha_week[$i]))
					$back = substr($ha_week[$i], $pos+1);
			}
			echo "week_".$ha_week[$i].'<br >';
			ob_start();
			switch($prev){
				case 'reportaudit':
					$_GET['number']=$back;
					$this->$prev();
					break;
				default:						
					$this->$prev();
					break;
					
			}
			$contents = ob_get_clean();
			file_put_contents("tmp/week_".$ha_week[$i].".html", $contents);
			$weekfile[]="tmp/week_".$ha_week[$i].".html";
		}
	}
	if($ha[0]['month']){			
		$ha_month = explode(',', $ha[0]['month']);
		$_GET['f_rangeStart'] = date('Y-m-d H:i:s', mktime(0,0,0,date('m')-1,1,date('Y')));
		$_GET['f_rangeEnd'] = date('Y-m-d H:i:s', mktime(0,0,0,date('m'),1,date('Y')));
		for($i=0; $i<count($ha_month); $i++){
			$pos = strpos($ha_month[$i], '_');
			if($pos===false){
				$prev=$ha_month[$i];
			}else{
				$prev = substr($ha_month[$i], 0, $pos);
				if($pos+1<=strlen($ha_month[$i]))
					$back = substr($ha_month[$i], $pos+1);
			}
			echo "month_".$ha_month[$i].'<br >';
			ob_start();
			switch($prev){
				case 'reportaudit':
					$_GET['number']=$back;
					$this->$prev();
					break;
				default:						
					$this->$prev();
					break;
					
			}
			$contents = ob_get_clean();
			file_put_contents("tmp/month_".$ha_month[$i].".html", $contents);
			$monthfile[]="tmp/week_".$ha_week[$i].".html";
		}		
	}
	if($weekfile||$monthfile){
		require_once 'include/emailattachfile.php';
		$rs = mysql_query("SELECT * FROM alarm LIMIT 1");
		$ha = mysql_fetch_array($rs);
		$e = new CSMTP($ha[0]['MailServer'],"25",$ha[0]['account'],$ha[0]['password']);
		$e -> linkSMTP(); 
		$e -> buildMail(array("netmwd@qq.com") ,"Hi Cay" ,"Just���� say hi!!�۹�����","text/html"); 
		for($i=0; $i<count($weekfile); $i++){
			$tmpfilename = substr($weekfile[$i],strpos($weekfile[$i],"_")+1);
			$tmpfilename = substr($tmpfilename, 0, strpos($tmpfilename, "."));
			$tmpfilename = $filename_a[$tmpfilename].".html";
			$e -> attachFile($weekfile[$i],'�ܱ�-'.$tmpfilename); 
		}
		for($i=0; $i<count($monthfile); $i++){
			$tmpfilename = substr($monthfile[$i],strpos($monthfile[$i],"_")+1);
			$tmpfilename = substr($tmpfilename, 0, strpos($tmpfilename, "."));
			$tmpfilename = $filename_a[$tmpfilename].".html";
			$e -> attachFile($monthfile[$i],'�±�-'.$tmpfilename); 
		}
		$e -> sendMail(); 
		$e -> quitSMTP();
	}
}
docronreports();
?>