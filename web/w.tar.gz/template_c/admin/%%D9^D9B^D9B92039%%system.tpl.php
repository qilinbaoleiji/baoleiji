<?php /* Smarty version 2.6.18, created on 2014-12-06 19:51:48
         compiled from system.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
<script src="./template/admin/cssjs/jscal2.js"></script>
<script src="./template/admin/cssjs/cn.js"></script>
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/jscal2.css" />
<script language="JavaScript">
window.onload=function(){
obj=new Date();
d=obj.getFullYear()+'-';
d+=(obj.getMonth()+1)<10?'0'+(obj.getMonth()+1):obj.getMonth()+1;
d+='-'+obj.getDate()+' '+obj.getHours()+':'+obj.getMinutes()+':'+obj.getSeconds();
form.dt.value=d;
}

function handle_delete() {
	//Because of bugs of IE, I need to define these variables explicitly.

	var delete_form;
	var page_id;
	var confirm_result;
	var table;

	table = document.getElementById("table");
	delete_form = document.getElementById("delete_form");
	page_id = document.getElementById("page_id");
	confirm_result = confirm("您确认要删除数据表" + table.value + "吗？");
	if (confirm_result) {
		page_id.value = "delete";
		delete_form.submit();
	}
}
</script>
</head>

<body>
<style type="text/css">
a {
    color: #003499;
    text-decoration: none;
} 
a:hover {
    color: #000000;
    text-decoration: underline;
}
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td valign="middle" class="hui_bj" >
	<div class="menu">
	<ul>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_slaveserver">探针管理</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li> 
<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_system">备份管理</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li> 
	</ul>
	</div>
</td>
</tr>
 <tr>
<td   width=100%>

	<table width=100%  class="BBtable">
	<?php $this->assign('trnumber', 0); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<form name="backup" action="admin.php?controller=admin_system&action=backup" METHOD=post>
  		 <td class="lighter" >
			      	<a class="myfont1">数据库备份，点击备份按钮对现有数据库进行备份:<a><br>
			        <a class="myfont1">备份将会清除目前数据表内容 </a>
					<input value="备份" class="myinput" type="submit">
		 </td>
		</form>
	</tr>
<?php $this->assign('trnumber', 0); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<form name="backup" action="admin.php?controller=admin_system&action=applog" METHOD=post>
  		 <td class="lighter" >
			      	<a class="myfont1">数据表applog备份，点击备份按钮对现有数据表applog进行备份:<a><br>
			        <a class="myfont1">备份将会清除目前applog数据表内容 </a>
					<input value="备份" class="myinput" type="submit">
		 </td>
		</form>
	</tr>
	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<form name="backup" action="admin.php?controller=admin_system&action=refresh_host" METHOD=post>
  	  		  <td class="lighter" width="85%">
				      <a class="myfont1">点击确认按钮更新新主机列表:<a><br>
				      <a class="myfont1">从选择的日志数据表中更新主机列表,可能需要数分钟:</a>
						<select name="logstable" id="logstable">
							<option value="log_logs">logs</option>
							<?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['r_alltable']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
							<option value="log_<?php echo $this->_tpl_vars['r_alltable'][$this->_sections['t']['index']]; ?>
">log_<?php echo $this->_tpl_vars['r_alltable'][$this->_sections['t']['index']]; ?>
</option>
							<?php endfor; endif; ?>
						</select>
						<input value="更新" class="myinput" type="submit">
			     </td>
		</form>
	</tr>

	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<form id="truncate_form" method="post" action="admin.php?controller=admin_system&action=truncate_alllogs">
  		      <td class="lighter" width="85%">
						
							 <a class="myfont1">清空alllogs数据表:<a>
			            	<input value="清空" class="myinput" type="submit">
			</td>
			
				<input type="hidden" name="pageId" value="" id="page_id">
		</form>
	</tr>
<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<form id="truncate_form" method="post" action="admin.php?controller=admin_system&action=truncate_applogs">
  		      <td class="lighter" width="85%">
						
							 <a class="myfont1">清空applog数据表:<a>
			            	<input value="清空" class="myinput" type="submit">
			</td>
			
				<input type="hidden" name="pageId" value="" id="page_id">
		</form>
	</tr>
	
	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
			<form id="delete_form" method="post" action="admin.php?controller=admin_system&action=delete_table" onsubmit="return false;">
  					<td class="lighter" width="85%">

							 <a class="myfont1">删除数据表:<a>
							<select name="table" id="table">
							<?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['alltable']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
							<option value="<?php echo $this->_tpl_vars['alltable'][$this->_sections['t']['index']]; ?>
"><?php echo $this->_tpl_vars['alltable'][$this->_sections['t']['index']]; ?>
</option>
							<?php endfor; endif; ?>
							</select>
			            	<input value="删除" class="myinput" type="button" onclick="JavaScript: handle_delete();">
					</td>
			
				<input type="hidden" name="pageId" value="" id="page_id">
		</form>
	</tr>

<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
			<form id="delete_form" method="post" action="admin.php?controller=admin_system&action=delete_table" onsubmit="return false;">
  					<td class="lighter" width="85%">

							 <a class="myfont1">删除applog数据表:<a>
							<select name="table" id="table">
							<?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['r_allapplogtable']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
							<option value="<?php echo $this->_tpl_vars['r_allapplogtable'][$this->_sections['t']['index']]; ?>
"><?php echo $this->_tpl_vars['r_allapplogtable'][$this->_sections['t']['index']]; ?>
</option>
							<?php endfor; endif; ?>
							</select>
			            	<input value="删除" class="myinput" type="button" onclick="JavaScript: handle_delete();">
					</td>
			
				<input type="hidden" name="pageId" value="" id="page_id">
		</form>
	</tr>

<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
			<form id="delete_form" method="post" action="admin.php?controller=admin_system&action=audit_server2log_hosts">
  					<td class="lighter" width="85%">

							 <a class="myfont1">从堡垒机系统里更新主机列表:<a>
							<input value="更新" class="myinput" type="submit">
					</td>
			
		</form>
	</tr>

	</table>
</form>
</td>


</tr>
</table>

 <script type="text/javascript">



function my_confirm(str){
	if(!confirm(str + "？"))
	{
		window.event.returnValue = false;
	}
}



</script>
</body>

</html>


