<?php /* Smarty version 2.6.18, created on 2014-11-30 20:05:34
         compiled from snmp_interface_log.tpl */ ?>
<?php echo '<?php'; ?>

//define("SEPARATE_PAGE",true);
require_once('dataprocess.php');
<?php echo '?>'; ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
<TITLE>OSSIM框架</TITLE>
<META content="text/html; charset=UTF-8" http-equiv=Content-Type>
<META content=no-cache http-equiv=Pragma>
<link href="template/admin/all_purpose_style.css" type="text/css" rel="stylesheet">
<STYLE>HTML {
	MARGIN: 0px; HEIGHT: 100%; FONT-SIZE: 12px
}
BODY {
	MARGIN: 0px; HEIGHT: 100%; FONT-SIZE: 12px
}
.mesWindow {
	BORDER-BOTTOM: #666 1px solid; BORDER-LEFT: #666 1px solid; BACKGROUND: #fff; BORDER-TOP: #666 1px solid; BORDER-RIGHT: #666 1px solid
}
.mesWindowTop {
	BORDER-BOTTOM: #eee 1px solid; TEXT-ALIGN: left; PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; MARGIN-LEFT: 4px; FONT-SIZE: 12px; FONT-WEIGHT: bold; PADDING-TOP: 3px
}
.mesWindowContent {
	MARGIN: 4px; FONT-SIZE: 12px
}
.mesWindow .close {
	BORDER-BOTTOM: medium none; BORDER-LEFT: medium none; WIDTH: 28px; BACKGROUND: #fff; HEIGHT: 15px; BORDER-TOP: medium none; CURSOR: pointer; BORDER-RIGHT: medium none; TEXT-DECORATION: underline
}
</STYLE>
<script>
function keyup(keycode){
	if(keycode==13){
		searchit();
	}
}
function searchit(){
	document.f1.action = "admin.php?controller=admin_thold&action=snmp_interface_log";
	document.f1.action += "&ip="+document.f1.ip.value;
	document.location=document.f1.action;
	return true;
}
</script>
</HEAD>
<BODY style="float:center">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
<?php if ($_GET['from'] != 'hostview'): ?>
  <tr>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0"  >
             <tr><td valign="middle" class="hui_bj"><div class="menu">
<ul>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_thold&action=snmp_status_warning_log">系统告警</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_thold&action=snmp_interface_log">流量告警</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_thold&action=app_warning_log">应用告警</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>

</ul>
</div></td></tr>

<tr>
	<td align="left" colspan = "7"><table width="100%" border="0" cellspacing="0" cellpadding="0"  class="main_content">

                <TBODY>
				 <TR>
                    <TD >
					<form name ='f1' action='admin.php?controller=admin_pro&action=dev_index' method=post onkeyup="keyup(event.keyCode);"  onsubmit="return false;">
					IP<input type="text" class="wbk" name="ip">
					&nbsp;&nbsp;<input  type="submit" value=" 搜 索 " onclick="return searchit();" class="bnnew2">
					</form>
					</TD>
                  </TR>
				  </table></td></tr><?php endif; ?>
      <tr  >
        <td class="">

		  <TABLE class=BBtable<?php if ($_GET['from'] == 'hostview'): ?>1<?php endif; ?> cellSpacing=0 cellPadding=0 width="100%"             align=center>
              <TBODY>
              <TR>
                <TD width="10%" class="list_bg<?php if ($_GET['from'] == 'hostview'): ?>1<?php endif; ?>"><a href = "admin.php?controller=admin_thold&action=snmp_interface_log&orderby1=device_ip&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
&from=<?php echo $_GET['from']; ?>
&ip=<?php echo $_GET['ip']; ?>
">设备IP</a></TD>
				<TD width="20%" class="list_bg<?php if ($_GET['from'] == 'hostview'): ?>1<?php endif; ?>"><a href = "admin.php?controller=admin_thold&action=snmp_interface_log&orderby1=datetime&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
&from=<?php echo $_GET['from']; ?>
&ip=<?php echo $_GET['ip']; ?>
">时间</a></TD>
                <TD width="10%"  class="list_bg<?php if ($_GET['from'] == 'hostview'): ?>1<?php endif; ?>"><a href = "admin.php?controller=admin_thold&action=snmp_interface_log&orderby1=port_index&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
&from=<?php echo $_GET['from']; ?>
&ip=<?php echo $_GET['ip']; ?>
">端口号</a></TD>
                <TD width=""  class="list_bg<?php if ($_GET['from'] == 'hostview'): ?>1<?php endif; ?>"><a href = "admin.php?controller=admin_thold&action=snmp_interface_log&orderby1=context&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
&from=<?php echo $_GET['from']; ?>
&ip=<?php echo $_GET['ip']; ?>
">告警内容</a></TD>
              </TR>
			<form action="" method="post">
			<?php unset($this->_sections['g']);
$this->_sections['g']['name'] = 'g';
$this->_sections['g']['loop'] = is_array($_loop=$this->_tpl_vars['tholdlist']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['g']['show'] = true;
$this->_sections['g']['max'] = $this->_sections['g']['loop'];
$this->_sections['g']['step'] = 1;
$this->_sections['g']['start'] = $this->_sections['g']['step'] > 0 ? 0 : $this->_sections['g']['loop']-1;
if ($this->_sections['g']['show']) {
    $this->_sections['g']['total'] = $this->_sections['g']['loop'];
    if ($this->_sections['g']['total'] == 0)
        $this->_sections['g']['show'] = false;
} else
    $this->_sections['g']['total'] = 0;
if ($this->_sections['g']['show']):

            for ($this->_sections['g']['index'] = $this->_sections['g']['start'], $this->_sections['g']['iteration'] = 1;
                 $this->_sections['g']['iteration'] <= $this->_sections['g']['total'];
                 $this->_sections['g']['index'] += $this->_sections['g']['step'], $this->_sections['g']['iteration']++):
$this->_sections['g']['rownum'] = $this->_sections['g']['iteration'];
$this->_sections['g']['index_prev'] = $this->_sections['g']['index'] - $this->_sections['g']['step'];
$this->_sections['g']['index_next'] = $this->_sections['g']['index'] + $this->_sections['g']['step'];
$this->_sections['g']['first']      = ($this->_sections['g']['iteration'] == 1);
$this->_sections['g']['last']       = ($this->_sections['g']['iteration'] == $this->_sections['g']['total']);
?>
			<TR bgcolor="f7f7f7">
			<TD class=""><?php echo $this->_tpl_vars['tholdlist'][$this->_sections['g']['index']]['device_ip']; ?>
</TD>
			<TD class="" style="text-align:left"><?php echo $this->_tpl_vars['tholdlist'][$this->_sections['g']['index']]['datetime']; ?>
</TD>
			<TD class="" style="text-align:left"><?php echo $this->_tpl_vars['tholdlist'][$this->_sections['g']['index']]['port_index']; ?>
</TD>
			<TD class="" style="text-align:left"><?php echo $this->_tpl_vars['tholdlist'][$this->_sections['g']['index']]['context']; ?>
</TD>	
			</TR>
			<?php endfor; endif; ?>
			<tr><td colspan="7" align="right">&nbsp&nbsp;&nbsp;共<?php echo $this->_tpl_vars['total']; ?>
个记录  <?php echo $this->_tpl_vars['page_list']; ?>
  页次：<?php echo $this->_tpl_vars['curr_page']; ?>
/<?php echo $this->_tpl_vars['total_page']; ?>
页  <?php echo $this->_tpl_vars['items_per_page']; ?>
个记录/页  转到第<input name="pagenum" type="text" class="wbk" size="2" onKeyPress="if(event.keyCode==13) window.location='admin.php?controller=admin_thold&action=status_thold&page='+this.value;">页&nbsp;&nbsp;&nbsp;<?php if ($_SESSION['ADMIN_LEVEL'] == 3): ?><a href="<?php echo $this->_tpl_vars['curr_url']; ?>
&derive=1" target="hide"><?php echo $this->_tpl_vars['language']['ExportresulttoExcel']; ?>
</a><?php endif; ?></td></tr>
			</form>
			</TBODY>
		</TABLE>
  
    
		  </td>
      </tr>
	  <tr><td cellpadding="3" height="15" align="right"></td></tr>
    </table></td>
  </tr>
  <tr><td height="10"></td></tr>
</table>



</BODY></HTML>
