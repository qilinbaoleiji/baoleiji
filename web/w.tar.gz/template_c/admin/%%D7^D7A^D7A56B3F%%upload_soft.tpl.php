<?php /* Smarty version 2.6.18, created on 2014-11-09 20:55:42
         compiled from upload_soft.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['site_title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
<script>
function resto()
{
 if(document.getElementById('filesql').value=='' ){
   alert("<?php echo $this->_tpl_vars['language']['UploadFile']; ?>
");
   return false;
  }
  return true;
}
</script>
<style type="text/css">
a {
    color: #003499;
    text-decoration: none;
} 
a:hover {
    color: #000000;
    text-decoration: underline;
}
</style>
</head>

<body>


<table width="100%" border="0" cellspacing="0" cellpadding="0">
	 <tr><td valign="middle" class="hui_bj"><div class="menu">
<ul>

	<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=tool_list">工具下载</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
</ul><span class="back_img"><A href="admin.php?controller=admin_index&action=tool_list&back=1"><IMG src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/back1.png" 
      width="80" height="30" border="0"></A></span>
</div></td></tr>
  <tr>
	<td class="">
		<table bordercolor="white" cellspacing="0" cellpadding="5" border="0" width="100%"  class="BBtable">
		 <tr><th colspan="3" class="list_bg"></th></tr>
		<tr><td>
			<form name="backup" enctype="multipart/form-data" action="admin.php?controller=admin_index&action=upload_tool" method="post">
			<div align="center">文件：<input name="key" id="filesql" type="file" /></div>
			<div align="center"><input name="submit" type="submit" onclick="return resto();"  value="提交" / class="an_02"></div>
			<input type="hidden" name="ac" value="upload" />
			</form></td></tr>
		</table>
	</td>
  </tr>
</table>
</body>
</html>

