<?php /* Smarty version 2.6.18, created on 2014-12-02 14:10:23
         compiled from snmp_alert_edit.tpl */ ?>
 <html>
<head>
  <title> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
 <link href="template/admin/all_purpose_style.css" type="text/css" rel="stylesheet">
</head>
<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >

  <tr>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0"  >
             <tr><td valign="middle" class="hui_bj"><div class="menu">
<ul>
<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_thold&action=snmp_alert">告警配置</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_configure&action=snmp_interface">接口设置</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>

</ul><span class="back_img"><A href="javascript:history.back();"><IMG src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/back1.png" 
      width="80" height="25" border="0"></A></span>
</div></td></tr>
<tr><td>
    <form method="post" name="newform" action="admin.php?controller=admin_thold&action=snmp_alert_save&id=<?php echo $this->_tpl_vars['alert']['seq']; ?>
">
    <table border=0 width=100% cellpadding=5 cellspacing=0 bgcolor="#FFFFFF" valign=top class="BBtable">
      <input type="hidden" name="ac" value="update">
<?php $this->assign('trnumber', 0); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td align=right> 
    名称</td>
    <td class="left">
      <input type="text" value="<?php echo $this->_tpl_vars['alert']['name']; ?>
" size="25" name="name" id="name" >
    </td>
  </tr>
 <?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td align=right> 允许</td>
    <td class="left"><input type="radio" value="1" size="25" name="enable" id="enable" <?php if ($this->_tpl_vars['alert']['enable']): ?>checked<?php endif; ?>>是 <input type="radio" value="0" size="25" name="enable" id="enable" <?php if (! $this->_tpl_vars['alert']['enable']): ?>checked<?php endif; ?>>否
    </td>
  </tr>
<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td align=right> 
    设备组</td>
    <td class="left">
     <select name='groupid' >
					<option value="0">全部设备</option>
					<?php unset($this->_sections['g']);
$this->_sections['g']['name'] = 'g';
$this->_sections['g']['loop'] = is_array($_loop=$this->_tpl_vars['group']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['g']['show'] = true;
$this->_sections['g']['max'] = $this->_sections['g']['loop'];
$this->_sections['g']['step'] = 1;
$this->_sections['g']['start'] = $this->_sections['g']['step'] > 0 ? 0 : $this->_sections['g']['loop']-1;
if ($this->_sections['g']['show']) {
    $this->_sections['g']['total'] = $this->_sections['g']['loop'];
    if ($this->_sections['g']['total'] == 0)
        $this->_sections['g']['show'] = false;
} else
    $this->_sections['g']['total'] = 0;
if ($this->_sections['g']['show']):

            for ($this->_sections['g']['index'] = $this->_sections['g']['start'], $this->_sections['g']['iteration'] = 1;
                 $this->_sections['g']['iteration'] <= $this->_sections['g']['total'];
                 $this->_sections['g']['index'] += $this->_sections['g']['step'], $this->_sections['g']['iteration']++):
$this->_sections['g']['rownum'] = $this->_sections['g']['iteration'];
$this->_sections['g']['index_prev'] = $this->_sections['g']['index'] - $this->_sections['g']['step'];
$this->_sections['g']['index_next'] = $this->_sections['g']['index'] + $this->_sections['g']['step'];
$this->_sections['g']['first']      = ($this->_sections['g']['iteration'] == 1);
$this->_sections['g']['last']       = ($this->_sections['g']['iteration'] == $this->_sections['g']['total']);
?>
					<option value="<?php echo $this->_tpl_vars['group'][$this->_sections['g']['index']]['id']; ?>
" <?php if ($this->_tpl_vars['alert']['groupid'] == $this->_tpl_vars['group'][$this->_sections['g']['index']]['id']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['group'][$this->_sections['g']['index']]['groupname']; ?>
</option>
					<?php endfor; endif; ?>
					</select>
    </td>
  </tr>
  <?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td align=right> 是否邮件告警</td>
    <td class="left">
       <input type="radio" value="1" size="25" name="mail_alarm" id="mail_alarm" <?php if ($this->_tpl_vars['alert']['mail_alarm']): ?>checked<?php endif; ?>>是 <input type="radio" value="0" size="25" name="mail_alarm" id="mail_alarm" <?php if (! $this->_tpl_vars['alert']['mail_alarm']): ?>checked<?php endif; ?>>否
    </td>
  </tr>
  <?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td align=right> 是否短信告警</td>
    <td class="left">
       <input type="radio" value="1" size="25" name="sms_alarm" id="sms_alarm" <?php if ($this->_tpl_vars['alert']['sms_alarm']): ?>checked<?php endif; ?>>是 <input type="radio" value="0" size="25" name="sms_alarm" id="sms_alarm" <?php if (! $this->_tpl_vars['alert']['sms_alarm']): ?>checked<?php endif; ?>>否
    </td>
  </tr>
<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td align=right> 
    告警周期</td>
    <td class="left">
      <input type="text" value="<?php echo $this->_tpl_vars['alert']['period']; ?>
" size="25" name="period" id="period" >分钟
    </td>
  </tr>
 
<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td align=right> 告警项</td>
    <td class="left">
       <select name="alertitem">
	   <option value="system" <?php if ($this->_tpl_vars['alert']['alertitem'] == 'system'): ?>selected<?php endif; ?>>系统</option>
	   <option value="network" <?php if ($this->_tpl_vars['alert']['alertitem'] == 'network'): ?>selected<?php endif; ?>>网络</option>
	   <option value="app" <?php if ($this->_tpl_vars['alert']['alertitem'] == 'app'): ?>selected<?php endif; ?>>应用</option>
	   </select>
    </td>
  </tr>
  <?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<td width="33%" align=right  valign=top>
		<?php echo $this->_tpl_vars['language']['bind']; ?>
<?php echo $this->_tpl_vars['language']['User']; ?>

		</td>
		<td width="67%">
		<table><tr >
		<?php unset($this->_sections['g']);
$this->_sections['g']['name'] = 'g';
$this->_sections['g']['loop'] = is_array($_loop=$this->_tpl_vars['allmem']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['g']['show'] = true;
$this->_sections['g']['max'] = $this->_sections['g']['loop'];
$this->_sections['g']['step'] = 1;
$this->_sections['g']['start'] = $this->_sections['g']['step'] > 0 ? 0 : $this->_sections['g']['loop']-1;
if ($this->_sections['g']['show']) {
    $this->_sections['g']['total'] = $this->_sections['g']['loop'];
    if ($this->_sections['g']['total'] == 0)
        $this->_sections['g']['show'] = false;
} else
    $this->_sections['g']['total'] = 0;
if ($this->_sections['g']['show']):

            for ($this->_sections['g']['index'] = $this->_sections['g']['start'], $this->_sections['g']['iteration'] = 1;
                 $this->_sections['g']['iteration'] <= $this->_sections['g']['total'];
                 $this->_sections['g']['index'] += $this->_sections['g']['step'], $this->_sections['g']['iteration']++):
$this->_sections['g']['rownum'] = $this->_sections['g']['iteration'];
$this->_sections['g']['index_prev'] = $this->_sections['g']['index'] - $this->_sections['g']['step'];
$this->_sections['g']['index_next'] = $this->_sections['g']['index'] + $this->_sections['g']['step'];
$this->_sections['g']['first']      = ($this->_sections['g']['iteration'] == 1);
$this->_sections['g']['last']       = ($this->_sections['g']['iteration'] == $this->_sections['g']['total']);
?>
		<td width="150"><input type="checkbox" name='memberid[]' value='<?php echo $this->_tpl_vars['allmem'][$this->_sections['g']['index']]['uid']; ?>
'  <?php if ($this->_tpl_vars['allmem'][$this->_sections['g']['index']]['check']): ?>checked<?php endif; ?>><?php echo $this->_tpl_vars['allmem'][$this->_sections['g']['index']]['username']; ?>
(<?php if ($this->_tpl_vars['allmem'][$this->_sections['g']['index']]['realname']): ?><?php echo $this->_tpl_vars['allmem'][$this->_sections['g']['index']]['realname']; ?>
<?php else: ?>未设置<?php endif; ?>)</a></td><?php if (( $this->_sections['g']['index'] + 1 ) % 5 == 0): ?></tr><tr><?php endif; ?>
		<?php endfor; endif; ?>
		</tr></table>
	  </td>
	  </tr>
 

  
<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
   <tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
    <td colspan="2" align="center" style="border-bottom: none; padding: 10px;">
      <input type="button" value="确定" onClick="javascript:document.newform.submit();" class="btn" style="font-size:12px">
      <input type="reset" value="重置" class="btn" style="font-size:12px">
    </td>
  </tr>
</table></td></tr></table>
</form>
</body>
</html>