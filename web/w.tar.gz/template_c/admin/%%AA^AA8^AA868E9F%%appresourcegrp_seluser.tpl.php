<?php /* Smarty version 2.6.18, created on 2014-12-07 21:06:00
         compiled from appresourcegrp_seluser.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo $this->_tpl_vars['template_root']; ?>
/Calendarandtime.js"></script>
</head>

<body>
<FORM name="f1" onSubmit="return check()" action="admin.php?controller=admin_app&action=appresourcegrp_seluser_save" 
            method="post">

              <TABLE width="100%" bgcolor="#ffffff" border="0" cellspacing="0" cellpadding="0" valign="top"  class="BBtable">
                <TBODY>
                  <TR bgcolor="#f7f7f7">
                    <TD colspan="2" class="list_bg">设置</TD>
                  </TR>
				   <TR id="autosutr" bgcolor="#f7f7f7">
                    <TD width="50%" align="right"><?php echo $this->_tpl_vars['language']['accountlocked']; ?>
</TD>
                    <TD><INPUT id="loginlock" <?php if ($this->_tpl_vars['luser']['loginlock'] == 1): ?> checked <?php endif; ?> type=checkbox name=loginlock value="on">  </TD>
                  </TR>
                  <TR id="autosutr" bgcolor="#f7f7f7">
                    <TD width="50%" align="right"><?php echo $this->_tpl_vars['language']['WeekTimepolicy']; ?>
</TD>
                    <TD><SELECT name="weektime" class="wbk">
                     <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['k']);
$this->_sections['k']['name'] = 'k';
$this->_sections['k']['loop'] = is_array($_loop=$this->_tpl_vars['weektime']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['k']['show'] = true;
$this->_sections['k']['max'] = $this->_sections['k']['loop'];
$this->_sections['k']['step'] = 1;
$this->_sections['k']['start'] = $this->_sections['k']['step'] > 0 ? 0 : $this->_sections['k']['loop']-1;
if ($this->_sections['k']['show']) {
    $this->_sections['k']['total'] = $this->_sections['k']['loop'];
    if ($this->_sections['k']['total'] == 0)
        $this->_sections['k']['show'] = false;
} else
    $this->_sections['k']['total'] = 0;
if ($this->_sections['k']['show']):

            for ($this->_sections['k']['index'] = $this->_sections['k']['start'], $this->_sections['k']['iteration'] = 1;
                 $this->_sections['k']['iteration'] <= $this->_sections['k']['total'];
                 $this->_sections['k']['index'] += $this->_sections['k']['step'], $this->_sections['k']['iteration']++):
$this->_sections['k']['rownum'] = $this->_sections['k']['iteration'];
$this->_sections['k']['index_prev'] = $this->_sections['k']['index'] - $this->_sections['k']['step'];
$this->_sections['k']['index_next'] = $this->_sections['k']['index'] + $this->_sections['k']['step'];
$this->_sections['k']['first']      = ($this->_sections['k']['iteration'] == 1);
$this->_sections['k']['last']       = ($this->_sections['k']['iteration'] == $this->_sections['k']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['weektime'][$this->_sections['k']['index']]['policyname']; ?>
" <?php if ($this->_tpl_vars['weektime'][$this->_sections['k']['index']]['policyname'] == $this->_tpl_vars['luser']['weektime']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['weektime'][$this->_sections['k']['index']]['policyname']; ?>
</option>
			<?php endfor; endif; ?>
                      </SELECT>                   </TD>
                  </TR>
                  <TR id="autosutr">
                    <TD width="50%" align="right"><?php echo $this->_tpl_vars['language']['SourceIPGroup']; ?>
</TD>
                    <TD><select  class="wbk"  name=sourceip>
                      <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['sourceip']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['sourceip'][$this->_sections['t']['index']]['groupname']; ?>
" <?php if ($this->_tpl_vars['sourceip'][$this->_sections['t']['index']]['groupname'] == $this->_tpl_vars['luser']['sourceip']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['sourceip'][$this->_sections['t']['index']]['groupname']; ?>
</option>
			<?php endfor; endif; ?>
                  </SELECT>  </TD>
                  </TR>
                 
                  
                  <TR>
                    <TD colspan="2" align="center"><INPUT class="an_02" type="submit" value="保存修改"></TD>
                  </TR>
                </TBODY>
              </TABLE>
<input type="hidden" name="id" value="<?php echo $this->_tpl_vars['luser']['id']; ?>
" />
<input type="hidden" name="uid" value="<?php echo $this->_tpl_vars['uid']; ?>
" />
<input type="hidden" name="sid" value="<?php echo $this->_tpl_vars['sid']; ?>
" />
<input type="hidden" name="sessionluser" value="<?php echo $this->_tpl_vars['sessionluser']; ?>
" />
</FORM>

</body>
<iframe name="hide" height="0" frameborder="0" scrolling="no"></iframe>
</html>

