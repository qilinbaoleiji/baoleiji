<?php /* Smarty version 2.6.18, created on 2015-04-10 18:22:00
         compiled from workflow_edit.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<?php if ($this->_tpl_vars['_config']['LDAP']): ?>
var foundparent = false;
var servergroup = new Array();
var usergroup = new Array();
var i=0;
<?php unset($this->_sections['a']);
$this->_sections['a']['name'] = 'a';
$this->_sections['a']['loop'] = is_array($_loop=$this->_tpl_vars['allsgroup']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['a']['show'] = true;
$this->_sections['a']['max'] = $this->_sections['a']['loop'];
$this->_sections['a']['step'] = 1;
$this->_sections['a']['start'] = $this->_sections['a']['step'] > 0 ? 0 : $this->_sections['a']['loop']-1;
if ($this->_sections['a']['show']) {
    $this->_sections['a']['total'] = $this->_sections['a']['loop'];
    if ($this->_sections['a']['total'] == 0)
        $this->_sections['a']['show'] = false;
} else
    $this->_sections['a']['total'] = 0;
if ($this->_sections['a']['show']):

            for ($this->_sections['a']['index'] = $this->_sections['a']['start'], $this->_sections['a']['iteration'] = 1;
                 $this->_sections['a']['iteration'] <= $this->_sections['a']['total'];
                 $this->_sections['a']['index'] += $this->_sections['a']['step'], $this->_sections['a']['iteration']++):
$this->_sections['a']['rownum'] = $this->_sections['a']['iteration'];
$this->_sections['a']['index_prev'] = $this->_sections['a']['index'] - $this->_sections['a']['step'];
$this->_sections['a']['index_next'] = $this->_sections['a']['index'] + $this->_sections['a']['step'];
$this->_sections['a']['first']      = ($this->_sections['a']['iteration'] == 1);
$this->_sections['a']['last']       = ($this->_sections['a']['iteration'] == $this->_sections['a']['total']);
?>
servergroup[i++]={id:<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['a']['index']]['id']; ?>
,name:'<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['a']['index']]['groupname']; ?>
',ldapid:<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['a']['index']]['ldapid']; ?>
,level:<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['a']['index']]['level']; ?>
};
<?php endfor; endif; ?>

function change_user_or_server_group(v, d, id_servergroup, id_usergroup)
{
	if(id_servergroup.length>0){
		document.getElementById(id_servergroup).options.length=0;		
		<?php if ($this->_tpl_vars['logined_user_level']): ?>
		document.getElementById(id_servergroup).options[document.getElementById(id_servergroup).options.length]=new Option('无', 0);
		<?php endif; ?>
		var found = 0;
		for(var i=0; i<servergroup.length; i++){
			if(servergroup[i].ldapid==v&& servergroup[i].level==0){
				if(d==servergroup[i].id){
					found = 1;
					var selected_i = document.getElementById(id_servergroup).options.length;
					document.getElementById(id_servergroup).options[document.getElementById(id_servergroup).options.length]=new Option(servergroup[i].name, servergroup[i].id, true, true);
				}else{				
					document.getElementById(id_servergroup).options[document.getElementById(id_servergroup).options.length]=new Option(servergroup[i].name, servergroup[i].id);
				}
			}
		}
		document.getElementById(id_servergroup).options.selectedIndex = selected_i;
	}

	if(id_usergroup.length>0){
		document.getElementById(id_usergroup).options.length=0;		
		<?php if ($this->_tpl_vars['logined_user_level']): ?>
		document.getElementById(id_usergroup).options[document.getElementById(id_usergroup).options.length]=new Option('无', 0);
		<?php endif; ?>
		var found = 0;
		for(var i=0; i<usergroup.length; i++){
			if(usergroup[i].ldapid==v ){
				if(d==usergroup[i].id){
					found = 1;
					var selected_i = document.getElementById(id_usergroup).options.length;
					document.getElementById(id_usergroup).options[document.getElementById(id_usergroup).options.length]=new Option(usergroup[i].name, usergroup[i].id, true, true);
				}else{				
					document.getElementById(id_usergroup).options[document.getElementById(id_usergroup).options.length]=new Option(usergroup[i].name, usergroup[i].id);
				}
			}
		}
		document.getElementById(id_usergroup).options.selectedIndex = selected_i;
	}
}

function changelevels(v, d, id_ldapid1, id_ldapid2, id_servergroup, id_usergroup){
	document.getElementById(id_ldapid2).options.length=0;
	<?php if ($this->_tpl_vars['logined_user_level'] == 1): ?>
	document.getElementById(id_ldapid2).options[document.getElementById(id_ldapid2).options.length]=new Option('无', 0);
	<?php endif; ?>
	var found = 0;
	for(var i=0; i<servergroup.length; i++){
		if(servergroup[i].ldapid==v&& servergroup[i].level==2){
			if(d==servergroup[i].id){
				found = 1;
				var selected_i = document.getElementById(id_ldapid2).options.length;
				document.getElementById(id_ldapid2).options[document.getElementById(id_ldapid2).options.length]=new Option(servergroup[i].name, servergroup[i].id, true, true);
			}else{				
				document.getElementById(id_ldapid2).options[document.getElementById(id_ldapid2).options.length]=new Option(servergroup[i].name, servergroup[i].id);
			}
		}
	}
	document.getElementById(id_ldapid2).options.selectedIndex = selected_i;

	change_user_or_server_group(v, d, id_servergroup, id_usergroup);	
}

function changelevel2(v, d, id_ldapid1, id_ldapid2, id_servergroup, id_usergroup){
	if(v!=0){
		change_user_or_server_group(v, d, id_servergroup, id_usergroup);
	}else{
		//changelevels(document.getElementById(id_ldapid1).options[document.getElementById(id_ldapid1).options.selectedIndex].value, d, id_ldapid1, id_ldapid2, id_servergroup, id_usergroup);
		change_user_or_server_group(v, d, id_servergroup, id_usergroup);
	}
}
<?php endif; ?>

var servers = new Array();
<?php unset($this->_sections['s']);
$this->_sections['s']['name'] = 's';
$this->_sections['s']['loop'] = is_array($_loop=$this->_tpl_vars['userpriority']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['s']['show'] = true;
$this->_sections['s']['max'] = $this->_sections['s']['loop'];
$this->_sections['s']['step'] = 1;
$this->_sections['s']['start'] = $this->_sections['s']['step'] > 0 ? 0 : $this->_sections['s']['loop']-1;
if ($this->_sections['s']['show']) {
    $this->_sections['s']['total'] = $this->_sections['s']['loop'];
    if ($this->_sections['s']['total'] == 0)
        $this->_sections['s']['show'] = false;
} else
    $this->_sections['s']['total'] = 0;
if ($this->_sections['s']['show']):

            for ($this->_sections['s']['index'] = $this->_sections['s']['start'], $this->_sections['s']['iteration'] = 1;
                 $this->_sections['s']['iteration'] <= $this->_sections['s']['total'];
                 $this->_sections['s']['index'] += $this->_sections['s']['step'], $this->_sections['s']['iteration']++):
$this->_sections['s']['rownum'] = $this->_sections['s']['iteration'];
$this->_sections['s']['index_prev'] = $this->_sections['s']['index'] - $this->_sections['s']['step'];
$this->_sections['s']['index_next'] = $this->_sections['s']['index'] + $this->_sections['s']['step'];
$this->_sections['s']['first']      = ($this->_sections['s']['iteration'] == 1);
$this->_sections['s']['last']       = ($this->_sections['s']['iteration'] == $this->_sections['s']['total']);
?>
servers[servers.length]={id: <?php echo $this->_tpl_vars['userpriority'][$this->_sections['s']['index']]['id']; ?>
, device_ip: '<?php echo $this->_tpl_vars['userpriority'][$this->_sections['s']['index']]['device_ip']; ?>
', username: '<?php if (! $this->_tpl_vars['userpriority'][$this->_sections['s']['index']]['username']): ?>空用户<?php else: ?><?php echo $this->_tpl_vars['userpriority'][$this->_sections['s']['index']]['username']; ?>
<?php endif; ?>', login_method: '<?php echo $this->_tpl_vars['userpriority'][$this->_sections['s']['index']]['login_method']; ?>
', groupid: '<?php echo $this->_tpl_vars['userpriority'][$this->_sections['s']['index']]['groupid']; ?>
'};
<?php endfor; endif; ?>

function changegroup(group,defaultip){
	var s = document.getElementById('ip');
	var d = document.getElementById('devicesid');
	s.options.length=0;
	d.options.length=0;
	s.options[s.options.length] = new Option('', '请选择');
	for(var i=0; i<servers.length; i++){
		if(servers[i].groupid==group){
			var found = false;
			for(var j=0; j<s.options.length; j++){
				if(s.options[j].value==servers[i].device_ip){
					found = true;
					break;
				}					
			}
			if(!found){
				if(defaultip==servers[i].device_ip){
					s.options[s.options.length] = new Option(servers[i].device_ip, servers[i].device_ip, true, true);
				}else{
					s.options[s.options.length] = new Option(servers[i].device_ip, servers[i].device_ip);
				}				
			}
		}
	}
}

function changeip(ip,defaultuser){
	var s = document.getElementById('username');
	var d = document.getElementById('devicesid');
	s.options.length=0;
	d.options.length=0;
	s.options[s.options.length] = new Option('', '请选择');
	for(var i=0; i<servers.length; i++){
		if(servers[i].device_ip==ip){
			var found = false;
			for(var j=0; j<s.options.length; j++){
				if(s.options[j].value==servers[i].username){
					found = true;
					break;
				}					
			}
			if(!found){
				if(defaultuser==servers[i].username){
					s.options[s.options.length] = new Option(servers[i].username, servers[i].username, true, true);
				}else{
					s.options[s.options.length] = new Option(servers[i].username, servers[i].username);
				}				
			}
		}
	}
}

function changeuser(user,defaultsid){
	var d = document.getElementById('devicesid');
	var _ip = document.getElementById('ip').options[document.getElementById('ip').options.selectedIndex].value;
	d.options.length=0;
	d.options[d.options.length] = new Option('', '请选择');
	for(var i=0; i<servers.length; i++){
		if(servers[i].device_ip==_ip && servers[i].username==user){
			if(defaultsid==servers[i].id){
				d.options[d.options.length] = new Option(servers[i].login_method, servers[i].id, true, true);
			}else{
				d.options[d.options.length] = new Option(servers[i].login_method, servers[i].id);
			}
		}
	}
}
</script>
</head>

<body>
<td width="84%" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td valign="middle" class="hui_bj"><div class="menu">
<ul>
<?php if ($_SESSION['ADMIN_LEVEL'] == 0): ?>
<?php if ($_GET['logintype'] != 'apppub'): ?>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&gid=<?php echo $this->_tpl_vars['gid']; ?>
&all=1">设备列表</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class=<?php if ($_GET['logintype'] != 'ssh'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != 'ssh'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=ssh&gid=<?php echo $this->_tpl_vars['gid']; ?>
">SSH设备</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != 'ssh'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>
<li class=<?php if ($_GET['logintype'] != 'telnet'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != 'telnet'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=telnet&gid=<?php echo $this->_tpl_vars['gid']; ?>
">TELNET设备</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != 'telnet'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>
<li class=<?php if ($_GET['logintype'] != 'rdp'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != 'rdp'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=rdp&gid=<?php echo $this->_tpl_vars['gid']; ?>
">RDP设备</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != 'rdp'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>
<li class=<?php if ($_GET['logintype'] != 'vnc'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != 'vnc'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=vnc&gid=<?php echo $this->_tpl_vars['gid']; ?>
">VNC设备</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != 'vnc'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>
<li class=<?php if ($_GET['logintype'] != 'ftp'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != 'ftp'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=ftp&gid=<?php echo $this->_tpl_vars['gid']; ?>
">FTP设备</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != 'ftp'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>
<li class=<?php if ($_GET['logintype'] != 'x11'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != 'x11'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=x11">X11设备</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != 'x11'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>

<li class=<?php if ($_GET['logintype'] != '_apppub'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != '_apppub'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=_apppub&gid=<?php echo $this->_tpl_vars['gid']; ?>
">应用</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != '_apppub'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>
<?php else: ?>
<li class=<?php if ($_GET['logintype'] != 'apppub'): ?>"me_b"<?php else: ?>"me_a"<?php endif; ?>><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1<?php if ($_GET['logintype'] != 'apppub'): ?>1<?php endif; ?>.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main&logintype=apppub&gid=<?php echo $this->_tpl_vars['gid']; ?>
">应用发布设备</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3<?php if ($_GET['logintype'] != 'apppub'): ?>3<?php endif; ?>.jpg" align="absmiddle"/></li>
<?php endif; ?>
<?php elseif ($_SESSION['ADMIN_LEVEL'] == 10 || $_SESSION['ADMIN_LEVEL'] == 101): ?>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=main">密码查看</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<?php if ($_SESSION['ADMIN_LEVEL'] == 10): ?>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_pro&action=passwordedit">修改密码</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>

<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_pro&action=password_cron">定时任务</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_backup&action=backup_setting_forpassword">自动备份</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_index&action=passdown">密码文件下载</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_pro&action=passwordcheck">密码校验</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<?php endif; ?><?php endif; ?>
<li class=me_a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_workflow&action=workflow">运维流程</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
</ul><span class="back_img"><A href="admin.php?controller=admin_workflow&action=workflow&back=1"><IMG src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/back1.png" 
      width="80" height="30" border="0"></A></span>
</div></td></tr>
  <tr>
	<td class="">

        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="BBtable">
          <tr>
            <td align="center"><form name="f1" method=post OnSubmit='return check()' action="admin.php?controller=admin_workflow&action=workflow_save&sid=<?php echo $this->_tpl_vars['sip']['sid']; ?>
">
	<table border=0 width=100% cellpadding=5 cellspacing=1 bgcolor="#FFFFFF" valign=top>
	<tr >
	<td align=right>目录</td><td>
<?php if ($this->_tpl_vars['_config']['LDAP']): ?>
						一级<select style="width:150px;" class="wbk"  name="ldapid1" id="ldapid1" onchange="changelevels(this.value,0, 'ldapid1', 'ldapid2', 'servergroup', '')">
		<?php if ($_SESSION['ADMIN_LEVEL'] != 3 && $_SESSION['ADMIN_LEVEL'] != 21 && $_SESSION['ADMIN_LEVEL'] != 101): ?>
		<OPTION VALUE="0">无</option>
		<?php endif; ?>
		<?php unset($this->_sections['g']);
$this->_sections['g']['name'] = 'g';
$this->_sections['g']['loop'] = is_array($_loop=$this->_tpl_vars['allsgroup']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['g']['show'] = true;
$this->_sections['g']['max'] = $this->_sections['g']['loop'];
$this->_sections['g']['step'] = 1;
$this->_sections['g']['start'] = $this->_sections['g']['step'] > 0 ? 0 : $this->_sections['g']['loop']-1;
if ($this->_sections['g']['show']) {
    $this->_sections['g']['total'] = $this->_sections['g']['loop'];
    if ($this->_sections['g']['total'] == 0)
        $this->_sections['g']['show'] = false;
} else
    $this->_sections['g']['total'] = 0;
if ($this->_sections['g']['show']):

            for ($this->_sections['g']['index'] = $this->_sections['g']['start'], $this->_sections['g']['iteration'] = 1;
                 $this->_sections['g']['iteration'] <= $this->_sections['g']['total'];
                 $this->_sections['g']['index'] += $this->_sections['g']['step'], $this->_sections['g']['iteration']++):
$this->_sections['g']['rownum'] = $this->_sections['g']['iteration'];
$this->_sections['g']['index_prev'] = $this->_sections['g']['index'] - $this->_sections['g']['step'];
$this->_sections['g']['index_next'] = $this->_sections['g']['index'] + $this->_sections['g']['step'];
$this->_sections['g']['first']      = ($this->_sections['g']['iteration'] == 1);
$this->_sections['g']['last']       = ($this->_sections['g']['iteration'] == $this->_sections['g']['total']);
?>
			<?php if ($_SESSION['ADMIN_MSERVERGROUP'] == $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id']): ?>
			<?php if ($this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['level'] == 1): ?>
			<OPTION VALUE="<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id']; ?>
" <?php if ($this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id'] == $this->_tpl_vars['sip']['info']['ppgroupid']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['groupname']; ?>
</option>
			<?php endif; ?>
			<?php elseif (! $this->_tpl_vars['member']['uid']): ?>
			<?php if ($this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['level'] == 1): ?>
			<OPTION VALUE="<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id']; ?>
" <?php if ($this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id'] == $this->_tpl_vars['sip']['info']['ppgroupid'] || $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id'] == $this->_tpl_vars['member']['ldapid1']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['groupname']; ?>
</option>
			<?php endif; ?>
			<?php else: ?>
			<?php if ($this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['level'] == 1): ?>
			<OPTION VALUE="<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id']; ?>
" <?php if ($this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id'] == $this->_tpl_vars['sip']['info']['ppgroupid'] || $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['id'] == $this->_tpl_vars['member']['ldapid1']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['allsgroup'][$this->_sections['g']['index']]['groupname']; ?>
</option>
			<?php endif; ?>
			<?php endif; ?>
		<?php endfor; endif; ?>
		</select>
		二级<select  style="width:150px;" class="wbk"  name="ldapid2" id="ldapid2" onchange="changelevel2(this.value,0, 'ldapid1', 'ldapid2', 'servergroup', '')">
		</select>
		资源组<?php endif; ?><select  style="width:150px;" class="wbk"  name="g_id" id="servergroup" onchange="changegroup(this.value)">
		<?php if ($this->_tpl_vars['logined_user_level']): ?>
				<option value="0" >无</option>
		<?php endif; ?>
		<?php unset($this->_sections['gg']);
$this->_sections['gg']['name'] = 'gg';
$this->_sections['gg']['loop'] = is_array($_loop=$this->_tpl_vars['allsgroup']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['gg']['show'] = true;
$this->_sections['gg']['max'] = $this->_sections['gg']['loop'];
$this->_sections['gg']['step'] = 1;
$this->_sections['gg']['start'] = $this->_sections['gg']['step'] > 0 ? 0 : $this->_sections['gg']['loop']-1;
if ($this->_sections['gg']['show']) {
    $this->_sections['gg']['total'] = $this->_sections['gg']['loop'];
    if ($this->_sections['gg']['total'] == 0)
        $this->_sections['gg']['show'] = false;
} else
    $this->_sections['gg']['total'] = 0;
if ($this->_sections['gg']['show']):

            for ($this->_sections['gg']['index'] = $this->_sections['gg']['start'], $this->_sections['gg']['iteration'] = 1;
                 $this->_sections['gg']['iteration'] <= $this->_sections['gg']['total'];
                 $this->_sections['gg']['index'] += $this->_sections['gg']['step'], $this->_sections['gg']['iteration']++):
$this->_sections['gg']['rownum'] = $this->_sections['gg']['iteration'];
$this->_sections['gg']['index_prev'] = $this->_sections['gg']['index'] - $this->_sections['gg']['step'];
$this->_sections['gg']['index_next'] = $this->_sections['gg']['index'] + $this->_sections['gg']['step'];
$this->_sections['gg']['first']      = ($this->_sections['gg']['iteration'] == 1);
$this->_sections['gg']['last']       = ($this->_sections['gg']['iteration'] == $this->_sections['gg']['total']);
?>
		<?php if ($this->_tpl_vars['_config']['LDAP']): ?>
		<?php if ($this->_tpl_vars['allsgroup'][$this->_sections['gg']['index']]['level'] == 0): ?>
			<option VALUE="<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['gg']['index']]['id']; ?>
" <?php if ($this->_tpl_vars['allsgroup'][$this->_sections['gg']['index']]['id'] == $this->_tpl_vars['g_id']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['allsgroup'][$this->_sections['gg']['index']]['groupname']; ?>
</option>
		<?php endif; ?>
		<?php else: ?>
		<option VALUE="<?php echo $this->_tpl_vars['allsgroup'][$this->_sections['gg']['index']]['id']; ?>
" <?php if ($this->_tpl_vars['allsgroup'][$this->_sections['gg']['index']]['id'] == $this->_tpl_vars['g_id']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['allsgroup'][$this->_sections['gg']['index']]['groupname']; ?>
</option>
		<?php endif; ?>
		<?php endfor; endif; ?>
		</select>
	</td>
	</tr>
	<tr bgcolor="f7f7f7">
		<td width="33%" align=right>
		设备IP	
		</td>
		<td width="67%">
		<?php if (! $this->_tpl_vars['sip']['status'] || $this->_tpl_vars['sip']['status'] == 2): ?>
		<select name="ip" id="ip" onchange="changeip(this.value,'')" >
		<option value="">请选择</option>
		<?php unset($this->_sections['s']);
$this->_sections['s']['name'] = 's';
$this->_sections['s']['loop'] = is_array($_loop=$this->_tpl_vars['servers']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['s']['show'] = true;
$this->_sections['s']['max'] = $this->_sections['s']['loop'];
$this->_sections['s']['step'] = 1;
$this->_sections['s']['start'] = $this->_sections['s']['step'] > 0 ? 0 : $this->_sections['s']['loop']-1;
if ($this->_sections['s']['show']) {
    $this->_sections['s']['total'] = $this->_sections['s']['loop'];
    if ($this->_sections['s']['total'] == 0)
        $this->_sections['s']['show'] = false;
} else
    $this->_sections['s']['total'] = 0;
if ($this->_sections['s']['show']):

            for ($this->_sections['s']['index'] = $this->_sections['s']['start'], $this->_sections['s']['iteration'] = 1;
                 $this->_sections['s']['iteration'] <= $this->_sections['s']['total'];
                 $this->_sections['s']['index'] += $this->_sections['s']['step'], $this->_sections['s']['iteration']++):
$this->_sections['s']['rownum'] = $this->_sections['s']['iteration'];
$this->_sections['s']['index_prev'] = $this->_sections['s']['index'] - $this->_sections['s']['step'];
$this->_sections['s']['index_next'] = $this->_sections['s']['index'] + $this->_sections['s']['step'];
$this->_sections['s']['first']      = ($this->_sections['s']['iteration'] == 1);
$this->_sections['s']['last']       = ($this->_sections['s']['iteration'] == $this->_sections['s']['total']);
?>
		<option value="<?php echo $this->_tpl_vars['servers'][$this->_sections['s']['index']]; ?>
" <?php if ($this->_tpl_vars['servers'][$this->_sections['s']['index']] == $this->_tpl_vars['sip']['device_ip']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['servers'][$this->_sections['s']['index']]; ?>
</option>
		<?php endfor; endif; ?>
		</select>
		<?php else: ?>
		<?php echo $this->_tpl_vars['sip']['device_ip']; ?>

		<?php endif; ?>
	  </td>
	</tr>	
	<tr bgcolor="">
		<td width="33%" align=right>
		用户名
		</td>
		<td width="67%">
		<?php if (! $this->_tpl_vars['sip']['status'] || $this->_tpl_vars['sip']['status'] == 2): ?>
		<select name="username" id="username" onchange="changeuser(this.value,'')">
		</select>
		<?php else: ?>
		<?php if (! $this->_tpl_vars['sip']['username']): ?>空用户<?php else: ?><?php echo $this->_tpl_vars['sip']['username']; ?>
<?php endif; ?>
		<?php endif; ?>
	  </td>
	</tr>
	<tr bgcolor="f7f7f7">
		<td width="33%" align=right>
		登录方式
		</td>
		<td width="67%">
		<?php if (! $this->_tpl_vars['sip']['status'] || $this->_tpl_vars['sip']['status'] == 2): ?>
		<select name="devicesid" id="devicesid">
		</select>
		<?php else: ?>
		<?php echo $this->_tpl_vars['sip']['login_method']; ?>

		<input type="hidden" name=devicesid value="<?php echo $this->_tpl_vars['sip']['devicesid']; ?>
" />
		<?php endif; ?>
	  </td>
	</tr>
	<tr bgcolor="">
		<td width="33%" align=right>
		操作内容
		</td>
		<td width="67%">
		<?php if (! $this->_tpl_vars['sip']['status'] || $this->_tpl_vars['sip']['status'] == 2): ?>
		<select name="wfcontant">
		<?php unset($this->_sections['wf']);
$this->_sections['wf']['name'] = 'wf';
$this->_sections['wf']['loop'] = is_array($_loop=$this->_tpl_vars['wfcontant']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['wf']['show'] = true;
$this->_sections['wf']['max'] = $this->_sections['wf']['loop'];
$this->_sections['wf']['step'] = 1;
$this->_sections['wf']['start'] = $this->_sections['wf']['step'] > 0 ? 0 : $this->_sections['wf']['loop']-1;
if ($this->_sections['wf']['show']) {
    $this->_sections['wf']['total'] = $this->_sections['wf']['loop'];
    if ($this->_sections['wf']['total'] == 0)
        $this->_sections['wf']['show'] = false;
} else
    $this->_sections['wf']['total'] = 0;
if ($this->_sections['wf']['show']):

            for ($this->_sections['wf']['index'] = $this->_sections['wf']['start'], $this->_sections['wf']['iteration'] = 1;
                 $this->_sections['wf']['iteration'] <= $this->_sections['wf']['total'];
                 $this->_sections['wf']['index'] += $this->_sections['wf']['step'], $this->_sections['wf']['iteration']++):
$this->_sections['wf']['rownum'] = $this->_sections['wf']['iteration'];
$this->_sections['wf']['index_prev'] = $this->_sections['wf']['index'] - $this->_sections['wf']['step'];
$this->_sections['wf']['index_next'] = $this->_sections['wf']['index'] + $this->_sections['wf']['step'];
$this->_sections['wf']['first']      = ($this->_sections['wf']['iteration'] == 1);
$this->_sections['wf']['last']       = ($this->_sections['wf']['iteration'] == $this->_sections['wf']['total']);
?>
		<option value="<?php echo $this->_tpl_vars['wfcontant'][$this->_sections['wf']['index']]['sid']; ?>
" <?php if ($this->_tpl_vars['sip']['contant'] == $this->_tpl_vars['wfcontant'][$this->_sections['wf']['index']]['sid']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['wfcontant'][$this->_sections['wf']['index']]['name']; ?>
</option>
		<?php endfor; endif; ?>
		</select>
		<?php else: ?>
		<?php echo $this->_tpl_vars['sip']['name']; ?>

		<input type="hidden" name=wfcontant value="<?php echo $this->_tpl_vars['sip']['contant']; ?>
" />
		<?php endif; ?>
	  </td>
	</tr>
	<tr bgcolor="f7f7f7">
	<td width="33%" align=right valign="top">
		描述
		</td>
		<td width="67%">
		<textarea cols="37" rows="10"  name="desc"><?php echo $this->_tpl_vars['sip']['desc']; ?>
</textarea>
	  </td>
	</tr>	
	<tr bgcolor="f7f7f7"><td></td><td><input type=submit  value="<?php echo $this->_tpl_vars['language']['Save']; ?>
" class="an_02"></td></tr></table>

</form>
	</td>
  </tr>
</table>
<script>

<?php if ($this->_tpl_vars['_config']['LDAP']): ?>
<?php if ($this->_tpl_vars['sip']['sid']): ?>
changelevels(<?php echo $this->_tpl_vars['sip']['info']['ppgroupid']; ?>
, <?php echo $this->_tpl_vars['sip']['info']['pgroupid']; ?>
, 'ldapid1', 'ldapid2', 'servergroup', '');
changelevel2(<?php echo $this->_tpl_vars['sip']['info']['pgroupid']; ?>
, <?php echo $this->_tpl_vars['sip']['info']['groupid']; ?>
, 'ldapid1', 'ldapid2', 'servergroup', '');
changegroup('<?php echo $this->_tpl_vars['sip']['info']['groupid']; ?>
','<?php echo $this->_tpl_vars['sip']['info']['device_ip']; ?>
');
changeip('<?php echo $this->_tpl_vars['sip']['device_ip']; ?>
','<?php if (! $this->_tpl_vars['sip']['username']): ?>空用户<?php else: ?><?php echo $this->_tpl_vars['sip']['username']; ?>
<?php endif; ?>');changeuser('<?php if (! $this->_tpl_vars['sip']['username']): ?>空用户<?php else: ?><?php echo $this->_tpl_vars['sip']['username']; ?>
<?php endif; ?>','<?php echo $this->_tpl_vars['sip']['devicesid']; ?>
');

<?php endif; ?>

<?php endif; ?>
</script>
</body>
<iframe name="hide" height="0" frameborder="0" scrolling="no"></iframe>
</html>

