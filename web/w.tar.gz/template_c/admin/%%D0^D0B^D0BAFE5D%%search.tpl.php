<?php /* Smarty version 2.6.18, created on 2015-04-15 23:36:43
         compiled from search.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
<script src="./template/admin/cssjs/jscal2.js"></script>
<script src="./template/admin/cssjs/cn.js"></script>
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/jscal2.css" />
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/border-radius.css" />

<script language="JavaScript">
 
</script>
</head>

<body>
<style type="text/css">
a {
    color: #003499;
    text-decoration: none;
} 
a:hover {
    color: #000000;
    text-decoration: underline;
}
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td valign="middle" class="hui_bj" colspan="2">
	<div class="menu">
	<ul>
	<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_search">综合日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
	<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_eventlogs&action=applogs">应用日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
	<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_login">登录日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
	<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_authpriv">权限日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
	</ul>
	</div>
</td>
</tr>
 <tr>
<td   width=100%>
<FORM id=main_form onSubmit="return false;" method=get name=results action=admin.php>
     <INPUT id="controller " value=admin_search type=hidden name=controller>
      <INPUT id=action value=search type=hidden   name=action> 	

<table border=0 width=100% cellpadding=5 cellspacing=1 bgcolor="#FFFFFF" valign=top>

<!--************-->
<tr>
<td width="100%"   align="center">
	<table  width=100% class="BBtable">
	<?php $this->assign('trnumber', 0); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<td   align=right>
		选择数据表:		
		</td>
		<td   colspan="3">
		 <select name="table" id="table">
				<?php unset($this->_sections['t']);
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['table_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['table_list'][$this->_sections['t']['index']]; ?>
"><?php echo $this->_tpl_vars['table_list'][$this->_sections['t']['index']]; ?>
</option>
				<?php endfor; endif; ?>
				<option value="alllogs">alllogs</option>
				</select>                 
				<span class="STYLE1">请选择数据表，其中logs为当前系统使用数据表，其它数据库为系统备份数据表 </span>
	  	</td>
	  	
	</tr>

	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		         <TD  align=right>主机地址:</TD>
                <TD  align=left class=main_list_td1>&nbsp;&nbsp; 
			                包括<INPUT   value=0 type=radio name=excludeHost CHECKED> 
			    <?php if ($this->_tpl_vars['level'] == 1): ?>
			                  除去 <INPUT value=1  type=radio name=excludeHost>
			   <?php endif; ?>
			       &nbsp;<br>主机名包括 <INPUT  class="wbk" size=18 type=text name=host2>&nbsp;<br>
              
          	 	 <select name="host[]" style="WIDTH: 200px" multiple size=5>
					<?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['allhost']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
					<option><?php echo $this->_tpl_vars['allhost'][$this->_sections['t']['index']]['device_ip']; ?>
</option>
					<?php endfor; endif; ?>
					</select>
				&nbsp;<br>
				&nbsp;<br>
				</TD>
                <TD   align=right class=main_list_td1>日志设备:</TD>
                <TD   align=left class=main_list_td1>&nbsp;&nbsp; 包括
                    <INPUT  value=0 type=radio name=excludeFacility>去除
                  <INPUT value=1 CHECKED type=radio  name=excludeFacility>
                    <br>&nbsp;
				  <SELECT multiple size=5 style="WIDTH: 200px" name=facility[]>
				    <OPTION>auth</OPTION>
				    <OPTION>authpriv</OPTION>
				    <OPTION>cron</OPTION>
				    <OPTION>daemon</OPTION>
				    <OPTION>kern</OPTION>
				    <OPTION>local0</OPTION>
				    <OPTION>local3</OPTION>
				    <OPTION>local5</OPTION>
				    <OPTION>local6</OPTION>
				    <OPTION>local7</OPTION>
				    <OPTION>mail</OPTION>
				    <OPTION>syslog</OPTION>
				    <OPTION>user</OPTION>
				    <OPTION>uucp</OPTION>
				  </SELECT>                
  				</TD>
	</tr>

	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
                <TD class=main_list_td1 align=right>日志级别:</TD>
                <TD class=main_list_td1 align=left>&nbsp;&nbsp; 包括<INPUT 
                  value=0 type=radio name=excludePriority>去除<INPUT value=1 
                  CHECKED type=radio 
                  name=excludePriority>
                  <br>
                  &nbsp;
                  <SELECT multiple size=5 style="WIDTH: 200px"
                  name=priority[]> 
                    <OPTION>debug<OPTION>info<OPTION>notice<OPTION>warning<OPTION>err<OPTION>crit<OPTION>alert<OPTION>emerg</OPTION></SELECT>
                  <br>
                 </TD>
                <TD align=right valign="top" class=main_list_td1>起始:<br>结束:</TD>
                <TD align=left valign="top" class=main_list_td1>&nbsp; 日期
                		<input type="text"  name="datetime" size="15" id="datetime"   class="wbk" /> 
				<input type="button"  id="datetime_trigger" name="datetime_trigger" value="选择时间" class="wbk">
					<br>
					&nbsp;&nbsp;日期
	<input type="text"  name="datetime2" size="15" id="datetime2"   class="wbk" /> 
				<input type="button"  id="datetime2_trigger" name="datetime2_trigger" value="选择时间" class="wbk">					<input id=page_id type=hidden name=pageId>
					<br>
 				</TD>
	</tr>
	
	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
                         <TD class=main_list_td1 align=right>每页记录数:</TD>
                <TD class=main_list_td1 align=left>&nbsp;&nbsp; <SELECT 
                  name=limit> <OPTION selected>25</OPTION> <OPTION>50</OPTION> 
                    <OPTION>100</OPTION> <OPTION>200</OPTION> 
                    <OPTION>500</OPTION> <OPTION>1000</OPTION></SELECT> </TD>
                <TD align=right class=main_list_td1>排序字段:</TD>
                <TD align=left class=main_list_td1>&nbsp;&nbsp;
                    <SELECT name=orderby>
                      <OPTION selected>id</OPTION>
                      <OPTION>host</OPTION>
                      <OPTION>facility</OPTION>
                      <OPTION>priority</OPTION>
                      <OPTION>datetime</OPTION>
                    </SELECT>                
                  </TD>
	</tr>

	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
                      <TD class=main_list_td1 align=right>升降序:</TD>
                <TD class=main_list_td1 align=left>&nbsp;&nbsp; <SELECT 
                  name=order> <OPTION>ASC</OPTION> <OPTION 
                    selected>DESC</OPTION></SELECT> </TD>
                <TD class=main_list_td1 align=left>&nbsp;</TD>
                <TD class=main_list_td1 align=left>&nbsp;</TD>
	</tr>


	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
          <TD class=main_list_td1 colSpan=4>进行日志信息内容搜索:<BR>
          去除 <INPUT  type=checkbox name=ExcludeMsg1>
         <INPUT size=75 type=text   name=msg1> 和<BR>
           去除 <INPUT type=checkbox name=ExcludeMsg2> 
         <INPUT size=75 type=text name=msg2> 和<BR>
           </TD>
	</tr>
	
	
	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
                <TD class=main_list_td1 colSpan=4>将同样的信息合并为一条输出: <INPUT 
                  value=1 CHECKED type=checkbox name=collapse>
                  </TD>
	</tr>


	<?php $this->assign('trnumber', $this->_tpl_vars['trnumber']+1); ?>
	<tr <?php if ($this->_tpl_vars['trnumber'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
	  <td colspan='4'  align="center">
		<INPUT id=hidden_search  type=hidden name=type> 
        <INPUT class=bnnew2 onClick="JavaScript: document.getElementById('action').value='search';submit();" value=搜索 type=button> 
		<INPUT class=bnnew2 onClick="JavaScript: document.getElementById('action').value='search';document.getElementById('hidden_search').value='today'; submit();" value=今天 type=button> 
		<INPUT class=bnnew2 onClick="JavaScript: document.getElementById('action').value='export'; submit();" value=导出 type=button> 
		<INPUT class=bnnew2 value=复位 type=reset>
	  </td>
	</tr>
	</table>
</td>
</tr>
</table>

  
      

</FORM>
</td>


</tr>
</table>

 <script type="text/javascript">


                  new Calendar({
                          inputField: "datetime",
                          dateFormat: "%Y-%m-%d %H:%M:%S",
                          trigger: "datetime_trigger",
                          bottomBar: false,
                          showTime: true,
                          onSelect: function() {
                                  var date = Calendar.intToDate(this.selection.get());                             
                                  this.hide();
                          }
                  });
                  
                      new Calendar({
                          inputField: "datetime2",
                          dateFormat: "%Y-%m-%d %H:%M:%S",
                          trigger: "datetime2_trigger",
                          bottomBar: false,
                          showTime: true,
                          onSelect: function() {
                                  var date = Calendar.intToDate(this.selection.get());                             
                                  this.hide();
                          }
                  });

function my_confirm(str){
	if(!confirm(str + "？"))
	{
		window.event.returnValue = false;
	}
}


</script>
</body>

</html>


