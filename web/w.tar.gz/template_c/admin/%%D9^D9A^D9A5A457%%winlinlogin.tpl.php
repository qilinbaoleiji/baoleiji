<?php /* Smarty version 2.6.18, created on 2015-02-07 23:22:07
         compiled from winlinlogin.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['language']['SessionsList']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />

<script src="./template/admin/cssjs/jscal2.js"></script>
<script src="./template/admin/cssjs/cn.js"></script>
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/jscal2.css" />
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/border-radius.css" />
<SCRIPT>
	function my_confirm(str){
		if(!confirm("确认要" + str + "？"))
		{
			window.event.returnValue = false;
		}
	}
	function chk_form(){
		for(var i = 0; i < document.list.elements.length;i++){
			var e = document.list.elements[i];
			if(e.name == 'chk_member[]' && e.checked == true)
				return true;
		}
		alert("您没有选任何记录！");
		return false;
	}
</SCRIPT>
</head>
<body>
<style type="text/css">
a {
    color: #003499;
    text-decoration: none;
} 
a:hover {
    color: #000000;
    text-decoration: underline;
}
</style>
<td width="84%" align="left" valign="top">

 </td>
  </tr>
  <tr><td>
  <table bordercolor="white" cellspacing="0" cellpadding="5" border="0" width="100%" class="BBtable1">
 <FORM method=post name=list     action=admin.php?controller=admin_login&amp;a=delete_all&amp;t=linux_login>
	<tr>
	 <TH width="2%" class="list_bg1">选</TH>
           <TH width="6%" class="list_bg1">来源</TH>
          <TH width="6%" class="list_bg1">用户名</TH> 
		  <?php if ($this->_tpl_vars['os'] == 'linux'): ?>
		  <TH width="6%" class="list_bg1">协议</TH>
		  <?php endif; ?>
		  <TH width="10%" class="list_bg1">登录时间</TH>
		  <TH width="10%" class="list_bg1">退出时间</TH>
		  <TH width="3%" class="list_bg1">状态</TH>
		   <TH width="6%" class="list_bg1">探针</TH>	
		  <TH width="6%" class="list_bg1">操作</TH>
						
		</tr>
		<?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['alllogs']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
	 <TR class="list_tr_bg<?php if ($this->_sections['t']['index'] % 2 != 0): ?>1<?php endif; ?>">
		 <TD><?php if ($_SESSION['ADMIN_LEVEL']): ?><INPUT value=<?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['id']; ?>
 type=checkbox name=chk_member[]><?php endif; ?></TD>
           <TD><?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['srchost']; ?>
</TD>
		  <TD><?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['user']; ?>
</TD>
		  <?php if ($this->_tpl_vars['os'] == 'linux'): ?>
		   <TD><?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['protocol']; ?>
</TD>
		  <?php endif; ?>
          <TD><?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['starttime']; ?>
</TD>
		  <TD><?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['endtime']; ?>
</TD>
		  <TD>
		  		<?php if ($this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['active'] == '1'): ?>成功
					<?php elseif ($this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['active'] == '0'): ?>失败
		
					<?php else: ?>退出
					<?php endif; ?>
		  </TD>
		   <TD><?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['logserver']; ?>
</TD>
		  <TD>
		  	<input name="detail" type="button" value="详细"  onclick="javascript:window.open('admin.php?controller=admin_login&action=detail&t=<?php if ($this->_tpl_vars['os'] == 'windows'): ?>windows_login<?php else: ?>linux_login<?php endif; ?>&id=<?php echo $this->_tpl_vars['alllogs'][$this->_sections['t']['index']]['id']; ?>
','newwin')"  class="bnnew2"  />
		  </TD>

			</tr>
		<?php endfor; endif; ?>
        <TR>
          <TD colSpan=11 align=left>
          <?php if ($_SESSION['ADMIN_LEVEL']): ?><INPUT  onclick="javascript:for(var i=0;i<this.form.elements.length;i++){var e=this.form.elements[i];if(e.name=='chk_member[]')e.checked=this.form.select_all.checked;}" 
            value=checkbox type=checkbox name=select_all>选本页显示的所有记录&nbsp;&nbsp;<INPUT class=an_06 onClick="my_confirm('删除所选记录');if(!chk_form())  return false;" value=批量删除所选记录 type=submit>      <?php endif; ?>
            </TD>
         </TR>
				</FORM>	
			<tr>
				<td height="45" colspan="11" align="right" bgcolor="#FFFFFF">
							<?php echo $this->_tpl_vars['language']['all']; ?>
<?php echo $this->_tpl_vars['session_num']; ?>
<?php echo $this->_tpl_vars['language']['Session']; ?>
  <?php echo $this->_tpl_vars['page_list']; ?>
  <?php echo $this->_tpl_vars['language']['Page']; ?>
：<?php echo $this->_tpl_vars['curr_page']; ?>
/<?php echo $this->_tpl_vars['total_page']; ?>
<?php echo $this->_tpl_vars['language']['page']; ?>
  <?php echo $this->_tpl_vars['items_per_page']; ?>
条/每页 
							  转到第<input name="pagenum" type="text" size="2" onKeyPress="if(event.keyCode==13) window.location='<?php echo $this->_tpl_vars['curr_url']; ?>
&page='+this.value;" class="wbk">
							  页&nbsp;  
				</td>
			</tr>
			
		</table>
	</td>
  </tr>
</table></td>


</body>
</html>

