<?php /* Smarty version 2.6.18, created on 2015-04-06 20:35:33
         compiled from main.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['site_title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  class="hui_bj"><?php echo $this->_tpl_vars['language']['ManandHelp']; ?>
</td>
  </tr>
  <tr>
	<td class="main_content">
		<?php echo $this->_tpl_vars['language']['ManandHelp']; ?>

	</td>
  </tr>
</table>

</body>
</html>

