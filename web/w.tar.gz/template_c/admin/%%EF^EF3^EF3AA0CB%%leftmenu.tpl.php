<?php /* Smarty version 2.6.18, created on 2015-03-01 00:49:03
         compiled from leftmenu.tpl */ ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>left</title>
<LINK href="<?php echo $this->_tpl_vars['template_root']; ?>
/cssjs/liye.css" type=text/css rel=stylesheet>
<SCRIPT src="<?php echo $this->_tpl_vars['template_root']; ?>
/cssjs/MTree.js" type=text/javascript></SCRIPT>


</head>

<body> <!-- oncontextmenu="return false" -->

          <table width="<?php if ($_GET['from'] == 'parameters'): ?>120<?php else: ?>235<?php endif; ?>"  height="554" border="0" cellspacing="0" cellpadding="0" style="background-color:#F1F1F1">
            <tr>
                <td height="100%" align="left" valign="top" width="<?php if ($_GET['from'] == 'parameters'): ?>120<?php else: ?>235<?php endif; ?>">
			      <!-- 边框的头-->

				<div id="bangzi" style='border:#B1B5B9 1px solid; text-align:left; position:relative; left:0; top:0; width:<?php if ($_GET['from'] == 'parameters'): ?>120<?php else: ?>235<?php endif; ?>px; height:554px; z-index:1; overflow: auto;'>
                  <table id="clgl" width="85%" border="0" cellspacing="0" cellpadding="0">
                  	<tr>
                  		<td colspan="2"><img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/spacer.gif' height='8'></td>
                  	</tr>
                  	<tr>
						<td><img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/spacer.gif' width='8'></td>
                  		
                  		<td width='232'>
							<!-- Tree -->
							<script type="text/javascript">
								var tree6 = new MTree("<?php echo $this->_tpl_vars['template_root']; ?>
/images/treeImages");
									tree6.setTreeName("tree6");
								<?php if ($_GET['from'] == 'paramters'): ?>

								 
							 tree6.addNode(new MTreeNode("a1","0","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<strong><?php echo $this->_tpl_vars['server']['device_ip']; ?>
</strong>","<img id=stateimg src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['server']['status'] == 1): ?>Green.gif<?php elseif ($this->_tpl_vars['server']['status'] == 2): ?>GreenYellow.gif<?php else: ?>GreenRed.gif<?php endif; ?>' width='13' height='13'  style='cursor: hand' alt='点击浏览状态信息' onclick=openStatePage('a1')>&nbsp;","","","","",""));						
											
							tree6.addNode(new MTreeNode("b1","a1","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_thold&action=status_thold&ip=<?php echo $this->_tpl_vars['ip']; ?>
&from=hostview','rightmain');>系统阈值</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/icon_cgxx.gif' width='16' height='16'>","","","","",""));

							tree6.addNode(new MTreeNode("b2","a1","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_thold&action=interface_thold&ip=<?php echo $this->_tpl_vars['ip']; ?>
&from=hostview','rightmain');>网络阈值</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));

							tree6.addNode(new MTreeNode("b3","a1","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_thold&action=app_thold&ip=<?php echo $this->_tpl_vars['ip']; ?>
&from=hostview','rightmain');>应用阈值</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));
										
										//tree6.setAutoReload(); //是否动态生成
								<?php else: ?>
											
											tree6.addNode(new MTreeNode("a1","0","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<strong><?php echo $this->_tpl_vars['server']['device_ip']; ?>
</strong>","<img id=stateimg src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['server']['status'] == 1): ?>Green.gif<?php elseif ($this->_tpl_vars['server']['status'] == 2): ?>GreenYellow.gif<?php else: ?>GreenRed.gif<?php endif; ?>' width='13' height='13'  style='cursor: hand' alt='点击浏览状态信息' onclick=openStatePage('a1')>&nbsp;","","","","",""));
											
								
											
											tree6.addNode(new MTreeNode("b1","a1","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostview&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>常规信息</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/icon_cgxx.gif' width='16' height='16'>","","","","",""));
											
											tree6.addNode(new MTreeNode("b3","a1","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b3'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' >事件管理</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));

											tree6.addNode(new MTreeNode("b31","b3","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b3'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_login&action=winlinlogin&os=<?php echo $this->_tpl_vars['os']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>登录日志</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));	
											
											tree6.addNode(new MTreeNode("b32","b3","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b3'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_authpriv&action=winlinauthpriv&os=<?php echo $this->_tpl_vars['os']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>权限日志</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));	

											tree6.addNode(new MTreeNode("b33","b3","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b3'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_eventlogs&action=eventlogbyip&os=<?php echo $this->_tpl_vars['os']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>告警日志</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));	
											tree6.addNode(new MTreeNode("b34","b3","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b3'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_thold&action=snmp_status_warning_log&ip=<?php echo $this->_tpl_vars['ip']; ?>
&from=hostview','rightmain');>系统告警</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));	
											tree6.addNode(new MTreeNode("b35","b3","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b3'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_thold&action=snmp_interface_log&ip=<?php echo $this->_tpl_vars['ip']; ?>
&from=hostview','rightmain');>流量告警</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));	
											tree6.addNode(new MTreeNode("b36","b3","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_b3'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_thold&action=app_warning_log&ip=<?php echo $this->_tpl_vars['ip']; ?>
&from=hostview','rightmain');>应用告警</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico-021.gif' width='16' height='16'>","","","","",""));	
								
											
											tree6.addNode(new MTreeNode("b4","b13","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_availabilitymetrica1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostview&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>可用性指标</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));							
											
											tree6.addNode(new MTreeNode("b5","b4","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_performancemetrica1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostview&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>性能指标</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));

											tree6.addNode(new MTreeNode("b42","b13","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_availabilitymetrica1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostview&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>本地检测指标</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));

											tree6.addNode(new MTreeNode("b421","b42","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_performancemetrica1'; style='border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' ,'rightmain');>本地端口</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));

											<?php unset($this->_sections['p']);
$this->_sections['p']['name'] = 'p';
$this->_sections['p']['loop'] = is_array($_loop=$this->_tpl_vars['localport']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['p']['show'] = true;
$this->_sections['p']['max'] = $this->_sections['p']['loop'];
$this->_sections['p']['step'] = 1;
$this->_sections['p']['start'] = $this->_sections['p']['step'] > 0 ? 0 : $this->_sections['p']['loop']-1;
if ($this->_sections['p']['show']) {
    $this->_sections['p']['total'] = $this->_sections['p']['loop'];
    if ($this->_sections['p']['total'] == 0)
        $this->_sections['p']['show'] = false;
} else
    $this->_sections['p']['total'] = 0;
if ($this->_sections['p']['show']):

            for ($this->_sections['p']['index'] = $this->_sections['p']['start'], $this->_sections['p']['iteration'] = 1;
                 $this->_sections['p']['iteration'] <= $this->_sections['p']['total'];
                 $this->_sections['p']['index'] += $this->_sections['p']['step'], $this->_sections['p']['iteration']++):
$this->_sections['p']['rownum'] = $this->_sections['p']['iteration'];
$this->_sections['p']['index_prev'] = $this->_sections['p']['index'] - $this->_sections['p']['step'];
$this->_sections['p']['index_next'] = $this->_sections['p']['index'] + $this->_sections['p']['step'];
$this->_sections['p']['first']      = ($this->_sections['p']['iteration'] == 1);
$this->_sections['p']['last']       = ($this->_sections['p']['iteration'] == $this->_sections['p']['total']);
?>
											tree6.addNode(new MTreeNode("b421<?php echo $this->_sections['p']['index']; ?>
","b421","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b8'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=localport&id=<?php echo $this->_tpl_vars['localport'][$this->_sections['p']['index']]['seq']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>PORT <?php echo $this->_tpl_vars['localport'][$this->_sections['p']['index']]['port']; ?>
</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['localport'][$this->_sections['p']['index']]['port_status'] <= '0'): ?>RhombusRed.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb8a1'>","","","","",""));
											<?php endfor; endif; ?>



											tree6.addNode(new MTreeNode("b422","b42","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_performancemetrica1'; style=' border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' ,'rightmain');>本地进程</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));

											<?php unset($this->_sections['pr']);
$this->_sections['pr']['name'] = 'pr';
$this->_sections['pr']['loop'] = is_array($_loop=$this->_tpl_vars['localprocess']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['pr']['show'] = true;
$this->_sections['pr']['max'] = $this->_sections['pr']['loop'];
$this->_sections['pr']['step'] = 1;
$this->_sections['pr']['start'] = $this->_sections['pr']['step'] > 0 ? 0 : $this->_sections['pr']['loop']-1;
if ($this->_sections['pr']['show']) {
    $this->_sections['pr']['total'] = $this->_sections['pr']['loop'];
    if ($this->_sections['pr']['total'] == 0)
        $this->_sections['pr']['show'] = false;
} else
    $this->_sections['pr']['total'] = 0;
if ($this->_sections['pr']['show']):

            for ($this->_sections['pr']['index'] = $this->_sections['pr']['start'], $this->_sections['pr']['iteration'] = 1;
                 $this->_sections['pr']['iteration'] <= $this->_sections['pr']['total'];
                 $this->_sections['pr']['index'] += $this->_sections['pr']['step'], $this->_sections['pr']['iteration']++):
$this->_sections['pr']['rownum'] = $this->_sections['pr']['iteration'];
$this->_sections['pr']['index_prev'] = $this->_sections['pr']['index'] - $this->_sections['pr']['step'];
$this->_sections['pr']['index_next'] = $this->_sections['pr']['index'] + $this->_sections['pr']['step'];
$this->_sections['pr']['first']      = ($this->_sections['pr']['iteration'] == 1);
$this->_sections['pr']['last']       = ($this->_sections['pr']['iteration'] == $this->_sections['pr']['total']);
?>
											tree6.addNode(new MTreeNode("b422<?php echo $this->_sections['pr']['index']; ?>
","b422","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b8'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=localprocess&id=<?php echo $this->_tpl_vars['localprocess'][$this->_sections['pr']['index']]['seq']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');><?php echo $this->_tpl_vars['localprocess'][$this->_sections['pr']['index']]['process']; ?>
</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['localprocess'][$this->_sections['pr']['index']]['process_status'] == '0'): ?>RhombusRed.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb8a1'>","","","","",""));
											<?php endfor; endif; ?>
								
											
											tree6.addNode(new MTreeNode("b6","b9","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b6'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=cpu&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>CPU平均利用率</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['cpu']['value'] == NULL || $this->_tpl_vars['cpu']['value'] < 0): ?>RhombusRed.gif<?php elseif ($this->_tpl_vars['cpu']['value'] < $this->_tpl_vars['cpu']['lowvalue'] || $this->_tpl_vars['cpu']['value'] > $this->_tpl_vars['cpu']['highvalue']): ?>RhombusYellow.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb6a1'>","","","","",""));
<?php if ($this->_tpl_vars['cpuio']): ?>
											tree6.addNode(new MTreeNode("b66","b9","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b6'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=cpu_io&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>CPU IO平均利用率</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['cpuio']['value'] == NULL || $this->_tpl_vars['cpuio']['value'] < 0): ?>RhombusRed.gif<?php elseif ($this->_tpl_vars['cpuio']['value'] < $this->_tpl_vars['cpuio']['lowvalue'] || $this->_tpl_vars['cpuio']['value'] > $this->_tpl_vars['cpuio']['highvalue']): ?>RhombusYellow.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb6a1'>","","","","",""));
<?php endif; ?>											
								
											
											tree6.addNode(new MTreeNode("b7","b10","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b7'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=memory&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>内存利用率</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['memory']['value'] == NULL || $this->_tpl_vars['memory']['value'] < 0): ?>RhombusRed.gif<?php elseif ($this->_tpl_vars['memory']['value'] < $this->_tpl_vars['memory']['lowvalue'] || $this->_tpl_vars['memory']['value'] > $this->_tpl_vars['memory']['highvalue']): ?>RhombusYellow.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb7a1'>","","","","",""));
											
								
											
											//tree6.addNode(new MTreeNode("b8","b11","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b8'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostping&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>ping 时延</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/RhombusGreen.gif' width='16' height='16' id='imgb8a1'>","","","","",""));
											
											<?php unset($this->_sections['d']);
$this->_sections['d']['name'] = 'd';
$this->_sections['d']['loop'] = is_array($_loop=$this->_tpl_vars['snmpstatus']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['d']['show'] = true;
$this->_sections['d']['max'] = $this->_sections['d']['loop'];
$this->_sections['d']['step'] = 1;
$this->_sections['d']['start'] = $this->_sections['d']['step'] > 0 ? 0 : $this->_sections['d']['loop']-1;
if ($this->_sections['d']['show']) {
    $this->_sections['d']['total'] = $this->_sections['d']['loop'];
    if ($this->_sections['d']['total'] == 0)
        $this->_sections['d']['show'] = false;
} else
    $this->_sections['d']['total'] = 0;
if ($this->_sections['d']['show']):

            for ($this->_sections['d']['index'] = $this->_sections['d']['start'], $this->_sections['d']['iteration'] = 1;
                 $this->_sections['d']['iteration'] <= $this->_sections['d']['total'];
                 $this->_sections['d']['index'] += $this->_sections['d']['step'], $this->_sections['d']['iteration']++):
$this->_sections['d']['rownum'] = $this->_sections['d']['iteration'];
$this->_sections['d']['index_prev'] = $this->_sections['d']['index'] - $this->_sections['d']['step'];
$this->_sections['d']['index_next'] = $this->_sections['d']['index'] + $this->_sections['d']['step'];
$this->_sections['d']['first']      = ($this->_sections['d']['iteration'] == 1);
$this->_sections['d']['last']       = ($this->_sections['d']['iteration'] == $this->_sections['d']['total']);
?>
											tree6.addNode(new MTreeNode("b8<?php echo $this->_sections['d']['index']; ?>
","b12","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b8'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=disk&id=<?php echo $this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['seq']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');><?php echo $this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['disk']; ?>
</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['value'] == NULL || $this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['value'] < 0): ?>RhombusRed.gif<?php elseif ($this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['value'] < $this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['lowvalue'] || $this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['value'] > $this->_tpl_vars['snmpstatus'][$this->_sections['d']['index']]['highvalue']): ?>RhombusYellow.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb8a1'>","","","","",""));
											<?php endfor; endif; ?>

											<?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['tcpport']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
											tree6.addNode(new MTreeNode("b11<?php echo $this->_sections['t']['index']; ?>
","b11","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_b8'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=tcpport&id=<?php echo $this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['seq']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>TCP <?php echo $this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['tcpport']; ?>
</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['value'] == NULL || $this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['value'] < 0): ?>RhombusRed.gif<?php elseif ($this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['value'] < $this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['lowvalue'] || $this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['value'] > $this->_tpl_vars['tcpport'][$this->_sections['t']['index']]['highvalue']): ?>RhombusYellow.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb8a1'>","","","","",""));
											<?php endfor; endif; ?>
								
											
											tree6.addNode(new MTreeNode("b9","b5","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_WindowHostCPUGroup'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=cpu&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>CPU类</span>","","","","","",""));
											
								
											
											tree6.addNode(new MTreeNode("b10","b5","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_WindowHostMemGroup'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=memory&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>内存类</span>","","","","","",""));

											tree6.addNode(new MTreeNode("b12","b5","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_WindowHostDiskGroup'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=disk&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>存贮类</span>","","","","","",""));
											
											
											
											tree6.addNode(new MTreeNode("b11","b5","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_a1_ConnectConfigurationGrp'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=hostbytype&type=tcpport&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');>端口扫描类</span>","","","","","",""));							
									
											tree6.addNode(new MTreeNode("b13","a1","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span class='ly'>指标列表</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));

											tree6.addNode(new MTreeNode("b14","a1","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span class='ly'>应用监控</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));

											<?php unset($this->_sections['ap']);
$this->_sections['ap']['name'] = 'ap';
$this->_sections['ap']['loop'] = is_array($_loop=$this->_tpl_vars['apps']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['ap']['show'] = true;
$this->_sections['ap']['max'] = $this->_sections['ap']['loop'];
$this->_sections['ap']['step'] = 1;
$this->_sections['ap']['start'] = $this->_sections['ap']['step'] > 0 ? 0 : $this->_sections['ap']['loop']-1;
if ($this->_sections['ap']['show']) {
    $this->_sections['ap']['total'] = $this->_sections['ap']['loop'];
    if ($this->_sections['ap']['total'] == 0)
        $this->_sections['ap']['show'] = false;
} else
    $this->_sections['ap']['total'] = 0;
if ($this->_sections['ap']['show']):

            for ($this->_sections['ap']['index'] = $this->_sections['ap']['start'], $this->_sections['ap']['iteration'] = 1;
                 $this->_sections['ap']['iteration'] <= $this->_sections['ap']['total'];
                 $this->_sections['ap']['index'] += $this->_sections['ap']['step'], $this->_sections['ap']['iteration']++):
$this->_sections['ap']['rownum'] = $this->_sections['ap']['iteration'];
$this->_sections['ap']['index_prev'] = $this->_sections['ap']['index'] - $this->_sections['ap']['step'];
$this->_sections['ap']['index_next'] = $this->_sections['ap']['index'] + $this->_sections['ap']['step'];
$this->_sections['ap']['first']      = ($this->_sections['ap']['iteration'] == 1);
$this->_sections['ap']['last']       = ($this->_sections['ap']['iteration'] == $this->_sections['ap']['total']);
?>
											tree6.addNode(new MTreeNode("<?php echo $this->_tpl_vars['apps'][$this->_sections['ap']['index']]['app_name']; ?>
","b14","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_availabilitymetrica1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' ><?php echo $this->_tpl_vars['apps'][$this->_sections['ap']['index']]['app_name']; ?>
</span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/ico_zblb.gif' width='16' height='16'>","","","","",""));	
											<?php endfor; endif; ?>

											<?php unset($this->_sections['app']);
$this->_sections['app']['name'] = 'app';
$this->_sections['app']['loop'] = is_array($_loop=$this->_tpl_vars['appdetail']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['app']['show'] = true;
$this->_sections['app']['max'] = $this->_sections['app']['loop'];
$this->_sections['app']['step'] = 1;
$this->_sections['app']['start'] = $this->_sections['app']['step'] > 0 ? 0 : $this->_sections['app']['loop']-1;
if ($this->_sections['app']['show']) {
    $this->_sections['app']['total'] = $this->_sections['app']['loop'];
    if ($this->_sections['app']['total'] == 0)
        $this->_sections['app']['show'] = false;
} else
    $this->_sections['app']['total'] = 0;
if ($this->_sections['app']['show']):

            for ($this->_sections['app']['index'] = $this->_sections['app']['start'], $this->_sections['app']['iteration'] = 1;
                 $this->_sections['app']['iteration'] <= $this->_sections['app']['total'];
                 $this->_sections['app']['index'] += $this->_sections['app']['step'], $this->_sections['app']['iteration']++):
$this->_sections['app']['rownum'] = $this->_sections['app']['iteration'];
$this->_sections['app']['index_prev'] = $this->_sections['app']['index'] - $this->_sections['app']['step'];
$this->_sections['app']['index_next'] = $this->_sections['app']['index'] + $this->_sections['app']['step'];
$this->_sections['app']['first']      = ($this->_sections['app']['iteration'] == 1);
$this->_sections['app']['last']       = ($this->_sections['app']['iteration'] == $this->_sections['app']['total']);
?>
											tree6.addNode(new MTreeNode("b141<?php echo $this->_sections['app']['index']; ?>
","<?php echo $this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_name']; ?>
","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_availabilitymetrica1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=appbytype&id=<?php echo $this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['seq']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');><?php if ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_name'] == 'apache'): ?><?php if ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'cpu load'): ?>系统占用<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'request rate'): ?>请求速率<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'traffic rate'): ?>每秒流量 KB/s<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'process num'): ?>当前进行数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'busy process'): ?>正在处理请求<?php else: ?>未定义<?php endif; ?><?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_name'] == 'mysql'): ?><?php if ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'questions rate'): ?>查询速率<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'open tables'): ?>打开表数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'open files'): ?>打开文件数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'threads'): ?>连接数<?php else: ?>未定义<?php endif; ?><?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_name'] == 'tomcat'): ?><?php if ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'traffic rate'): ?>每秒流量 KB/s<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'cpu load'): ?>CPU平均占用率 %<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'request rate'): ?>每秒请求数量<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'memory usage'): ?>当前jvm内存使用率<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'busy thread'): ?>当前工作线程数<?php else: ?>未定义<?php endif; ?><?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_name'] == 'nginx'): ?><?php if ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'request rate'): ?>nginx 请求率（点击率）<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'connect num'): ?>nginx 连接数（并发数）<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'server accept'): ?>处理连接数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'server handled'): ?>创建连接数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'reading num'): ?>读取客户端header信息数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'writing num'): ?>返回给客户端header信息数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'waiting num'): ?>nginx 等待连接数<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['app_type'] == 'connect num'): ?>等待驻留连接<?php else: ?>未定义<?php endif; ?><?php endif; ?></span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['value'] == NULL || $this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['value'] < 0): ?>RhombusRed.gif<?php elseif ($this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['value'] < $this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['lowvalue'] || $this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['value'] > $this->_tpl_vars['appdetail'][$this->_sections['app']['index']]['highvalue']): ?>RhombusYellow.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb8a1'>","","","","",""));	
											<?php endfor; endif; ?>

											<?php unset($this->_sections['appdns']);
$this->_sections['appdns']['name'] = 'appdns';
$this->_sections['appdns']['loop'] = is_array($_loop=$this->_tpl_vars['appdnsdetail']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['appdns']['show'] = true;
$this->_sections['appdns']['max'] = $this->_sections['appdns']['loop'];
$this->_sections['appdns']['step'] = 1;
$this->_sections['appdns']['start'] = $this->_sections['appdns']['step'] > 0 ? 0 : $this->_sections['appdns']['loop']-1;
if ($this->_sections['appdns']['show']) {
    $this->_sections['appdns']['total'] = $this->_sections['appdns']['loop'];
    if ($this->_sections['appdns']['total'] == 0)
        $this->_sections['appdns']['show'] = false;
} else
    $this->_sections['appdns']['total'] = 0;
if ($this->_sections['appdns']['show']):

            for ($this->_sections['appdns']['index'] = $this->_sections['appdns']['start'], $this->_sections['appdns']['iteration'] = 1;
                 $this->_sections['appdns']['iteration'] <= $this->_sections['appdns']['total'];
                 $this->_sections['appdns']['index'] += $this->_sections['appdns']['step'], $this->_sections['appdns']['iteration']++):
$this->_sections['appdns']['rownum'] = $this->_sections['appdns']['iteration'];
$this->_sections['appdns']['index_prev'] = $this->_sections['appdns']['index'] - $this->_sections['appdns']['step'];
$this->_sections['appdns']['index_next'] = $this->_sections['appdns']['index'] + $this->_sections['appdns']['step'];
$this->_sections['appdns']['first']      = ($this->_sections['appdns']['iteration'] == 1);
$this->_sections['appdns']['last']       = ($this->_sections['appdns']['iteration'] == $this->_sections['appdns']['total']);
?>
											tree6.addNode(new MTreeNode("b142<?php echo $this->_sections['appdns']['index']; ?>
","dns","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/open.gif","<?php echo $this->_tpl_vars['template_root']; ?>
/images/tree<?php echo $this->_tpl_vars['template_root']; ?>
/images/close.gif","","<span id='focusNode_nodehidden_availabilitymetrica1'; style='cursor:hand; border: 0px solid ; overflow: hidden; text-overflow:ellipsis'  class='ly' onclick=window.open('admin.php?controller=admin_detail&action=appbytype&type=dns&id=<?php echo $this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['id']; ?>
&ip=<?php echo $this->_tpl_vars['ip']; ?>
','rightmain');><?php if ($this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['type'] == 1): ?>授权域可用性<?php elseif ($this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['type'] == 2): ?>非授权域可用性<?php else: ?>未定义<?php endif; ?></span>","<img src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/<?php if ($this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['delayvalue'] == NULL || $this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['delayvalue'] < 0): ?>RhombusRed.gif<?php elseif ($this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['delayvalue'] < $this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['lowvalue'] || $this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['delayvalue'] > $this->_tpl_vars['appdnsdetail'][$this->_sections['appdns']['index']]['highvalue']): ?>RhombusYellow.gif<?php else: ?>RhombusGreen.gif<?php endif; ?>' width='16' height='16' id='imgb8a1'>","","","","",""));	
											<?php endfor; endif; ?>
							
											
							 <?php endif; ?>


											
														
								
		
								// 将对象结构转为html，写到网页中
								
										document.write("<div id='myspan'>");
										test=tree6.getTreeHtml();
										
										document.write(test);						
										document.write("</div>");
										//tree6.clickDemo('WindowHostName');

								tree6.expandAll();


							</script>
                  		</td>
                  	</tr>
                  
                  

				  </table>			    
                 </div>
                </td>
            </tr>
          </table>
<!-- 边框的结尾-->

</body>

</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
</body>
</html>