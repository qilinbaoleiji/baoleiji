<?php /* Smarty version 2.6.18, created on 2014-12-05 18:56:57
         compiled from log_eventlogs.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['language']['SessionsList']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />

<script src="./template/admin/cssjs/jscal2.js"></script>
<script src="./template/admin/cssjs/cn.js"></script>
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/jscal2.css" />
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/border-radius.css" />
<SCRIPT>
	function my_confirm(str){
		if(!confirm("确认要" + str + "？"))
		{
			window.event.returnValue = false;
		}
	}
	function chk_form(){
		for(var i = 0; i < document.list.elements.length;i++){
			var e = document.list.elements[i];
			if(e.name == 'chk_member[]' && e.checked == true)
				return true;
		}
		alert("您没有选任何记录！");
		return false;
	}
</SCRIPT>
</head>
<body>
<style type="text/css">
a {
    color: #003499;
    text-decoration: none;
} 
a:hover {
    color: #000000;
    text-decoration: underline;
}
</style>
<td width="84%" align="left" valign="top">
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#F1F1F1">
<tr><td valign="middle" class="hui_bj" align="left">
<div class="menu">
<ul>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_search">综合日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_eventlogs&action=applogs">应用日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_login">登录日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_authpriv">权限日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_eventlogs">报警日志</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>

</ul>
</div>
</td></tr>

  <tr>
    <td >
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_content">
  <tr>
    <td>
    <FORM method=get name=f1   onSubmit="return false;"    action=admin.php>
         <INPUT id="controller " value=admin_eventlogs type=hidden name=c>
      <INPUT id=action value=index type=hidden   name=a> 
		    服务器:<INPUT name=hostname  size="12" class="wbk"> 
		     事件:<INPUT name=event  size="12" class="wbk"> 
		    日志内容:<INPUT name=msg  size="12" class="wbk"> 
		  时间：<input type="text"  name="f_rangeStart" size="13" id="f_rangeStart"  class="wbk" /> 
				<input type="button"  id="f_rangeStart_trigger" name="f_rangeStart_trigger" value="选择时间" class="wbk">
		      
		      <INPUT  size="12" class="bnnew2"  onClick="JavaScript: document.getElementById('action').value='index';submit();" value=查找  type=button> 
	</FORM>
</td>
  </tr>
</table>	

	  </td>
  </tr>
  <tr><td>
  <table bordercolor="white" cellspacing="0" cellpadding="5" border="0" width="100%" class="BBtable">
	 <FORM method=post name=list     action=admin.php?controller=admin_eventlogs&amp;action=delete_all&amp;t=eventlogs>
					
				<tr>
			 	     <TH width="3%" class="list_bg">选</TH>
			          <TH width="3%" class="list_bg">ID</TH>
			          <TH width="10%" class="list_bg">服务器</TH>
			           <TH width="8%" class="list_bg">程序</TH>
			          <TH width="5%" class="list_bg">级别</TH>
			          <TH width="10%" class="list_bg">时间</TH>
			            <TH width="15%" class="list_bg">事件</TH>
			          <TH width="5%" class="list_bg">状态</TH>

					      <TH class="list_bg"  width="5%"  >操作</TH>
					</tr>
					 <?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['all']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
  			 <TR class="list_tr_bg<?php if ($this->_sections['t']['index'] % 2 != 0): ?>1<?php endif; ?>">
	    			  <TD><INPUT value=<?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['seq']; ?>
 type=checkbox name=chk_member[]></TD>
			          <TD><?php echo $this->_sections['t']['index']+1; ?>
</TD>
			          <TD><?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['host']; ?>
</TD>
			          <TD><?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['program']; ?>
</TD>
			          <TD>
							<?php if ($this->_tpl_vars['all'][$this->_sections['t']['index']]['msg_level'] == '1'): ?>信息
							<?php elseif ($this->_tpl_vars['all'][$this->_sections['t']['index']]['msg_level'] == '2'): ?>警告
							<?php elseif ($this->_tpl_vars['all'][$this->_sections['t']['index']]['msg_level'] == '3'): ?>严重
							<?php elseif ($this->_tpl_vars['all'][$this->_sections['t']['index']]['msg_level'] == '4'): ?>非常严重		
							<?php else: ?>紧急
							<?php endif; ?>
						</TD>
			          <TD><?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['datetime']; ?>
</TD>
 						<TD><?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['event']; ?>
</TD>
 						<TD>
	 						<?php if ($this->_tpl_vars['all'][$this->_sections['t']['index']]['status'] == '1'): ?>处理
							<?php else: ?>未处理
							<?php endif; ?>
 						</TD>
			          <TD >
				  	<input name="detail" type="button" value="详细"  onclick="javascript:window.open('admin.php?controller=admin_eventlogs&action=detail&t=eventlogs&id=<?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['seq']; ?>
','newwin')" class="bnnew2"  />
			          </TD>
					</tr>
					<?php endfor; endif; ?>
		<TR>
          <TD colSpan=9 align=left>
          <INPUT  onclick="javascript:for(var i=0;i<this.form.elements.length;i++){var e=this.form.elements[i];if(e.name=='chk_member[]')e.checked=this.form.select_all.checked;}" 
            value=checkbox type=checkbox name=select_all>选本页显示的所有记录&nbsp;&nbsp;<INPUT class=an_06 onClick="my_confirm('删除所选记录');if(!chk_form())  return false;" value=批量删除所选记录 type=submit>      
            
            
            </TD>
         </TR>
				</FORM>	
					<tr>
						<td height="45" colspan="9" align="right" bgcolor="#FFFFFF">
							<?php echo $this->_tpl_vars['language']['all']; ?>
<?php echo $this->_tpl_vars['session_num']; ?>
<?php echo $this->_tpl_vars['language']['Session']; ?>
  <?php echo $this->_tpl_vars['page_list']; ?>
  <?php echo $this->_tpl_vars['language']['Page']; ?>
：<?php echo $this->_tpl_vars['curr_page']; ?>
/<?php echo $this->_tpl_vars['total_page']; ?>
<?php echo $this->_tpl_vars['language']['page']; ?>
  <?php echo $this->_tpl_vars['items_per_page']; ?>
条/每页 
							  转到第<input name="pagenum" type="text" size="2" onKeyPress="if(event.keyCode==13) window.location='<?php echo $this->_tpl_vars['curr_url']; ?>
&page='+this.value;" class="wbk">
							  页&nbsp;  
						</td>
					</tr>
				</table>
	</td>
  </tr>
</table></td>

<script type="text/javascript">

                  new Calendar({
                          inputField: "f_rangeStart",
                          dateFormat: "%Y-%m-%d %H:%M",
                          trigger: "f_rangeStart_trigger",
                          bottomBar: false,
                          showTime: true,
                          onSelect: function() {
                                  var date = Calendar.intToDate(this.selection.get());
                                 
                                  this.hide();
                          }
                  });

</script>
</body>
</html>

