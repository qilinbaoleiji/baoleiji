<?php /* Smarty version 2.6.18, created on 2015-03-26 23:32:19
         compiled from threepripwd_twopwd.tpl */ ?>
  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
  <TBODY>
  <TR>
    <TD align="center" class="tb_t_bg">填写三权密码</TD>
  </TR>
  <TR>
    <TD>
      <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
        <TBODY>
        <TR>
          <TD align="center">
           <form name="f1" method=post enctype="multipart/form-data" action="admin.php?controller=admin_config&action=dothreepripwd_twopwd" target="hide">
            <TABLE width="100%" bgcolor="#ffffff" border="0" cellspacing="1" 
            cellpadding="5" valign="top">
              <TBODY>
              <TR bgcolor="#f7f7f7">
                <TD width="30%" height="32" align="right">Audit密码: </TD>
                <TD><INPUT name="auditpassword"   id="auditpassword" type="password" value="" autocomplete="off"></TD></TR>
              <TR>
                <TD width="30%" height="32" align="right">Password密码: </TD>
                <TD><INPUT name="passwordpassword" id="passwordpassword" type="password" value="" autocomplete="off"></TD></TR>
              <TR>
                <TD height="32" align="right"></TD>
                <TD><INPUT class="an_02" type="submit" value="提交" name="actions"></TD></TR></TBODY></TABLE>
      </FORM></TD></TR></TBODY></TABLE></TR></TBODY></TABLE>


