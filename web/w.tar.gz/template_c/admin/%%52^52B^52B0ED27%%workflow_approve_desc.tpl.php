<?php /* Smarty version 2.6.18, created on 2014-12-15 16:24:04
         compiled from workflow_approve_desc.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo $this->_tpl_vars['template_root']; ?>
/Calendarandtime.js"></script>
</head>

<body>


	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td class="">

        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center"><form name="f1" method=post enctype="multipart/form-data" action="admin.php?controller=admin_workflow&action=do_workflow_approve&wid=<?php echo $this->_tpl_vars['wid']; ?>
&status=<?php echo $this->_tpl_vars['status']; ?>
">
	<table border=0 width=100% cellpadding=5 cellspacing=1 bgcolor="#FFFFFF" valign=top>
	<?php if ($this->_tpl_vars['last']): ?>
	<tr bgcolor="f7f7f7">
                  <TD  width="33%" align=center>操作人： </TD>
				  </tr>
				  <tr>
                  <TD>含有字符<input type="text" class="wbk" size="10" id="filtertext" onchange="filter();" />
                  <select  class="wbk"  name=username id="username" onchange="check_userpriority(<?php echo $this->_tpl_vars['wf']['devicesid']; ?>
, this.value)">
                      <OPTION value="">请选择</OPTION>
                     	<?php unset($this->_sections['k']);
$this->_sections['k']['name'] = 'k';
$this->_sections['k']['loop'] = is_array($_loop=$this->_tpl_vars['members']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['k']['show'] = true;
$this->_sections['k']['max'] = $this->_sections['k']['loop'];
$this->_sections['k']['step'] = 1;
$this->_sections['k']['start'] = $this->_sections['k']['step'] > 0 ? 0 : $this->_sections['k']['loop']-1;
if ($this->_sections['k']['show']) {
    $this->_sections['k']['total'] = $this->_sections['k']['loop'];
    if ($this->_sections['k']['total'] == 0)
        $this->_sections['k']['show'] = false;
} else
    $this->_sections['k']['total'] = 0;
if ($this->_sections['k']['show']):

            for ($this->_sections['k']['index'] = $this->_sections['k']['start'], $this->_sections['k']['iteration'] = 1;
                 $this->_sections['k']['iteration'] <= $this->_sections['k']['total'];
                 $this->_sections['k']['index'] += $this->_sections['k']['step'], $this->_sections['k']['iteration']++):
$this->_sections['k']['rownum'] = $this->_sections['k']['iteration'];
$this->_sections['k']['index_prev'] = $this->_sections['k']['index'] - $this->_sections['k']['step'];
$this->_sections['k']['index_next'] = $this->_sections['k']['index'] + $this->_sections['k']['step'];
$this->_sections['k']['first']      = ($this->_sections['k']['iteration'] == 1);
$this->_sections['k']['last']       = ($this->_sections['k']['iteration'] == $this->_sections['k']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['members'][$this->_sections['k']['index']]['uid']; ?>
" <?php if ($this->_tpl_vars['members'][$this->_sections['k']['index']]['uid'] == $this->_tpl_vars['member']['usbkey']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['members'][$this->_sections['k']['index']]['username']; ?>
</option>
			<?php endfor; endif; ?>
                  </SELECT>        
				  </TD>
                </TR>
	<?php endif; ?>
                <TR bgcolor="f7f7f7">
                  <TD width="50%" align=center>备注: </TD>
				  </tr>
				  <tr>
                  <TD><textarea cols=55 rows=5 name="description"></textarea>               
				  </TD>
                </TR>            
	<tr><td align=center><input type=submit onclick="<?php if ($this->_tpl_vars['last']): ?>return cansubmit()<?php endif; ?>"  value="提交" class="an_02"></td></tr></table>
</form>
	</td>
  </tr>
</table>

</body>
<iframe name="hide" height="0" frameborder="0" scrolling="no"></iframe>
</html>


