<?php /* Smarty version 2.6.18, created on 2014-12-01 21:13:29
         compiled from eventlogs.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>详细信息</TITLE>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<LINK rel=stylesheet type=text/css 
href="<?php echo $this->_tpl_vars['template_root']; ?>
/cssjs/liye.css">
<META name=GENERATOR content="MSHTML 8.00.6001.23501">
<SCRIPT type=text/javascript>

function allreload(){
	window.location.reload();
}

function allclose(){
	window.close();
}


                            

</SCRIPT>
</HEAD>
<BODY>
  <table width="700" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td align="left" valign="top">
                          <table width="96%" border="1" align="center" cellpadding="0" cellspacing="0"  bordercolorlight="#D4D4D4" bordercolordark="#FFFFFF" bgcolor="#F9F9F9">
                            <tr>
                              <td align="center" bgcolor="#D6E8FF" valign="middle"><table height="22" border="0" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td rowspan="2" valign="middle" align="center"><nobr><strong>等级</strong></nobr></td>
                                    <td height="11" align="center" valign="bottom"><a href="#" onClick="showOrderBy('-1', 'asc');return false;"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/st-paixus.gif" width="10" height="8" align="absmiddle" border="0"></a></td>
                                  </tr>
                                  <tr>
                                    <td height="11" align="center" valign="top"><a href="#" onClick="showOrderBy('-1', 'desc');return false;"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/st-paixu.gif" width="10" height="6" align="absmiddle" border="0"></a></td>
                                  </tr>
                              </table></td>
                              <td  align="center" bgcolor="#D6E8FF"><nobr><strong>时间</strong></nobr></td>
                             
                          
                              <td  height="46" align="center" bgcolor="#D6E8FF" valign="middle"><table width="100" height="22" border="0" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td rowspan="2" valign="middle" align="center"><nobr><strong>program</strong></nobr></td>
                                    <td height="11" align="center" valign="bottom"><a href="#" onClick="showOrderBy('2', 'asc');return false;"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/st-paixus.gif" width="10" height="8" align="absmiddle" border="0"></a></td>
                                  </tr>
                                  <tr>
                                    <td height="11" align="center" valign="top"><a href="#" onClick="showOrderBy('2', 'desc');return false;"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/st-paixu.gif" width="10" height="6" align="absmiddle" border="0"></a></td>
                                  </tr>
                              </table></td>
                              <td  height="46" align="center" bgcolor="#D6E8FF" valign="middle"><table width="100" height="22" border="0" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td rowspan="2" valign="middle" align="center"><nobr><strong>信息</strong></nobr></td>
                                    <td height="11" align="center" valign="bottom"><a href="#" onClick="showOrderBy('3', 'asc');return false;"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/st-paixus.gif" width="10" height="8" align="absmiddle" border="0"></a></td>
                                  </tr>
                                  <tr>
                                    <td height="11" align="center" valign="top"><a href="#" onClick="showOrderBy('3', 'desc');return false;"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/st-paixu.gif" width="10" height="6" align="absmiddle" border="0"></a></td>
                                  </tr>
                              </table></td>
                             
                            </tr>
							<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['eventlogs']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
                            <tr>
                              <td><span onMouseOver="showAllContent('<?php echo $this->_tpl_vars['eventlogs'][$this->_sections['i']['index']]['port_describe']; ?>
', 16);" onMouseOut="document.getElementById('msg_id').style.display='none';"><nobr><img style="cursor:hand" src='<?php echo $this->_tpl_vars['template_root']; ?>
/images/Gray.gif' onClick="gotoStateSearch('472614B7732A12081FB6B5FCDE870DA688C0CDB8');" /><span style="width:120; overflow: hidden; text-overflow:ellipsis;"><nobr><?php echo $this->_tpl_vars['eventlogs'][$this->_sections['i']['index']]['level']; ?>
</nobr></span></nobr></span></td>
                              <td><NOBR><?php echo $this->_tpl_vars['eventlogs'][$this->_sections['i']['index']]['datetime']; ?>
</NOBR></td>
                             
                              <td width="98" height="30" align="center" id="01" style=""><nobr> <a style="text-decoration: none;" href="javascript:void(0);"><?php echo $this->_tpl_vars['eventlogs'][$this->_sections['i']['index']]['program']; ?>
</a> </nobr> </td>
                              <td width="98" height="30" align="center" id="02" style=""><nobr> <a style="text-decoration: none;" href="javascript:void(0);"><?php echo $this->_tpl_vars['eventlogs'][$this->_sections['i']['index']]['msg']; ?>
</a> </nobr> </td>
                            </tr>
							<?php endfor; endif; ?>
                            
                          </table>
                      </td>
                    </tr>
                  </table>

</BODY></HTML>


