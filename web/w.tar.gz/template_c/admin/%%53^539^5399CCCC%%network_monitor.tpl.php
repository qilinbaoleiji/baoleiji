<?php /* Smarty version 2.6.18, created on 2014-12-02 22:30:30
         compiled from network_monitor.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'truncate', 'network_monitor.tpl', 128, false),)), $this); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd"><HTML 
xmlns="http://www.w3.org/1999/xhtml"><HEAD><META content="IE=10.000" 
http-equiv="X-UA-Compatible">
 <TITLE>OSSIM框架</TITLE> 
<META http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<META http-equiv="Pragma" content="no-cache"> <LINK href="template/admin/all_purpose_style.css" 
rel="stylesheet" type="text/css"> 
<STYLE>HTML {
	MARGIN: 0px; HEIGHT: 100%; FONT-SIZE: 12px
}
BODY {
	MARGIN: 0px; HEIGHT: 100%; FONT-SIZE: 12px
}
.mesWindow {
	BORDER-BOTTOM: #666 1px solid; BORDER-LEFT: #666 1px solid; BACKGROUND: #fff; BORDER-TOP: #666 1px solid; BORDER-RIGHT: #666 1px solid
}
.mesWindowTop {
	BORDER-BOTTOM: #eee 1px solid; TEXT-ALIGN: left; PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; MARGIN-LEFT: 4px; FONT-SIZE: 12px; FONT-WEIGHT: bold; PADDING-TOP: 3px
}
.mesWindowContent {
	MARGIN: 4px; FONT-SIZE: 12px
}
.mesWindow .close {
	BORDER-BOTTOM: medium none; BORDER-LEFT: medium none; WIDTH: 28px; BACKGROUND: #fff; HEIGHT: 15px; BORDER-TOP: medium none; CURSOR: pointer; BORDER-RIGHT: medium none; TEXT-DECORATION: underline
}
.div_s_title {
	width:100%; }
.div_scrollbar {
	width:100%;   height:152px;   z-index:1;   overflow:auto;SCROLLBAR-FACE-COLOR: #ffffff; SCROLLBAR-HIGHLIGHT-COLOR: #f3f3f3; SCROLLBAR-SHADOW-COLOR: COLOR:#000000 ; SCROLLBAR-3DLIGHT-COLOR: #ffffff; SCROLLBAR-ARROW-COLOR: #006c90;  SCROLLBAR-DARKSHADOW-COLOR: #ffffff;  
}
</STYLE>
 
<SCRIPT type="text/javascript">


var interfacesct = new Array();
var interfacesid = new Array();
</SCRIPT>
 
<META name="GENERATOR" content="MSHTML 10.00.9200.16635"></HEAD> 
<BODY>
      <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
        <TR>
          <TD class="hui_bj" valign="middle">
          <DIV class=menu>
      <UL>
		<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_monitor&action=index">状态监控</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
		<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_monitor&action=system_monitor">系统监控</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
		<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_monitor&action=network_monitor">网络监控</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
        </UL></DIV>
        
       </TD></TR>
     <TR>
    <TD>
      <TABLE width="100%" align="center"  border="0" cellspacing="0" cellpadding="8">
        <TR id="network_port1_tr">
          <TD class="main_title_td">
            <TABLE width="99%" height="200" border="0" cellspacing="0" 
            cellpadding="3" class="BBtable">
              
              <tr>
            <td align="center"><a href="#" id="traffic_a" ><img width="480" height="220" id="traffic_graph" src="template/admin/images/nopic.jpg"></a></td>
        
            <td align="center"><a href="#" id="package_a" ><img width="480" height="220" id="package_graph" src="template/admin/images/nopic.jpg"></a></td>
          </tr>
		  </TABLE>
              
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><div class="div_s_title" >
                      <TABLE width="99%" border="0" cellpadding="0" cellspacing="0" class="BBtable" >
                        <TR>
                          <TD width="2%" bgcolor="#b9dbfb"></TD>
                          <TD align="center" bgcolor="#b9dbfb">主机IP</TD>
                          <TD width="13%" align="center" bgcolor="#b9dbfb">主机名</TD>
                          <TD width="13%" align="center" bgcolor="#b9dbfb">运行时间</TD>
                          <TD width="13%" align="center" bgcolor="#b9dbfb">接口数</TD>
                          <TD width="13%" align="center" bgcolor="#b9dbfb">启用接口</TD>
                          <TD width="13%" align="center" bgcolor="#b9dbfb">禁用接口</TD>
                        </TR>
                      </TABLE>
                    </div>
                      <DIV  class="div_scrollbar" >
                        <TABLE width="100%" border="0" cellpadding="0"    cellspacing="0" class="BBtable" id="port1_network" >
                         <?php unset($this->_sections['n']);
$this->_sections['n']['name'] = 'n';
$this->_sections['n']['loop'] = is_array($_loop=$this->_tpl_vars['network']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['n']['show'] = true;
$this->_sections['n']['max'] = $this->_sections['n']['loop'];
$this->_sections['n']['step'] = 1;
$this->_sections['n']['start'] = $this->_sections['n']['step'] > 0 ? 0 : $this->_sections['n']['loop']-1;
if ($this->_sections['n']['show']) {
    $this->_sections['n']['total'] = $this->_sections['n']['loop'];
    if ($this->_sections['n']['total'] == 0)
        $this->_sections['n']['show'] = false;
} else
    $this->_sections['n']['total'] = 0;
if ($this->_sections['n']['show']):

            for ($this->_sections['n']['index'] = $this->_sections['n']['start'], $this->_sections['n']['iteration'] = 1;
                 $this->_sections['n']['iteration'] <= $this->_sections['n']['total'];
                 $this->_sections['n']['index'] += $this->_sections['n']['step'], $this->_sections['n']['iteration']++):
$this->_sections['n']['rownum'] = $this->_sections['n']['iteration'];
$this->_sections['n']['index_prev'] = $this->_sections['n']['index'] - $this->_sections['n']['step'];
$this->_sections['n']['index_next'] = $this->_sections['n']['index'] + $this->_sections['n']['step'];
$this->_sections['n']['first']      = ($this->_sections['n']['iteration'] == 1);
$this->_sections['n']['last']       = ($this->_sections['n']['iteration'] == $this->_sections['n']['total']);
?>
		  <TR onclick="change_network(<?php echo $this->_sections['n']['index']; ?>
)">
			<TD width="2%" class="main_list_td1"><img id="_id_<?php echo $this->_sections['n']['index']; ?>
" src="template/admin/images/lv_dot.gif" width="13" height="13"></TD>
			<TD class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['n']['index']]['device_ip']; ?>
</TD>
			<TD width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['n']['index']]['hostname']; ?>
</TD>
			<TD width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['n']['index']]['snmptime_diff']; ?>
</TD>
			<TD width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['n']['index']]['ct']; ?>
</TD>
			<TD width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['n']['index']]['runct']; ?>
</TD>
			<TD width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['n']['index']]['cutct']; ?>
</TD>
		  </TR>
		  
		 <?php endfor; endif; ?>
                        </TABLE>
                      </DIV>
                      <div class="div_s_title" >
                        <TABLE width="100%" border="0" cellpadding="0"  cellspacing="0" class="BBtable"  valign="top">
                          <TR>
			  <td width="2%" bgcolor="#b9dbfb" class="main_list_title1">&nbsp;</td>
			  <TD width="20%" bgcolor="#b9dbfb" class="main_list_title1"><a id="t_a_port_describe" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=port_describe&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">网络接口</a></TD>
			  <TD width="13%" bgcolor="#b9dbfb" class="main_list_title1"><a id="t_a_cur_status" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=cur_status&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">当前状态</a></TD>
			  <TD width="13%" bgcolor="#b9dbfb" class="main_list_title1"><a id="t_a_connectdevice" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=connectdevice&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">对端设备</a></TD>
			  <TD width="13%" bgcolor="#b9dbfb" class="main_list_title1"><a id="t_a_connectdeviceport" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=connectdeviceport&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">对端接口</a></TD>
			  <TD width="13%" bgcolor="#b9dbfb" class="main_list_title1">流量(<a id="t_a_traffic_in" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=traffic_in&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">入</a>/<a  id="t_a_traffic_out" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=traffic_out&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">出</a>)</TD>
			  <TD width="13%" bgcolor="#b9dbfb" class="main_list_title1">包速率(<a  id="t_a_packet_in" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=packet_in&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">入</a>/<a  id="t_a_packet_out" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=packet_out&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">出</a>)</TD>
			  <TD width="13%" bgcolor="#b9dbfb" class="main_list_title1">错包(<a  id="t_a_err_packet_in" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=err_packet_in&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">入</a>/<a  id="t_a_err_packet_out" href="admin.php?controller=admin_monitor&action=network_monitor&orderby1=err_packet_out&orderby2=<?php echo $this->_tpl_vars['orderby2']; ?>
">出</a>)</TD>
			</TR>
                        </TABLE>
                      </div>
                     <?php unset($this->_sections['nn']);
$this->_sections['nn']['name'] = 'nn';
$this->_sections['nn']['loop'] = is_array($_loop=$this->_tpl_vars['network']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['nn']['show'] = true;
$this->_sections['nn']['max'] = $this->_sections['nn']['loop'];
$this->_sections['nn']['step'] = 1;
$this->_sections['nn']['start'] = $this->_sections['nn']['step'] > 0 ? 0 : $this->_sections['nn']['loop']-1;
if ($this->_sections['nn']['show']) {
    $this->_sections['nn']['total'] = $this->_sections['nn']['loop'];
    if ($this->_sections['nn']['total'] == 0)
        $this->_sections['nn']['show'] = false;
} else
    $this->_sections['nn']['total'] = 0;
if ($this->_sections['nn']['show']):

            for ($this->_sections['nn']['index'] = $this->_sections['nn']['start'], $this->_sections['nn']['iteration'] = 1;
                 $this->_sections['nn']['iteration'] <= $this->_sections['nn']['total'];
                 $this->_sections['nn']['index'] += $this->_sections['nn']['step'], $this->_sections['nn']['iteration']++):
$this->_sections['nn']['rownum'] = $this->_sections['nn']['iteration'];
$this->_sections['nn']['index_prev'] = $this->_sections['nn']['index'] - $this->_sections['nn']['step'];
$this->_sections['nn']['index_next'] = $this->_sections['nn']['index'] + $this->_sections['nn']['step'];
$this->_sections['nn']['first']      = ($this->_sections['nn']['iteration'] == 1);
$this->_sections['nn']['last']       = ($this->_sections['nn']['iteration'] == $this->_sections['nn']['total']);
?>
		<script >
		interfacesid[<?php echo $this->_sections['nn']['index']; ?>
] = new Array();
		</script>
	
		
		<div id="_<?php echo $this->_sections['nn']['index']; ?>
" class="div_scrollbar" style="display:none">	 
		<TABLE align=center cellpadding="0" cellspacing="1"  valign="top"  class="BBtable" width="100%" >
			<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
			<script >
			interfacesid[<?php echo $this->_sections['nn']['index']; ?>
][<?php echo $this->_sections['i']['index']; ?>
]=<?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['id']; ?>
;
			</script>
			<TR onclick="change_network_interface(<?php echo $this->_sections['nn']['index']; ?>
,<?php echo $this->_sections['i']['index']; ?>
,<?php echo $this->_sections['nn']['total']; ?>
);">
			  <TD  width="2%" class="main_list_td1"><img id="_id_<?php echo $this->_sections['nn']['index']; ?>
_<?php echo $this->_sections['i']['index']; ?>
" src="template/admin/images/lv_dot.gif" width="13" height="13"></TD>
			  <TD width="20%" class="main_list_td1" title="<?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['port_describe']; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['port_describe'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 30) : smarty_modifier_truncate($_tmp, 30)); ?>
</TD>
			  <TD  width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['cur_status']; ?>
</TD>
			  <TD  width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['connectdevice']; ?>
</TD>
			  <TD  width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['connectdeviceport']; ?>
</TD>
			  <TD  width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['traffic_in']; ?>
/<?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['traffic_out']; ?>
</TD>
			  <TD  width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['packet_in']; ?>
/<?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['packet_out']; ?>
</TD>
			  <TD  width="13%" class="main_list_td1"><?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['err_packet_in']; ?>
/<?php echo $this->_tpl_vars['network'][$this->_sections['nn']['index']]['interfaces'][$this->_sections['i']['index']]['err_packet_out']; ?>
</TD>
			</TR>
			<?php endfor; endif; ?>
			
			<!-- pagination -->
		  </TBODY>
		</TABLE>
	</div>
		<script >
		interfacesct[<?php echo $this->_sections['nn']['index']; ?>
]=<?php echo $this->_sections['i']['total']; ?>
;
		</script>
		<?php endfor; endif; ?>
	</td></tr>
                </table>
              <div class="div_s_title" ></div>
          </TD></TR></TABLE></TR></TBODY></TABLE>
<SCRIPT>
var total = <?php echo $this->_sections['n']['total']; ?>
;
function change_network(index){
	if(document.getElementById('_id_'+index)!=undefined)
	document.getElementById('_id_'+index).src='template/admin/images/lv_dot.gif';
	if(document.getElementById('_'+index)!=undefined)
	document.getElementById('_'+index).style.display='';
	document.getElementById('t_a_port_describe').href=document.getElementById('t_a_port_describe').href+'&index='+index;
	document.getElementById('t_a_cur_status').href=document.getElementById('t_a_cur_status').href+'&index='+index;
	document.getElementById('t_a_connectdevice').href=document.getElementById('t_a_connectdevice').href+'&index='+index;
	document.getElementById('t_a_connectdeviceport').href=document.getElementById('t_a_connectdeviceport').href+'&index='+index;
	document.getElementById('t_a_traffic_in').href=document.getElementById('t_a_traffic_in').href+'&index='+index;
	document.getElementById('t_a_traffic_out').href=document.getElementById('t_a_traffic_out').href+'&index='+index;
	document.getElementById('t_a_packet_in').href=document.getElementById('t_a_packet_in').href+'&index='+index;
	document.getElementById('t_a_packet_out').href=document.getElementById('t_a_packet_out').href+'&index='+index;
	document.getElementById('t_a_err_packet_in').href=document.getElementById('t_a_err_packet_in').href+'&index='+index;
	document.getElementById('t_a_err_packet_out').href=document.getElementById('t_a_err_packet_out').href+'&index='+index;
	for(var j=0; j<total; j++){
		 if(j==index) continue;
		document.getElementById('_id_'+j).src='template/admin/images/hui_dot.gif';
		document.getElementById('_'+j).style.display='none';
	}
	change_network_interface(index, 0);
}

function change_network_interface(ni,index){
	  if(interfacesid.length>0 && interfacesid[ni].length > 0){
	  document.getElementById('traffic_graph').src="admin.php?controller=admin_monitor&action=interface_image&type=traffic&id="+interfacesid[ni][index]+"&"+parseInt(10000*Math.random());
	 document.getElementById('package_graph').src="admin.php?controller=admin_monitor&action=interface_image&type=packet&id="+interfacesid[ni][index]+"&"+parseInt(10000*Math.random());
	}
	 for(var j=0; j<interfacesct[ni]; j++){
		document.getElementById('_id_'+ni+'_'+j).src='template/admin/images/hui_dot.gif';
	 }
	 if(document.getElementById('_id_'+ni+'_'+index)!=undefined)
	 document.getElementById('_id_'+ni+'_'+index).src='template/admin/images/lv_dot.gif';
}

change_network(<?php echo $this->_tpl_vars['index']; ?>
);
 </SCRIPT>
 </BODY></HTML>