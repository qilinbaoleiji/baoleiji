<?php /* Smarty version 2.6.18, created on 2015-01-26 17:18:37
         compiled from dns_report.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['language']['SessionsList']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />

<script src="./template/admin/cssjs/jscal2.js"></script>
<script src="./template/admin/cssjs/cn.js"></script>
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/jscal2.css" />
<link type="text/css" rel="stylesheet" href="./template/admin/cssjs/border-radius.css" />
<SCRIPT>
	function my_confirm(str){
		if(!confirm("确认要" + str + "？"))
		{
			window.event.returnValue = false;
		}
	}
	function chk_form(){
		for(var i = 0; i < document.list.elements.length;i++){
			var e = document.list.elements[i];
			if(e.name == 'chk_member[]' && e.checked == true)
				return true;
		}
		alert("您没有选任何记录！");
		return false;
	}
	
   function searchit(orderby1,orderby2){

	document.search.action = "admin.php?controller=admin_reports&action=dns_report&orderby1="+orderby1+"&orderby2="+orderby2;
	document.search.orderby1.value=orderby1;
	document.search.orderby2.value=orderby2;
	document.search.submit();

	return true;
	}
</SCRIPT>
</head>
<body>
<style type="text/css">
a {
    color: #003499;
    text-decoration: none;
} 
a:hover {
    color: #000000;
    text-decoration: underline;
}
</style>
<td width="84%" align="left" valign="top">
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#F1F1F1">
<tr><td valign="middle" class="hui_bj" align="left">
<div class="menu">
<ul>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_reports&action=host_reports">主机报表</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_reports&action=app_reports">应用报表</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_reports&action=dns_report">DNS报表</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
</ul>
</div>
</td></tr>

  <tr>
    <td >
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="main_content">
  <tr>
    <td>
      <FORM method=get name=f1   onSubmit="return false;"    action=admin.php>
         <INPUT id="controller " value=admin_reports type=hidden name=controller>
      <INPUT id=action value=dns_report type=hidden   name=action> 
      
		<input type="radio" name="listType" value="month"   <?php if ($this->_tpl_vars['listType'] == 'month'): ?>checked<?php endif; ?> >每月&nbsp;
             <input type="radio" name="listType" value="week" <?php if ($this->_tpl_vars['listType'] == 'week'): ?>checked<?php endif; ?> >按周&nbsp;
             <input type="radio" name="listType"  value="day" <?php if ($this->_tpl_vars['listType'] == 'day' || $this->_tpl_vars['listType'] == ""): ?>checked<?php endif; ?> >按天&nbsp;
             <input class="wbk" type="text" name="f_rangeStart" id="f_rangeStart" <?php if ($this->_tpl_vars['f_rangeStart'] != ""): ?>value=<?php echo $this->_tpl_vars['f_rangeStart']; ?>
<?php endif; ?> />
 	         <input class="wbk" type="button" id="f_rangeStart_trigger" name="f_rangeStart_trigger" value="选择时间">
    		 <input type="hidden" name="orderby1" id="orderby1"  value="" />
		     <input type="hidden" name="orderby2" id="orderby2"  value="" />
		  
               <INPUT  size="12" class="an_02"  onClick="JavaScript:submit();" value=确定  type=button> 
	</FORM>
</td>
  </tr>
</table>	

	  </td>
  </tr>
  <tr><td>
  <table bordercolor="white" cellspacing="0" cellpadding="5" border="0" width="100%" class="BBtable">
	 <FORM method=post name=list     action=admin.php?controller=admin_countlogs&amp;a=delete_all&amp;t=countlogs_day_detailed>
					
				<tr>
			 	       <TH width="3%" class="list_bg">选</TH>
			          <TH width="3%" class="list_bg">ID</TH>
			          <TH width="8%" class="list_bg"><a href="#"  onClick="searchit('host','<?php echo $this->_tpl_vars['orderby2']; ?>
');">设备IP</a></TH>
			          <TH width="15%" class="list_bg"><a href="#"  onClick="searchit('date','<?php echo $this->_tpl_vars['orderby2']; ?>
');">时间</a></TH>
			          <TH width="8%" class="list_bg"><a href="#"  onClick="searchit('DEBUG','<?php echo $this->_tpl_vars['orderby2']; ?>
');">类型</a></TH>
			          <TH width="5%" class="list_bg"><a href="#"  onClick="searchit('INFO','<?php echo $this->_tpl_vars['orderby2']; ?>
');">延迟时间(ms)</a></TH>
					</tr>
					 <?php unset($this->_sections['t']);
$this->_sections['t']['name'] = 't';
$this->_sections['t']['loop'] = is_array($_loop=$this->_tpl_vars['all']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['t']['show'] = true;
$this->_sections['t']['max'] = $this->_sections['t']['loop'];
$this->_sections['t']['step'] = 1;
$this->_sections['t']['start'] = $this->_sections['t']['step'] > 0 ? 0 : $this->_sections['t']['loop']-1;
if ($this->_sections['t']['show']) {
    $this->_sections['t']['total'] = $this->_sections['t']['loop'];
    if ($this->_sections['t']['total'] == 0)
        $this->_sections['t']['show'] = false;
} else
    $this->_sections['t']['total'] = 0;
if ($this->_sections['t']['show']):

            for ($this->_sections['t']['index'] = $this->_sections['t']['start'], $this->_sections['t']['iteration'] = 1;
                 $this->_sections['t']['iteration'] <= $this->_sections['t']['total'];
                 $this->_sections['t']['index'] += $this->_sections['t']['step'], $this->_sections['t']['iteration']++):
$this->_sections['t']['rownum'] = $this->_sections['t']['iteration'];
$this->_sections['t']['index_prev'] = $this->_sections['t']['index'] - $this->_sections['t']['step'];
$this->_sections['t']['index_next'] = $this->_sections['t']['index'] + $this->_sections['t']['step'];
$this->_sections['t']['first']      = ($this->_sections['t']['iteration'] == 1);
$this->_sections['t']['last']       = ($this->_sections['t']['iteration'] == $this->_sections['t']['total']);
?>
  					 <TR class="list_tr_bg<?php if ($this->_sections['t']['index'] % 2 != 0): ?>1<?php endif; ?>">
	    			 <TD><INPUT value=<?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['id']; ?>
 type=checkbox name=chk_member[]></TD>
			          <TD><?php echo $this->_sections['t']['index']+1; ?>
</TD>
			          <TD><?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['device_ip']; ?>
</TD>
			          <TD><?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['date']; ?>
</TD>
			          <TD><?php if ($this->_tpl_vars['all'][$this->_sections['t']['index']]['type'] == 1): ?>授权域可用性<?php else: ?>非授权域可用性<?php endif; ?></TD>
			          <TD><?php echo $this->_tpl_vars['all'][$this->_sections['t']['index']]['avg']; ?>
</TD>
					</tr>
					<?php endfor; endif; ?>
		<TR>
          <TD colSpan=14 align=left>
          <INPUT  onclick="javascript:for(var i=0;i<this.form.elements.length;i++){var e=this.form.elements[i];if(e.name=='chk_member[]')e.checked=this.form.select_all.checked;}" 
            value=checkbox type=checkbox name=select_all>选本页显示的所有记录&nbsp;&nbsp;<INPUT class=an_06 onClick="my_confirm('删除所选记录');if(!chk_form())  return false;" value=批量删除所选记录 type=submit>      
            
             
          </TD>
         </TR>
				</FORM>	
					<tr>
						<td height="45" colspan="14" align="right" bgcolor="#FFFFFF">
							<?php echo $this->_tpl_vars['language']['all']; ?>
<?php echo $this->_tpl_vars['session_num']; ?>
<?php echo $this->_tpl_vars['language']['Session']; ?>
  <?php echo $this->_tpl_vars['page_list']; ?>
  <?php echo $this->_tpl_vars['language']['Page']; ?>
：<?php echo $this->_tpl_vars['curr_page']; ?>
/<?php echo $this->_tpl_vars['total_page']; ?>
<?php echo $this->_tpl_vars['language']['page']; ?>
  <?php echo $this->_tpl_vars['items_per_page']; ?>
条/每页 
							  转到第<input name="pagenum" type="text" size="2" onKeyPress="if(event.keyCode==13) window.location='<?php echo $this->_tpl_vars['curr_url']; ?>
&page='+this.value;" class="wbk">
							  页&nbsp;  
						</td>
					</tr>
				</table>
	</td>
  </tr>
</table></td>

<script type="text/javascript">
                  new Calendar({
                          inputField: "f_rangeStart",
                          dateFormat: "%Y-%m-%d",
                          trigger: "f_rangeStart_trigger",
                          bottomBar: false,
                          onSelect: function() {
                                  var date = Calendar.intToDate(this.selection.get());
                                 
                                  this.hide();
                          }
                  });
                  
function export1(){
var f_rangeStart = document.getElementById("f_rangeStart").value;
location.href='admin.php?controller=admin_countlogs&action=export&table=log_countlogs_day_detailed&f_rangeStart='+f_rangeStart;

}

function export2(){
var f_rangeStart = document.getElementById("f_rangeStart").value;
location.href='admin.php?controller=admin_countlogs&action=derivetoHTML&table=log_countlogs_day_detailed&f_rangeStart='+f_rangeStart;
}
</script>
</body>
</html>

