<?php /* Smarty version 2.6.18, created on 2015-02-07 17:51:30
         compiled from app_reports.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
<TITLE>OSSIM框架</TITLE>
<META content="text/html; charset=UTF-8" http-equiv=Content-Type>
<META content=no-cache http-equiv=Pragma>
<link href="template/admin/all_purpose_style.css" type="text/css" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="template/admin/cssjs/jscal2.css" />
<script src="template/admin/cssjs/jscal2.js"></script>
<script src="template/admin/cssjs/cn.js"></script>
<STYLE>HTML {
	MARGIN: 0px; HEIGHT: 100%; FONT-SIZE: 12px
}
BODY {
	MARGIN: 0px; HEIGHT: 100%; FONT-SIZE: 12px
}
.mesWindow {
	BORDER-BOTTOM: #666 1px solid; BORDER-LEFT: #666 1px solid; BACKGROUND: #fff; BORDER-TOP: #666 1px solid; BORDER-RIGHT: #666 1px solid
}
.mesWindowTop {
	BORDER-BOTTOM: #eee 1px solid; TEXT-ALIGN: left; PADDING-BOTTOM: 3px; PADDING-LEFT: 3px; PADDING-RIGHT: 3px; MARGIN-LEFT: 4px; FONT-SIZE: 12px; FONT-WEIGHT: bold; PADDING-TOP: 3px
}
.mesWindowContent {
	MARGIN: 4px; FONT-SIZE: 12px
}
.mesWindow .close {
	BORDER-BOTTOM: medium none; BORDER-LEFT: medium none; WIDTH: 28px; BACKGROUND: #fff; HEIGHT: 15px; BORDER-TOP: medium none; CURSOR: pointer; BORDER-RIGHT: medium none; TEXT-DECORATION: underline
}
</STYLE>
<script>
function keyup(keycode){
	if(keycode==13){
		searchit();
	}
}
function changetimetype(id){
	document.getElementById(id).checked = true;
}
</script>
<script type="text/javascript">
function reloadimg(duration){
	var img = document.getElementById("zoomGraphImage");
	img.src=img.src+"&duration="+duration+"&"+parseInt(10000*Math.random());
}
</script>
<script src="./template/admin/cssjs/jquery-1.7.2.min.js"></script>
<script src="./template/admin/cssjs/highcharts.js"></script>
<script src="./template/admin/cssjs/exporting.js"></script>
<script language="JavaScript">

	var chart;
	$(document).ready(function() {
	<?php unset($this->_sections['d']);
$this->_sections['d']['name'] = 'd';
$this->_sections['d']['loop'] = is_array($_loop=$this->_tpl_vars['graphdata']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['d']['show'] = true;
$this->_sections['d']['max'] = $this->_sections['d']['loop'];
$this->_sections['d']['step'] = 1;
$this->_sections['d']['start'] = $this->_sections['d']['step'] > 0 ? 0 : $this->_sections['d']['loop']-1;
if ($this->_sections['d']['show']) {
    $this->_sections['d']['total'] = $this->_sections['d']['loop'];
    if ($this->_sections['d']['total'] == 0)
        $this->_sections['d']['show'] = false;
} else
    $this->_sections['d']['total'] = 0;
if ($this->_sections['d']['show']):

            for ($this->_sections['d']['index'] = $this->_sections['d']['start'], $this->_sections['d']['iteration'] = 1;
                 $this->_sections['d']['iteration'] <= $this->_sections['d']['total'];
                 $this->_sections['d']['index'] += $this->_sections['d']['step'], $this->_sections['d']['iteration']++):
$this->_sections['d']['rownum'] = $this->_sections['d']['iteration'];
$this->_sections['d']['index_prev'] = $this->_sections['d']['index'] - $this->_sections['d']['step'];
$this->_sections['d']['index_next'] = $this->_sections['d']['index'] + $this->_sections['d']['step'];
$this->_sections['d']['first']      = ($this->_sections['d']['iteration'] == 1);
$this->_sections['d']['last']       = ($this->_sections['d']['iteration'] == $this->_sections['d']['total']);
?>
	var arr = <?php echo $this->_tpl_vars['graphdata'][$this->_sections['d']['index']]['v']; ?>
;
	getBar('g_<?php echo $this->_sections['d']['index']; ?>
','ip','<?php echo $this->_tpl_vars['graphdata'][$this->_sections['d']['index']]['k_cn']; ?>
',arr);
	<?php endfor; endif; ?>
		
	});
	
	 function	getBar(divid,cname,title,arr){

	var y = 55;
	var rotation = -65;
	var bottom = 100;
	if(cname=='protocol'){
		y = 20;
		bottom = 40;
		rotation = 0;
	}
	var colors = Highcharts.getOptions().colors;
	var max = parseInt(arr[0].num)+0.5;
	var categories = new Array();
	var data = new Array();
     for(var i=0; i<arr.length;i++){
	        categories[i] = arr[i][cname];
	        var o = new Object();
	        o.y = arr[i].num;
	        o.color = colors[i];
	        data[i] =  o;
 
	  }
		chart = new Highcharts.Chart({
			chart: {
				renderTo: divid, 
				type: 'column',
				marginBottom: bottom,
				marginTop: 20
			},
			title: {
				text: ''
			},
			xAxis: {
				categories: categories,
				tickPixelInterval:1000,
			//	tickInterval:10,
				labels:{  
				  rotation: rotation,
				  y:y 	
				}					
			},
			yAxis: {
				title: {
					
					rotation: 0,
					text: '数<br />量'
				},
				max:max
			},
			plotOptions: {
				column: {
					cursor: 'pointer',
					pointPadding: 0.2,
					borderWidth: 0,
					dataLabels: {
						enabled: true,
						color: colors[0],
						formatter: function() {
							return this.y ;
						}
					}					
				}
			},
			tooltip: {
				formatter: function() {
					var point = this.point,
					s = this.x +':<b>'+ this.y +'</b><br/>';
					return s;
				}
			},
			legend: { 
					            enabled: false  //设置图例不可见 
					        },
			series: [{
				name: title,
				data: data,
				color: 'white'
			}],
			exporting: {
				enabled: false
			}
		});
	}
</script>
</HEAD>
<BODY style="float:center">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >

  <tr>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0"  >
       <tr><td valign="middle" class="hui_bj"><div class="menu">
<ul>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_reports&action=host_reports">主机报表</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
<li class="me_a"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an1.jpg" align="absmiddle"/><a href="admin.php?controller=admin_reports&action=app_reports">应用报表</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an3.jpg" align="absmiddle"/></li>
<li class="me_b"><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an11.jpg" align="absmiddle"/><a href="admin.php?controller=admin_reports&action=dns_report">DNS报表</a><img src="<?php echo $this->_tpl_vars['template_root']; ?>
/images/an33.jpg" align="absmiddle"/></li>
</ul>
</div></td></tr>
<tr>
	<td align="left" colspan = "7"><table width="100%" border="0" cellspacing="0" cellpadding="0"  class="main_content">

		<TBODY>
		 <TR>
			<TD >
			<form name ='f1' action='admin.php?controller=admin_reports&action=app_reports' method='get' >
<input type="hidden" name="controller" value="admin_reports" />
<input type="hidden" name="action" value="app_reports" />
设备组:<select name='group'  style="width:150px">
<option value='' >全部设备</option>
<?php unset($this->_sections['g']);
$this->_sections['g']['name'] = 'g';
$this->_sections['g']['loop'] = is_array($_loop=$this->_tpl_vars['sgroup']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['g']['show'] = true;
$this->_sections['g']['max'] = $this->_sections['g']['loop'];
$this->_sections['g']['step'] = 1;
$this->_sections['g']['start'] = $this->_sections['g']['step'] > 0 ? 0 : $this->_sections['g']['loop']-1;
if ($this->_sections['g']['show']) {
    $this->_sections['g']['total'] = $this->_sections['g']['loop'];
    if ($this->_sections['g']['total'] == 0)
        $this->_sections['g']['show'] = false;
} else
    $this->_sections['g']['total'] = 0;
if ($this->_sections['g']['show']):

            for ($this->_sections['g']['index'] = $this->_sections['g']['start'], $this->_sections['g']['iteration'] = 1;
                 $this->_sections['g']['iteration'] <= $this->_sections['g']['total'];
                 $this->_sections['g']['index'] += $this->_sections['g']['step'], $this->_sections['g']['iteration']++):
$this->_sections['g']['rownum'] = $this->_sections['g']['iteration'];
$this->_sections['g']['index_prev'] = $this->_sections['g']['index'] - $this->_sections['g']['step'];
$this->_sections['g']['index_next'] = $this->_sections['g']['index'] + $this->_sections['g']['step'];
$this->_sections['g']['first']      = ($this->_sections['g']['iteration'] == 1);
$this->_sections['g']['last']       = ($this->_sections['g']['iteration'] == $this->_sections['g']['total']);
?>
<option value='<?php echo $this->_tpl_vars['sgroup'][$this->_sections['g']['index']]['id']; ?>
' ><?php echo $this->_tpl_vars['sgroup'][$this->_sections['g']['index']]['groupname']; ?>
</option>
<?php endfor; endif; ?>
</select>&nbsp;&nbsp;&nbsp;&nbsp;
内容:<select name='content' >
<option value='mysql' <?php if ($this->_tpl_vars['content'] == 'mysql'): ?>selected<?php endif; ?>>MySQL</option>
<option value='apache' <?php if ($this->_tpl_vars['content'] == 'apache'): ?>selected<?php endif; ?>>Apache</option>
<option value='tomcat' <?php if ($this->_tpl_vars['content'] == 'tomcat'): ?>selected<?php endif; ?>>Tomcat</option>
<option value='nginx' <?php if ($this->_tpl_vars['content'] == 'nginx'): ?>selected<?php endif; ?>>Nginx</option>
</select>
<input type="text" name="date" id="date" size="25" value="<?php echo $this->_tpl_vars['ymd']; ?>
"/><input type="button" id="f_date" name="f_date" value="开始时间"> - <input type="text" name="date_e" id="date_e" size="25" value="<?php echo $this->_tpl_vars['ymd_e']; ?>
"/><input type="button" id="f_date_e" name="f_date_e" value="结束时间"> 

<input type="submit" value="提交"  class="bnnew2"/>
<script type="text/javascript">
var cal = Calendar.setup({
    onSelect: function(cal) { cal.hide() }
});
cal.manageFields("f_date", "date", "%Y-%m-%d");
cal.manageFields("f_date_e", "date_e", "%Y-%m-%d");
</script>
			</form>
			</TD>
		  </TR>
		  </table></td></tr>		 
      <tr  >
        <td class="">
		<TR>
                  <TD style="MARGIN-TOP: 10px" colspan="9">
				  <table cellSpacing=0 cellPadding=0 width="100%" align=center><tr>
<?php unset($this->_sections['d']);
$this->_sections['d']['name'] = 'd';
$this->_sections['d']['loop'] = is_array($_loop=$this->_tpl_vars['graphdata']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['d']['show'] = true;
$this->_sections['d']['max'] = $this->_sections['d']['loop'];
$this->_sections['d']['step'] = 1;
$this->_sections['d']['start'] = $this->_sections['d']['step'] > 0 ? 0 : $this->_sections['d']['loop']-1;
if ($this->_sections['d']['show']) {
    $this->_sections['d']['total'] = $this->_sections['d']['loop'];
    if ($this->_sections['d']['total'] == 0)
        $this->_sections['d']['show'] = false;
} else
    $this->_sections['d']['total'] = 0;
if ($this->_sections['d']['show']):

            for ($this->_sections['d']['index'] = $this->_sections['d']['start'], $this->_sections['d']['iteration'] = 1;
                 $this->_sections['d']['iteration'] <= $this->_sections['d']['total'];
                 $this->_sections['d']['index'] += $this->_sections['d']['step'], $this->_sections['d']['iteration']++):
$this->_sections['d']['rownum'] = $this->_sections['d']['iteration'];
$this->_sections['d']['index_prev'] = $this->_sections['d']['index'] - $this->_sections['d']['step'];
$this->_sections['d']['index_next'] = $this->_sections['d']['index'] + $this->_sections['d']['step'];
$this->_sections['d']['first']      = ($this->_sections['d']['iteration'] == 1);
$this->_sections['d']['last']       = ($this->_sections['d']['iteration'] == $this->_sections['d']['total']);
?>
<?php if ($this->_sections['d']['index'] > 0 && $this->_sections['d']['index']%2 == 0): ?>
</tr><tr>
<?php endif; ?>
<td width="50%"><table width="100%" style="height:230px;"  class="BBtable">
									<tr>
										<th   style="text-align:left"   class="list_bg"><?php echo $this->_tpl_vars['graphdata'][$this->_sections['d']['index']]['k_cn']; ?>
</th>
									</tr>
									<tr>
										<td style="height:100%;" >
										 <div id="g_<?php echo $this->_sections['d']['index']; ?>
" style="width: 100%;height:80%;  margin: 1 auto"></div>
										</td>
									</tr>
								</table></td>
<?php endfor; endif; ?>
</tr></table>
</TD>
                </TR>
		  <TABLE class=BBtable cellSpacing=0 cellPadding=0 width="100%" align=center>		
              <TBODY>			
	<?php if ($this->_tpl_vars['content'] == 'apache'): ?>		  
			<TR>
                <td width="10%" class="list_bg">主机</td>
				<TD class="list_bg" >每秒流量 KB/s</TD>
				<TD class="list_bg" >系统占用</TD>
				<TD class="list_bg" >请求速率</TD>
				<TD class="list_bg" >当前进行数</TD>
				<TD class="list_bg" >正在处理请求</TD>
			  </TR>
			<?php unset($this->_sections['h']);
$this->_sections['h']['name'] = 'h';
$this->_sections['h']['loop'] = is_array($_loop=$this->_tpl_vars['reports']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['h']['show'] = true;
$this->_sections['h']['max'] = $this->_sections['h']['loop'];
$this->_sections['h']['step'] = 1;
$this->_sections['h']['start'] = $this->_sections['h']['step'] > 0 ? 0 : $this->_sections['h']['loop']-1;
if ($this->_sections['h']['show']) {
    $this->_sections['h']['total'] = $this->_sections['h']['loop'];
    if ($this->_sections['h']['total'] == 0)
        $this->_sections['h']['show'] = false;
} else
    $this->_sections['h']['total'] = 0;
if ($this->_sections['h']['show']):

            for ($this->_sections['h']['index'] = $this->_sections['h']['start'], $this->_sections['h']['iteration'] = 1;
                 $this->_sections['h']['iteration'] <= $this->_sections['h']['total'];
                 $this->_sections['h']['index'] += $this->_sections['h']['step'], $this->_sections['h']['iteration']++):
$this->_sections['h']['rownum'] = $this->_sections['h']['iteration'];
$this->_sections['h']['index_prev'] = $this->_sections['h']['index'] - $this->_sections['h']['step'];
$this->_sections['h']['index_next'] = $this->_sections['h']['index'] + $this->_sections['h']['step'];
$this->_sections['h']['first']      = ($this->_sections['h']['iteration'] == 1);
$this->_sections['h']['last']       = ($this->_sections['h']['iteration'] == $this->_sections['h']['total']);
?>
		 <TR <?php if ($this->_sections['h']['index'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['device_ip']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['cpu_load']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['request_rate']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['traffic_rate']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['process_num']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['busy_process']; ?>
</TD>
	  </TR>
	 
	<?php endfor; else: ?>
	   <TR>
                  <TD style="MARGIN-TOP: 10px" colspan="9">没有数据</TD>
                </TR>
	<?php endif; ?>
	<?php elseif ($this->_tpl_vars['content'] == 'mysql'): ?>
	<TR>
                <td width="10%" class="list_bg" >主机</td>
				<TD class="list_bg" >打开文件数</TD>
				<TD class="list_bg" >打开表数</TD>
				<TD class="list_bg" >连接数</TD>
				<TD class="list_bg" > 查询速率 </TD>
			  </TR>
			<?php unset($this->_sections['h']);
$this->_sections['h']['name'] = 'h';
$this->_sections['h']['loop'] = is_array($_loop=$this->_tpl_vars['reports']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['h']['show'] = true;
$this->_sections['h']['max'] = $this->_sections['h']['loop'];
$this->_sections['h']['step'] = 1;
$this->_sections['h']['start'] = $this->_sections['h']['step'] > 0 ? 0 : $this->_sections['h']['loop']-1;
if ($this->_sections['h']['show']) {
    $this->_sections['h']['total'] = $this->_sections['h']['loop'];
    if ($this->_sections['h']['total'] == 0)
        $this->_sections['h']['show'] = false;
} else
    $this->_sections['h']['total'] = 0;
if ($this->_sections['h']['show']):

            for ($this->_sections['h']['index'] = $this->_sections['h']['start'], $this->_sections['h']['iteration'] = 1;
                 $this->_sections['h']['iteration'] <= $this->_sections['h']['total'];
                 $this->_sections['h']['index'] += $this->_sections['h']['step'], $this->_sections['h']['iteration']++):
$this->_sections['h']['rownum'] = $this->_sections['h']['iteration'];
$this->_sections['h']['index_prev'] = $this->_sections['h']['index'] - $this->_sections['h']['step'];
$this->_sections['h']['index_next'] = $this->_sections['h']['index'] + $this->_sections['h']['step'];
$this->_sections['h']['first']      = ($this->_sections['h']['iteration'] == 1);
$this->_sections['h']['last']       = ($this->_sections['h']['iteration'] == $this->_sections['h']['total']);
?>
		 <TR <?php if ($this->_sections['h']['index'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['device_ip']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['questions_rate']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['open_tables']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['open_files']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['threads']; ?>
</TD>
	  </TR>
	 
	<?php endfor; else: ?>
	   <TR>
                  <TD style="MARGIN-TOP: 10px" colspan="9">没有数据</TD>
                </TR>
	<?php endif; ?>
	<?php elseif ($this->_tpl_vars['content'] == 'tomcat'): ?>
	<TR>
                <td width="10%" class="list_bg" >主机</td>
				<TD class="list_bg" >每秒流量 KB/s</TD>
				<TD class="list_bg" >CPU平均占用率 %</TD>
				<TD class="list_bg" >每秒请求数量</TD>
				<TD class="list_bg" > 当前jvm内存使用率 </TD>
				<TD class="list_bg" > 当前工作线程数 </TD>
			  </TR>
			<?php unset($this->_sections['h']);
$this->_sections['h']['name'] = 'h';
$this->_sections['h']['loop'] = is_array($_loop=$this->_tpl_vars['reports']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['h']['show'] = true;
$this->_sections['h']['max'] = $this->_sections['h']['loop'];
$this->_sections['h']['step'] = 1;
$this->_sections['h']['start'] = $this->_sections['h']['step'] > 0 ? 0 : $this->_sections['h']['loop']-1;
if ($this->_sections['h']['show']) {
    $this->_sections['h']['total'] = $this->_sections['h']['loop'];
    if ($this->_sections['h']['total'] == 0)
        $this->_sections['h']['show'] = false;
} else
    $this->_sections['h']['total'] = 0;
if ($this->_sections['h']['show']):

            for ($this->_sections['h']['index'] = $this->_sections['h']['start'], $this->_sections['h']['iteration'] = 1;
                 $this->_sections['h']['iteration'] <= $this->_sections['h']['total'];
                 $this->_sections['h']['index'] += $this->_sections['h']['step'], $this->_sections['h']['iteration']++):
$this->_sections['h']['rownum'] = $this->_sections['h']['iteration'];
$this->_sections['h']['index_prev'] = $this->_sections['h']['index'] - $this->_sections['h']['step'];
$this->_sections['h']['index_next'] = $this->_sections['h']['index'] + $this->_sections['h']['step'];
$this->_sections['h']['first']      = ($this->_sections['h']['iteration'] == 1);
$this->_sections['h']['last']       = ($this->_sections['h']['iteration'] == $this->_sections['h']['total']);
?>
		 <TR <?php if ($this->_sections['h']['index'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['device_ip']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['traffic_rate']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['cpu_load']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['request_rate']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['memory_usage']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['busy_thread']; ?>
</TD>
	  </TR>
	 
	<?php endfor; else: ?>
	   <TR>
                  <TD style="MARGIN-TOP: 10px" colspan="9">没有数据</TD>
                </TR>
	<?php endif; ?>
	<?php elseif ($this->_tpl_vars['content'] == 'nginx'): ?>
	<TR>
                <td width="10%" class="list_bg" >主机</td>
				<TD class="list_bg" >nginx 请求率（点击率）</TD>
				<TD class="list_bg" >nginx 连接数（并发数）</TD>
			  </TR>
			<?php unset($this->_sections['h']);
$this->_sections['h']['name'] = 'h';
$this->_sections['h']['loop'] = is_array($_loop=$this->_tpl_vars['reports']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['h']['show'] = true;
$this->_sections['h']['max'] = $this->_sections['h']['loop'];
$this->_sections['h']['step'] = 1;
$this->_sections['h']['start'] = $this->_sections['h']['step'] > 0 ? 0 : $this->_sections['h']['loop']-1;
if ($this->_sections['h']['show']) {
    $this->_sections['h']['total'] = $this->_sections['h']['loop'];
    if ($this->_sections['h']['total'] == 0)
        $this->_sections['h']['show'] = false;
} else
    $this->_sections['h']['total'] = 0;
if ($this->_sections['h']['show']):

            for ($this->_sections['h']['index'] = $this->_sections['h']['start'], $this->_sections['h']['iteration'] = 1;
                 $this->_sections['h']['iteration'] <= $this->_sections['h']['total'];
                 $this->_sections['h']['index'] += $this->_sections['h']['step'], $this->_sections['h']['iteration']++):
$this->_sections['h']['rownum'] = $this->_sections['h']['iteration'];
$this->_sections['h']['index_prev'] = $this->_sections['h']['index'] - $this->_sections['h']['step'];
$this->_sections['h']['index_next'] = $this->_sections['h']['index'] + $this->_sections['h']['step'];
$this->_sections['h']['first']      = ($this->_sections['h']['iteration'] == 1);
$this->_sections['h']['last']       = ($this->_sections['h']['iteration'] == $this->_sections['h']['total']);
?>
		 <TR <?php if ($this->_sections['h']['index'] % 2 == 0): ?>bgcolor="f7f7f7"<?php endif; ?>>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['device_ip']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['request_rate']; ?>
</TD>
		<TD class=""><?php echo $this->_tpl_vars['reports'][$this->_sections['h']['index']]['connect_num']; ?>
</TD>
	  </TR>
	 
	<?php endfor; else: ?>
	   <TR>
                  <TD style="MARGIN-TOP: 10px" colspan="9">没有数据</TD>
                </TR>
	<?php endif; ?>
	<?php endif; ?>
	<tr>
	  <td  colspan="8" align="right">
		   			&nbsp&nbsp;&nbsp;共<?php echo $this->_tpl_vars['total']; ?>
个记录  <?php echo $this->_tpl_vars['page_list']; ?>
  页次：<?php echo $this->_tpl_vars['curr_page']; ?>
/<?php echo $this->_tpl_vars['total_page']; ?>
页  <?php echo $this->_tpl_vars['items_per_page']; ?>
个记录/页  转到第<input name="pagenum" type="text" class="wbk" size="2" onKeyPress="if(event.keyCode==13) window.location='admin.php?controller=admin_monitor&action=system_monitor&page='+this.value;">页&nbsp;&nbsp;&nbsp;<?php if ($_SESSION['ADMIN_LEVEL'] == 3): ?><a href="<?php echo $this->_tpl_vars['curr_url']; ?>
&derive=1" target="hide"><?php echo $this->_tpl_vars['language']['ExportresulttoExcel']; ?>
</a><?php endif; ?>
		   </td>
		   </tr>
		</TBODY></TABLE>
  
    
		  </td>
      </tr>
	  <tr><td cellpadding="3" height="15" align="right"></td></tr>
    </table></td>
  </tr>
  <tr><td height="10"></td></tr>
</table>



</BODY></HTML>
