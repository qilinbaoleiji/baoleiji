<?php /* Smarty version 2.6.18, created on 2015-03-25 22:37:07
         compiled from passedit_selgroup.tpl */ ?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title><?php echo $this->_tpl_vars['title']; ?>
</title>
<meta name="generator" content="editplus">
<meta name="author" content="nuttycoder">
<link href="<?php echo $this->_tpl_vars['template_root']; ?>
/all_purpose_style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo $this->_tpl_vars['template_root']; ?>
/Calendarandtime.js"></script>
</head>

<body>
<FORM name="f1" onSubmit="return check()" action="admin.php?controller=admin_pro&action=passedit_selgroup_save" 
            method="post">

              <TABLE width="100%" bgcolor="#ffffff" border="0" cellspacing="0" cellpadding="0" valign="top"  class="BBtable">
                <TBODY>
                  <TR bgcolor="#f7f7f7">
                    <TD colspan="2" class="list_bg">设置</TD>
                  </TR>
                  <TR id="autosutr" bgcolor="#f7f7f7">
                    <TD width="50%" align="right"><?php echo $this->_tpl_vars['language']['automaticallyloginassuperadministrator']; ?>
</TD>
                    <TD><INPUT id="autosu" <?php if ($this->_tpl_vars['lgroup']['autosu'] == 1): ?> checked <?php endif; ?> type=checkbox name=autosu value="on">                      </TD>
                  </TR>
                  <TR id="autosutr">
                    <TD width="50%" align="right"><?php echo $this->_tpl_vars['language']['syslogAlertwhenloginin']; ?>
</TD>
                    <TD><INPUT id="syslogalert" <?php if ($this->_tpl_vars['lgroup']['syslogalert'] == 1): ?> checked <?php endif; ?> type=checkbox name=syslogalert value="on">                  </TD>
                  </TR>
                  <TR id="autosutr" bgcolor="#f7f7f7">
                    <TD width="50%" align="right"><?php echo $this->_tpl_vars['language']['mailalertwhenloginin']; ?>
</TD>
                    <TD><INPUT id="mailalert" <?php if ($this->_tpl_vars['lgroup']['mailalert'] == 1): ?> checked <?php endif; ?> type=checkbox name=mailalert value="on">              </TD>
                  </TR>
                  <TR id="autosutr">
                    <TD width="50%" align="right"><?php echo $this->_tpl_vars['language']['accountlocked']; ?>
 </TD>
                    <TD><INPUT id="loginlock" <?php if ($this->_tpl_vars['lgroup']['loginlock'] == 1): ?> checked <?php endif; ?> type=checkbox name=loginlock value="on">                    </TD>
                  </TR>
                                   <TR bgcolor="#f7f7f7">
                    <TD width="50%" align="right">命令权限 </TD>
                    <TD><select  class="wbk"  name=forbidden_commands_groups>
                      <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['f']);
$this->_sections['f']['name'] = 'f';
$this->_sections['f']['loop'] = is_array($_loop=$this->_tpl_vars['allforbiddengroup']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['f']['show'] = true;
$this->_sections['f']['max'] = $this->_sections['f']['loop'];
$this->_sections['f']['step'] = 1;
$this->_sections['f']['start'] = $this->_sections['f']['step'] > 0 ? 0 : $this->_sections['f']['loop']-1;
if ($this->_sections['f']['show']) {
    $this->_sections['f']['total'] = $this->_sections['f']['loop'];
    if ($this->_sections['f']['total'] == 0)
        $this->_sections['f']['show'] = false;
} else
    $this->_sections['f']['total'] = 0;
if ($this->_sections['f']['show']):

            for ($this->_sections['f']['index'] = $this->_sections['f']['start'], $this->_sections['f']['iteration'] = 1;
                 $this->_sections['f']['iteration'] <= $this->_sections['f']['total'];
                 $this->_sections['f']['index'] += $this->_sections['f']['step'], $this->_sections['f']['iteration']++):
$this->_sections['f']['rownum'] = $this->_sections['f']['iteration'];
$this->_sections['f']['index_prev'] = $this->_sections['f']['index'] - $this->_sections['f']['step'];
$this->_sections['f']['index_next'] = $this->_sections['f']['index'] + $this->_sections['f']['step'];
$this->_sections['f']['first']      = ($this->_sections['f']['iteration'] == 1);
$this->_sections['f']['last']       = ($this->_sections['f']['iteration'] == $this->_sections['f']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['allforbiddengroup'][$this->_sections['f']['index']]['gname']; ?>
" <?php if ($this->_tpl_vars['allforbiddengroup'][$this->_sections['f']['index']]['gname'] == $this->_tpl_vars['lgroup']['forbidden_commands_groups']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['allforbiddengroup'][$this->_sections['f']['index']]['gname']; ?>
(<?php if ($this->_tpl_vars['allforbiddengroup'][$this->_sections['f']['index']]['black_or_white'] == 1): ?>白名单<?php elseif ($this->_tpl_vars['allforbiddengroup'][$this->_sections['f']['index']]['black_or_white'] == 3): ?>授权命令<?php else: ?>黑名单<?php endif; ?>)</option>
			<?php endfor; endif; ?>
                  </SELECT>      </TD>
                  </TR>
				 <TR bgcolor="">
                    <TD width="50%" align="right">双人授权 </TD>
                    <TD><INPUT id="twoauth" <?php if ($this->_tpl_vars['lgroup']['twoauth'] == 1): ?> checked <?php endif; ?> type=checkbox onclick="checktwo(this.checked);" name=twoauth value="on"></TD>
                  </TR>
				   <TR bgcolor="" id="wf_2">
                    <TD width="50%" align="right">登录短信告警</TD>
                    <TD><INPUT id="smsalert" <?php if ($this->_tpl_vars['lgroup']['smsalert'] == 1): ?> checked <?php endif; ?> type=checkbox name=smsalert value="on">           </TD>
                  </TR>
				  <TR bgcolor="" id="wf_2">
                    <TD width="50%" align="right">流程审批</TD>
                    <TD><INPUT id="workflow" onclick="sworkflow(this.checked);" <?php if ($this->_tpl_vars['lgroup']['workflow'] == 1): ?> checked <?php endif; ?> type=checkbox name=workflow value="on">           </TD>
                  </TR>
				  <TR bgcolor="#f7f7f7" id=tr_wf_user1>
                    <TD width="50%" align="right">审批人一 </TD>
                    <TD><select  class="wbk"  name=wf_user1 id=wf_user1 >
                      <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['w']);
$this->_sections['w']['name'] = 'w';
$this->_sections['w']['loop'] = is_array($_loop=$this->_tpl_vars['webusers']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['w']['show'] = true;
$this->_sections['w']['max'] = $this->_sections['w']['loop'];
$this->_sections['w']['step'] = 1;
$this->_sections['w']['start'] = $this->_sections['w']['step'] > 0 ? 0 : $this->_sections['w']['loop']-1;
if ($this->_sections['w']['show']) {
    $this->_sections['w']['total'] = $this->_sections['w']['loop'];
    if ($this->_sections['w']['total'] == 0)
        $this->_sections['w']['show'] = false;
} else
    $this->_sections['w']['total'] = 0;
if ($this->_sections['w']['show']):

            for ($this->_sections['w']['index'] = $this->_sections['w']['start'], $this->_sections['w']['iteration'] = 1;
                 $this->_sections['w']['iteration'] <= $this->_sections['w']['total'];
                 $this->_sections['w']['index'] += $this->_sections['w']['step'], $this->_sections['w']['iteration']++):
$this->_sections['w']['rownum'] = $this->_sections['w']['iteration'];
$this->_sections['w']['index_prev'] = $this->_sections['w']['index'] - $this->_sections['w']['step'];
$this->_sections['w']['index_next'] = $this->_sections['w']['index'] + $this->_sections['w']['step'];
$this->_sections['w']['first']      = ($this->_sections['w']['iteration'] == 1);
$this->_sections['w']['last']       = ($this->_sections['w']['iteration'] == $this->_sections['w']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid']; ?>
" <?php if ($this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid'] == $this->_tpl_vars['lgroup']['wf_user1']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['username']; ?>
</option>
			<?php endfor; endif; ?>
                  </SELECT>       </TD>
                  </TR>
				  <TR id=tr_wf_user2>
                    <TD width="50%" align="right">审批人二 </TD>
                    <TD><select  class="wbk"  name=wf_user2 id=wf_user2>
                      <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['w']);
$this->_sections['w']['name'] = 'w';
$this->_sections['w']['loop'] = is_array($_loop=$this->_tpl_vars['webusers']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['w']['show'] = true;
$this->_sections['w']['max'] = $this->_sections['w']['loop'];
$this->_sections['w']['step'] = 1;
$this->_sections['w']['start'] = $this->_sections['w']['step'] > 0 ? 0 : $this->_sections['w']['loop']-1;
if ($this->_sections['w']['show']) {
    $this->_sections['w']['total'] = $this->_sections['w']['loop'];
    if ($this->_sections['w']['total'] == 0)
        $this->_sections['w']['show'] = false;
} else
    $this->_sections['w']['total'] = 0;
if ($this->_sections['w']['show']):

            for ($this->_sections['w']['index'] = $this->_sections['w']['start'], $this->_sections['w']['iteration'] = 1;
                 $this->_sections['w']['iteration'] <= $this->_sections['w']['total'];
                 $this->_sections['w']['index'] += $this->_sections['w']['step'], $this->_sections['w']['iteration']++):
$this->_sections['w']['rownum'] = $this->_sections['w']['iteration'];
$this->_sections['w']['index_prev'] = $this->_sections['w']['index'] - $this->_sections['w']['step'];
$this->_sections['w']['index_next'] = $this->_sections['w']['index'] + $this->_sections['w']['step'];
$this->_sections['w']['first']      = ($this->_sections['w']['iteration'] == 1);
$this->_sections['w']['last']       = ($this->_sections['w']['iteration'] == $this->_sections['w']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid']; ?>
" <?php if ($this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid'] == $this->_tpl_vars['lgroup']['wf_user2']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['username']; ?>
</option>
			<?php endfor; endif; ?>
                  </SELECT>       </TD>
                  </TR>
				  <TR bgcolor="#f7f7f7" id=tr_wf_user3>
                    <TD width="50%" align="right">审批人三 </TD>
                    <TD><select  class="wbk"  name=wf_user3 id=wf_user3>
                      <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['w']);
$this->_sections['w']['name'] = 'w';
$this->_sections['w']['loop'] = is_array($_loop=$this->_tpl_vars['webusers']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['w']['show'] = true;
$this->_sections['w']['max'] = $this->_sections['w']['loop'];
$this->_sections['w']['step'] = 1;
$this->_sections['w']['start'] = $this->_sections['w']['step'] > 0 ? 0 : $this->_sections['w']['loop']-1;
if ($this->_sections['w']['show']) {
    $this->_sections['w']['total'] = $this->_sections['w']['loop'];
    if ($this->_sections['w']['total'] == 0)
        $this->_sections['w']['show'] = false;
} else
    $this->_sections['w']['total'] = 0;
if ($this->_sections['w']['show']):

            for ($this->_sections['w']['index'] = $this->_sections['w']['start'], $this->_sections['w']['iteration'] = 1;
                 $this->_sections['w']['iteration'] <= $this->_sections['w']['total'];
                 $this->_sections['w']['index'] += $this->_sections['w']['step'], $this->_sections['w']['iteration']++):
$this->_sections['w']['rownum'] = $this->_sections['w']['iteration'];
$this->_sections['w']['index_prev'] = $this->_sections['w']['index'] - $this->_sections['w']['step'];
$this->_sections['w']['index_next'] = $this->_sections['w']['index'] + $this->_sections['w']['step'];
$this->_sections['w']['first']      = ($this->_sections['w']['iteration'] == 1);
$this->_sections['w']['last']       = ($this->_sections['w']['iteration'] == $this->_sections['w']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid']; ?>
" <?php if ($this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid'] == $this->_tpl_vars['lgroup']['wf_user3']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['username']; ?>
</option>
			<?php endfor; endif; ?>
                  </SELECT>       </TD>
                  </TR>
				  <TR id=tr_wf_user4>
                    <TD width="50%" align="right">审批人四 </TD>
                    <TD><select  class="wbk"  name=wf_user4 id=wf_user4>
                      <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['w']);
$this->_sections['w']['name'] = 'w';
$this->_sections['w']['loop'] = is_array($_loop=$this->_tpl_vars['webusers']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['w']['show'] = true;
$this->_sections['w']['max'] = $this->_sections['w']['loop'];
$this->_sections['w']['step'] = 1;
$this->_sections['w']['start'] = $this->_sections['w']['step'] > 0 ? 0 : $this->_sections['w']['loop']-1;
if ($this->_sections['w']['show']) {
    $this->_sections['w']['total'] = $this->_sections['w']['loop'];
    if ($this->_sections['w']['total'] == 0)
        $this->_sections['w']['show'] = false;
} else
    $this->_sections['w']['total'] = 0;
if ($this->_sections['w']['show']):

            for ($this->_sections['w']['index'] = $this->_sections['w']['start'], $this->_sections['w']['iteration'] = 1;
                 $this->_sections['w']['iteration'] <= $this->_sections['w']['total'];
                 $this->_sections['w']['index'] += $this->_sections['w']['step'], $this->_sections['w']['iteration']++):
$this->_sections['w']['rownum'] = $this->_sections['w']['iteration'];
$this->_sections['w']['index_prev'] = $this->_sections['w']['index'] - $this->_sections['w']['step'];
$this->_sections['w']['index_next'] = $this->_sections['w']['index'] + $this->_sections['w']['step'];
$this->_sections['w']['first']      = ($this->_sections['w']['iteration'] == 1);
$this->_sections['w']['last']       = ($this->_sections['w']['iteration'] == $this->_sections['w']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid']; ?>
" <?php if ($this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid'] == $this->_tpl_vars['lgroup']['wf_user4']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['username']; ?>
</option>
			<?php endfor; endif; ?>
                  </SELECT>       </TD>
                  </TR>
				  <TR bgcolor="#f7f7f7" id=tr_wf_user5>
                    <TD width="50%" align="right">审批人五 </TD>
                    <TD><select  class="wbk"  name=wf_user5 id=wf_user5>
                      <OPTION value=""><?php echo $this->_tpl_vars['language']['no']; ?>
</OPTION>
                     	<?php unset($this->_sections['w']);
$this->_sections['w']['name'] = 'w';
$this->_sections['w']['loop'] = is_array($_loop=$this->_tpl_vars['webusers']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['w']['show'] = true;
$this->_sections['w']['max'] = $this->_sections['w']['loop'];
$this->_sections['w']['step'] = 1;
$this->_sections['w']['start'] = $this->_sections['w']['step'] > 0 ? 0 : $this->_sections['w']['loop']-1;
if ($this->_sections['w']['show']) {
    $this->_sections['w']['total'] = $this->_sections['w']['loop'];
    if ($this->_sections['w']['total'] == 0)
        $this->_sections['w']['show'] = false;
} else
    $this->_sections['w']['total'] = 0;
if ($this->_sections['w']['show']):

            for ($this->_sections['w']['index'] = $this->_sections['w']['start'], $this->_sections['w']['iteration'] = 1;
                 $this->_sections['w']['iteration'] <= $this->_sections['w']['total'];
                 $this->_sections['w']['index'] += $this->_sections['w']['step'], $this->_sections['w']['iteration']++):
$this->_sections['w']['rownum'] = $this->_sections['w']['iteration'];
$this->_sections['w']['index_prev'] = $this->_sections['w']['index'] - $this->_sections['w']['step'];
$this->_sections['w']['index_next'] = $this->_sections['w']['index'] + $this->_sections['w']['step'];
$this->_sections['w']['first']      = ($this->_sections['w']['iteration'] == 1);
$this->_sections['w']['last']       = ($this->_sections['w']['iteration'] == $this->_sections['w']['total']);
?>
				<option value="<?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid']; ?>
" <?php if ($this->_tpl_vars['webusers'][$this->_sections['w']['index']]['uid'] == $this->_tpl_vars['lgroup']['wf_user5']): ?>selected<?php endif; ?>><?php echo $this->_tpl_vars['webusers'][$this->_sections['w']['index']]['username']; ?>
</option>
			<?php endfor; endif; ?>
                  </SELECT>       </TD>
                  </TR>
                  <TR>
                    <TD colspan="2" align="center"><INPUT class="an_02" type="submit" value="保存修改"></TD>
                  </TR>
                </TBODY>
              </TABLE>
<input type="hidden" name="id" value="<?php echo $this->_tpl_vars['lgroup']['id']; ?>
" />
<input type="hidden" name="gid" value="<?php echo $this->_tpl_vars['gid']; ?>
" />
<input type="hidden" name="sid" value="<?php echo $this->_tpl_vars['sid']; ?>
" />
<input type="hidden" name="sessionlgroup" value="<?php echo $this->_tpl_vars['sessionlgroup']; ?>
" />
</FORM>

<script>
function sworkflow(checked){
	if(checked){
		for(var i=1; i<=5; i++){
			document.getElementById('tr_wf_user'+i).style.display = '';
		}
	}else{
		for(var i=1; i<=5; i++){
			document.getElementById('tr_wf_user'+i).style.display = 'none';
		}
	}
}
var success = true;
function checkwfuser(user, b){
	success = true;
	checkwfuser1(user,b);
	return success;
}
function checkwfuser1(user, b){
	if(document.getElementById('wf_user'+user).options[document.getElementById('wf_user'+user).options.selectedIndex].value > 0){
		b = true;
		if(user-1>0){
			if(checkwfuser1(user-1, b)==false&&b){
				success = false;
				alert('请选择流程批准人'+(user-1));
				return false;
			}
		}
		return true;
	}
	if(user-1>0&&b==false){
		checkwfuser1(user-1, b);
	}
	return false;
}

function checktwo(c){
  if(c){
	document.getElementById('workflow').checked = true;
	sworkflow(true);
  }
}
sworkflow(<?php if (! $this->_tpl_vars['luser']['workflow']): ?>false<?php else: ?>true<?php endif; ?>);
</script>
</body>
<iframe name="hide" height="0" frameborder="0" scrolling="no"></iframe>
</html>

