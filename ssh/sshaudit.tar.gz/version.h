/* $OpenBSD: version.h,v 1.58 2010/03/16 16:36:49 djm Exp $ */

#define SSH_VERSION	"OpenSSH_5.5"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
