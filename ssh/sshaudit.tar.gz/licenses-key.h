#ifndef _LICENSES_KEY_H
#define _LICENSES_KEY_H

#define LICENSES_KEY "freesvr123"

#endif
